/** Lọc bảng / thẻ trên trình duyệt (không đổi SQL). */
function tableFilterInit(root) {
  if (!root) return;
  const roleSel = root.querySelector('[data-filter-role]');
  const healthSel = root.querySelector('[data-filter-health]');
  const searchInp = root.querySelector('[data-filter-search]');
  const resetBtn = root.querySelector('[data-filter-reset]');
  const rows = () => root.querySelectorAll('[data-filter-row]');

  function apply() {
    const role = (roleSel?.value || '').toLowerCase();
    const health = (healthSel?.value || '').toLowerCase();
    const q = (searchInp?.value || '').trim().toLowerCase();
    let visible = 0;
    rows().forEach((row) => {
      const r = (row.dataset.role || '').toLowerCase();
      const h = (row.dataset.health || '').toLowerCase();
      const hay = (row.dataset.search || '').toLowerCase();
      const ok = (!role || r === role) && (!health || h === health) && (!q || hay.includes(q));
      row.hidden = !ok;
      if (ok) visible++;
    });
    const empty = root.querySelector('[data-filter-empty]');
    if (empty) empty.hidden = visible > 0;
  }

  roleSel?.addEventListener('change', apply);
  healthSel?.addEventListener('change', apply);
  searchInp?.addEventListener('input', apply);
  resetBtn?.addEventListener('click', () => {
    if (roleSel) roleSel.value = '';
    if (healthSel) healthSel.value = '';
    if (searchInp) searchInp.value = '';
    apply();
  });
  apply();
}

document.querySelectorAll('[data-table-filter]').forEach(tableFilterInit);
