# Đường dẫn query (PHP)

| BQ | SQL | Dashboard |
|----|-----|-----------|
| BQ-01 | `includes/report_definitions.php` | `dashboard.php` (admin) |
| BQ-10 | ↑ | `dashboard.php` (admin) — activity log |
| BQ-26 | ↑ | `dashboard.php` (admin) — user summary role/status |
| BQ-27 | ↑ | `dashboard.php` (admin) — tài khoản locked / chưa login |
| BQ-02 | ↑ | `dashboard.php` (manager) |
| BQ-03 | ↑ | `dashboard.php` (manager) |
| BQ-04 | ↑ | `dashboard.php` (manager) — sensor lỗi/inactive |
| BQ-05 | ↑ | `dashboard.php` (manager) — cảnh báo mở |
| BQ-06 | ↑ | `dashboard.php` (manager) — lịch tưới active |
| BQ-07 | ↑ | `dashboard.php` (manager) — Currently Irrigating |
| BQ-08 | ↑ | `dashboard.php` (manager) — Pending Approval |
| BQ-09 | ↑ | `dashboard.php` (manager) — dự báo thời tiết 7 ngày |
| BQ-20 | ↑ | `dashboard.php` (manager) — lịch tưới đề xuất theo thời tiết |
| BQ-21 | ↑ | `dashboard.php` (manager) — `vw_zone_health_summary` |
| BQ-22 | ↑ | `dashboard.php` (farmer) — `sp_farmer_zone_dashboard` |
| BQ-28 | ↑ | `dashboard.php` (farmer) — latest sensor readings (RBAC) |
| BQ-29 | ↑ | `dashboard.php` (farmer) — alert chưa xử lý (RBAC) |
| BQ-23 | `sql/aloe_farm_dashboard.sql` + `includes/db_schema.php` | Trigger → alert mới trên BQ-05; demo: Manager form / `api/sensor_ingest.php` |
| BQ-24 | `includes/harvest_engine.php` | Manager dashboard — nút Duyệt (transaction + audit) |
| BQ-11 | ↑ | `dashboard.php` (manager) — zone khô (TB độ ẩm &lt; 60%) |
| BQ-12 | ↑ | `dashboard.php` (manager) — root rot risk (max &gt; 85%) |
| BQ-13 | ↑ | `dashboard.php` (manager) — alert summary theo zone |
| BQ-14 | ↑ | `dashboard.php` (manager) — hiệu quả tưới theo zone |
| BQ-15 | ↑ | `dashboard.php` (manager) — irrigation failure |
| BQ-16 | ↑ | `dashboard.php` (manager) — AI irrigation recommendations |
| BQ-17 | ↑ | `dashboard.php` (manager) — disease risk cards |
| BQ-18 | ↑ | `dashboard.php` (manager) — harvest performance leaderboard |
| BQ-19 | ↑ | `dashboard.php` (manager) — KPI completion % |
| BQ-25 | ↑ | `dashboard.php` (manager) — ranking Zone (RANK) |
| BQ-30 | ↑ | `dashboard.php` (manager) — KPI cards (scalar subqueries) |

Chạy query: `report_run($conn, 'BQ-XX')` trong `includes/reports.php`.

**Điều hướng:** Sidebar + `?page=` trên `dashboard.php` — cấu hình `includes/nav_config.php`, load theo trang `includes/dashboard_load.php`, view tách `views/manager/`, `views/farmer/`, `views/admin/`.

JSON (tùy chọn): `GET /farm/api/report.php?code=BQ-01`
