<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/reports.php';
require_once __DIR__ . '/includes/dashboard_load.php';
require_once __DIR__ . '/includes/nav_config.php';
rbac_middleware();

$user = current_user();
$role = $user['role'];
$adminOps = $role === 'admin' && ($_GET['view'] ?? '') === 'ops';
$dashPage = nav_sanitize_page((string)($_GET['page'] ?? 'overview'), $role, $adminOps);
$GLOBALS['dash_page_title'] = nav_page_title($role, $dashPage, $adminOps);

function dash_redirect_url(string $role, bool $adminOps, string $page, string $query = ''): string
{
    $base = $adminOps ? 'dashboard.php?view=ops&page=' . rawurlencode($page) : 'dashboard.php?page=' . rawurlencode($page);

    return $query !== '' ? $base . '&' . $query : $base;
}

if ($role === 'farmer') {
    $vars = dashboard_load_farmer($conn, $dashPage, (int)$user['user_id']);
    extract($vars, EXTR_SKIP);
    $farmerPage = $dashPage;
    require __DIR__ . '/views/dashboard_farmer.php';
    exit;
}

if ($role === 'admin' && !$adminOps) {
    $vars = dashboard_load_admin($conn, $dashPage);
    extract($vars, EXTR_SKIP);
    $adminPage = $dashPage;
    require __DIR__ . '/views/dashboard_admin.php';
    exit;
}

if ($role === 'manager' || $adminOps) {
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['harvest_approve'] ?? '') === '1') {
        require_once __DIR__ . '/includes/harvest_engine.php';
        $harvestId = (int)($_POST['harvest_id'] ?? 0);
        $approveResult = ['ok' => false, 'error' => 'Không có quyền duyệt thu hoạch.'];
        if (rbac_can('harvest.approve')) {
            $approveResult = harvest_approve($conn, $harvestId, (int)$user['user_id']);
        }
        $q = $approveResult['ok'] ? 'harvest_ok=1' : 'harvest_err=' . urlencode((string)($approveResult['error'] ?? 'Lỗi'));
        header('Location: ' . dash_redirect_url($role, $adminOps, 'harvest', $q));
        exit;
    }

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['iot_sim'] ?? '') === '1') {
        require_once __DIR__ . '/includes/sensor_helpers.php';
        $sensorCode = trim((string)($_POST['sensor_code'] ?? ''));
        $readingValue = (float)($_POST['reading_value'] ?? 0);
        if ($sensorCode !== '') {
            sensor_ingest_by_code($conn, $sensorCode, $readingValue);
        }
        header('Location: ' . dash_redirect_url($role, $adminOps, 'alerts', 'iot=1'));
        exit;
    }

    $vars = dashboard_load_manager($conn, $dashPage);
    extract($vars, EXTR_SKIP);
    $managerPage = $dashPage;
    $isAdmin = $adminOps;
    require __DIR__ . '/views/dashboard_manager.php';
    exit;
}

require __DIR__ . '/includes/layout.php';
echo '<div class="card"><p class="muted">Không có quyền.</p></div>';
require __DIR__ . '/includes/layout_end.php';
