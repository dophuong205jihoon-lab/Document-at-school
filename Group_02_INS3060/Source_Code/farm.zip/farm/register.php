<?php
/**
 * FR-01: Farmer tự đăng ký (role=farmer, bcrypt, redirect login)
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$old = ['username' => '', 'email' => '', 'full_name' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $old = compact('username', 'email', 'full_name', 'phone');

    if ($username === '' || $email === '' || $full_name === '' || $password === '') {
        $error = 'Vui lòng điền đầy đủ thông tin bắt buộc.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Email không hợp lệ.';
    } elseif (strlen($password) < 8) {
        $error = 'Mật khẩu phải có tối thiểu 8 ký tự.';
    } elseif ($password !== $password_confirm) {
        $error = 'Xác nhận mật khẩu không khớp.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
        $error = 'Tên đăng nhập chỉ gồm chữ, số, gạch dưới (3–50 ký tự).';
    } else {
        $stmt = mysqli_prepare($conn, 'SELECT user_id FROM users WHERE user_email = ? LIMIT 1');
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        if (mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))) {
            $error = 'Email đã được sử dụng.';
        } else {
            $stmt = mysqli_prepare($conn, 'SELECT user_id FROM users WHERE user_username = ? LIMIT 1');
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            if (mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))) {
                $error = 'Tên đăng nhập đã tồn tại.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $role = 'farmer';
                $status = 'active';
                $phoneVal = $phone !== '' ? $phone : null;
                $stmt = mysqli_prepare(
                    $conn,
                    'INSERT INTO users (user_username, user_password_hash, user_email, user_full_name, user_role, user_status, user_phone)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );
                mysqli_stmt_bind_param($stmt, 'sssssss', $username, $hash, $email, $full_name, $role, $status, $phoneVal);
                if (mysqli_stmt_execute($stmt)) {
                    header('Location: login.php?registered=1');
                    exit;
                }
                $error = 'Không thể tạo tài khoản: ' . mysqli_error($conn);
            }
        }
    }
}

require __DIR__ . '/includes/layout.php';
?>
<div class="auth-card" style="width:min(480px,93vw);">
    <div class="auth-logo">
        <div class="auth-logo-icon">🌱</div>
        <div>
            <div class="auth-brand">Aloe Vera Farm</div>
            <div class="auth-brand-sub">Đăng ký Farmer</div>
        </div>
    </div>
    <div class="auth-heading">Đăng ký tài khoản (FR-01)</div>
    <div class="auth-sub">Role mặc định: <strong>Farmer</strong> — Admin sẽ phân Zone sau khi duyệt</div>

    <?php if ($error): ?>
        <div class="message-error"><?php echo e($error); ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;">
            <div class="form-group" style="margin:0">
                <label class="form-label">Họ và tên *</label>
                <input class="form-input" name="full_name" value="<?php echo e($old['full_name']); ?>" required>
            </div>
            <div class="form-group" style="margin:0">
                <label class="form-label">Số điện thoại</label>
                <input class="form-input" type="tel" name="phone" value="<?php echo e($old['phone']); ?>" placeholder="0901234567">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">Email *</label>
            <input class="form-input" type="email" name="email" value="<?php echo e($old['email']); ?>" required>
        </div>
        <div class="form-group">
            <label class="form-label">Tên đăng nhập *</label>
            <input class="form-input" name="username" value="<?php echo e($old['username']); ?>"
                   pattern="[a-zA-Z0-9_]{3,50}" title="3–50 ký tự: chữ, số, gạch dưới" required>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;">
            <div class="form-group" style="margin:0">
                <label class="form-label">Mật khẩu *</label>
                <input class="form-input" type="password" name="password" minlength="8" placeholder="≥8 ký tự" required>
            </div>
            <div class="form-group" style="margin:0">
                <label class="form-label">Xác nhận mật khẩu *</label>
                <input class="form-input" type="password" name="password_confirm" minlength="8" required>
            </div>
        </div>
        <div style="background:var(--green-50);border:1px solid var(--green-200);border-radius:var(--r);padding:9px 12px;font-size:12px;color:var(--green-700);margin-bottom:14px">
            🔒 Chỉ đăng ký vai trò Farmer. Manager/Admin do quản trị viên tạo trong mục Users.
        </div>
        <button type="submit" class="auth-btn">Tạo tài khoản →</button>
    </form>

    <div class="auth-switch">
        Đã có tài khoản?
        <a href="login.php"><strong>Đăng nhập (FR-02)</strong></a>
    </div>
</div>
<?php require __DIR__ . '/includes/layout_end.php';
