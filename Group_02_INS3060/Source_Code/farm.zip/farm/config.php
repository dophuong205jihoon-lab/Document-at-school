<?php
/**
 * App configuration (JWT, cookies).
 */
define('JWT_SECRET', getenv('FARM_JWT_SECRET') ?: 'aloe-farm-change-this-secret-in-production');
define('JWT_TTL', 8 * 3600); // 8 hours
define('JWT_COOKIE_NAME', 'farm_token');
define('COOKIE_PATH', '/farm');
define('IOT_API_KEY', getenv('FARM_IOT_API_KEY') ?: 'aloe-iot-dev-key-change-in-production');
/** Tọa độ trang trại (Open-Meteo) — mặc định TP.HCM */
define('WEATHER_LAT', (float)(getenv('FARM_WEATHER_LAT') ?: '10.8231'));
define('WEATHER_LON', (float)(getenv('FARM_WEATHER_LON') ?: '106.6297'));
