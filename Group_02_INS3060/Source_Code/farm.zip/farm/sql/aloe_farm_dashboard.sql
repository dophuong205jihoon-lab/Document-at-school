-- ============================================================
-- ALOE VERA FARM MANAGEMENT DASHBOARD SYSTEM
-- MySQL 8.0 | Engine: InnoDB | Charset: utf8mb4
-- File đầy đủ: DDL (đã review + sửa) + Mock Data + Queries (25+)
-- ============================================================


-- ============================================================
-- PHẦN 1: TÓM TẮT HỆ THỐNG
-- ============================================================
/*
 HỆ THỐNG LÀM GÌ:
 - Quản lý 1 nông trại nha đam (~5 ha, 10 Zone) theo mô hình IoT + AI
 - Giám sát real-time: độ ẩm đất, nhiệt độ, pH, EC từ sensor mỗi 5 phút
 - Tự động hóa tưới nhỏ giọt: lịch tưới + điều chỉnh theo thời tiết
 - Phát hiện bệnh sớm bằng AI (root rot, leaf spot, mealybug, thrips)
 - Quản lý thu hoạch + phê duyệt theo RBAC (Admin/Manager/Farmer)
 - Audit log toàn bộ thao tác, phân quyền 3 roles


 CÁC BẢNG CHÍNH (13 bảng):
 1.  users                - Tài khoản Admin/Manager/Farmer + RBAC
 2.  zones                - 10 khu vực trồng (entity trung tâm)
 3.  user_zone_assignment - Phân công Farmer → Zone (lịch sử)
 4.  growing_cycles       - Chu kỳ trồng/vụ theo Zone
 5.  sensors              - Thiết bị IoT gắn tại Zone
 6.  sensor_readings      - Dữ liệu đo 5 phút/lần (BIGINT PK, ~2.88M/năm)
 7.  irrigation_schedules - Lịch tưới nhỏ giọt theo Zone
 8.  irrigation_logs      - Lịch sử tưới thực tế từng lần
 9.  alerts               - Cảnh báo khi sensor vượt ngưỡng
 10. ai_predictions       - Kết quả AI: bệnh, sản lượng, tối ưu tưới
 11. harvest_records      - Ghi nhận thu hoạch lá nha đam
 12. weather_data         - Dữ liệu thời tiết (dự báo + thực tế)
 13. audit_logs           - Nhật ký thao tác (append-only)


 NGHIỆP VỤ QUAN TRỌNG:
 - Irrigation: lịch auto-adjust theo mưa >10mm hoặc temp >35°C
 - Alerts: ngưỡng nha đam (moisture 50-85%, temp 5-40°C, pH 6-8)
 - Harvest workflow: Farmer ghi → Manager duyệt → vào báo cáo
 - RBAC: Farmer chỉ thấy Zone mình; Manager thấy toàn trang trại
*/


-- ============================================================
-- PHẦN 2: DDL HOÀN CHỈNH (ĐÃ REVIEW + BỔ SUNG)
-- ============================================================


DROP DATABASE IF EXISTS aloe_farm_dashboard;
CREATE DATABASE aloe_farm_dashboard
   DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aloe_farm_dashboard;


-- -----------------------------------------------------------
-- 1. USERS
-- -----------------------------------------------------------
CREATE TABLE users (
   user_id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   user_username           VARCHAR(50)  NOT NULL UNIQUE,
   user_password_hash      VARCHAR(255) NOT NULL,
   user_email              VARCHAR(100) NOT NULL UNIQUE,
   user_full_name          VARCHAR(100) NOT NULL,
   user_role               ENUM('admin','manager','farmer') NOT NULL DEFAULT 'farmer',
   user_status             ENUM('active','locked','inactive') NOT NULL DEFAULT 'active',
   user_failed_login_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
   user_phone              VARCHAR(20),
   user_created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   user_last_login         DATETIME,
   INDEX idx_user_role   (user_role),
   INDEX idx_user_status (user_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 2. ZONES
-- -----------------------------------------------------------
CREATE TABLE zones (
   zone_id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   zone_code            VARCHAR(10)  NOT NULL UNIQUE,
   zone_name            VARCHAR(100) NOT NULL,
   zone_area_m2         DECIMAL(10,2) NOT NULL,
   zone_soil_type       ENUM('loamy','sandy_loam','clay_loam') DEFAULT 'sandy_loam',
   zone_row_count       SMALLINT UNSIGNED,
   zone_plants_per_row  SMALLINT UNSIGNED,
   zone_irrigation_type ENUM('drip','sprinkler') DEFAULT 'drip',
   zone_status          ENUM('active','fallow','harvesting','setup') DEFAULT 'active',
   zone_notes           TEXT,
   zone_created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   CHECK (zone_area_m2 > 0),
   CHECK (zone_row_count IS NULL OR zone_row_count > 0),
   CHECK (zone_plants_per_row IS NULL OR zone_plants_per_row > 0),
   INDEX idx_zone_status (zone_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 3. USER_ZONE_ASSIGNMENT
-- -----------------------------------------------------------
CREATE TABLE user_zone_assignment (
   assign_id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   assign_user_id       INT UNSIGNED NOT NULL,
   assign_zone_id       INT UNSIGNED NOT NULL,
   assign_assigned_by   INT UNSIGNED NOT NULL,
   assign_assigned_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   assign_is_active     TINYINT(1) NOT NULL DEFAULT 1,
   assign_ended_at      DATETIME,
   assign_unassigned_by INT UNSIGNED,
   assign_notes         TEXT,
   assign_active_key    TINYINT(1) GENERATED ALWAYS AS (
       CASE WHEN assign_is_active = 1 THEN 1 ELSE NULL END
   ) STORED,
   UNIQUE KEY uq_assign_active_user_zone (assign_user_id, assign_zone_id, assign_active_key),
   CHECK (assign_is_active IN (0,1)),
   CHECK (
       (assign_is_active = 1 AND assign_ended_at IS NULL AND assign_unassigned_by IS NULL)
       OR
       (assign_is_active = 0 AND assign_ended_at IS NOT NULL AND assign_unassigned_by IS NOT NULL)
   ),
   FOREIGN KEY (assign_user_id)       REFERENCES users(user_id) ON DELETE CASCADE,
   FOREIGN KEY (assign_zone_id)       REFERENCES zones(zone_id) ON DELETE CASCADE,
   FOREIGN KEY (assign_assigned_by)   REFERENCES users(user_id),
   FOREIGN KEY (assign_unassigned_by) REFERENCES users(user_id),
   INDEX idx_assign_zone          (assign_zone_id),
   INDEX idx_assign_active        (assign_is_active),
   INDEX idx_assign_assigned_by   (assign_assigned_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 4. GROWING_CYCLES
-- -----------------------------------------------------------
CREATE TABLE growing_cycles (
   cycle_id                     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   cycle_zone_id                INT UNSIGNED NOT NULL,
   cycle_variety                VARCHAR(100) NOT NULL,
   cycle_planted_date           DATE NOT NULL,
   cycle_expected_first_harvest DATE,
   cycle_plant_density          INT UNSIGNED,
   cycle_target_yield_kg        DECIMAL(10,2),
   cycle_status                 ENUM('growing','harvesting','ended') NOT NULL DEFAULT 'growing',
   cycle_active_key             TINYINT(1) GENERATED ALWAYS AS (
       CASE WHEN cycle_status IN ('growing','harvesting') THEN 1 ELSE NULL END
   ) STORED,
   CHECK (cycle_expected_first_harvest IS NULL OR cycle_expected_first_harvest >= cycle_planted_date),
   CHECK (cycle_plant_density IS NULL OR cycle_plant_density > 0),
   CHECK (cycle_target_yield_kg IS NULL OR cycle_target_yield_kg > 0),
   UNIQUE KEY uq_active_cycle_zone (cycle_zone_id, cycle_active_key),
   FOREIGN KEY (cycle_zone_id) REFERENCES zones(zone_id) ON DELETE CASCADE,
   INDEX idx_cycle_zone   (cycle_zone_id),
   INDEX idx_cycle_status (cycle_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 5. SENSORS
-- -----------------------------------------------------------
CREATE TABLE sensors (
   sensor_id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   sensor_zone_id       INT UNSIGNED NOT NULL,
   sensor_code          VARCHAR(20)  NOT NULL UNIQUE,
   sensor_type          ENUM('soil_moisture','temperature','humidity','ph','ec') NOT NULL,
   sensor_model         VARCHAR(100),
   sensor_unit          VARCHAR(20),
   sensor_min_threshold DECIMAL(8,2),
   sensor_max_threshold DECIMAL(8,2),
   sensor_status        ENUM('active','inactive','error') NOT NULL DEFAULT 'active',
   sensor_installed_at  DATE,
   CHECK (
       sensor_min_threshold IS NULL
       OR sensor_max_threshold IS NULL
       OR sensor_min_threshold < sensor_max_threshold
   ),
   FOREIGN KEY (sensor_zone_id) REFERENCES zones(zone_id) ON DELETE CASCADE,
   INDEX idx_sensor_zone   (sensor_zone_id),
   INDEX idx_sensor_type   (sensor_type),
   INDEX idx_sensor_status (sensor_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 6. SENSOR_READINGS
-- -----------------------------------------------------------
CREATE TABLE sensor_readings (
   reading_id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   reading_sensor_id   INT UNSIGNED NOT NULL,
   reading_value       DECIMAL(8,2) NOT NULL,
   reading_recorded_at DATETIME NOT NULL,
   reading_is_valid    TINYINT(1) NOT NULL DEFAULT 1,
   CHECK (reading_is_valid IN (0,1)),
   UNIQUE KEY uq_sensor_time (reading_sensor_id, reading_recorded_at),
   FOREIGN KEY (reading_sensor_id) REFERENCES sensors(sensor_id) ON DELETE CASCADE,
   INDEX idx_reading_sensor_time (reading_sensor_id, reading_recorded_at),
   INDEX idx_reading_time        (reading_recorded_at),
   INDEX idx_reading_valid       (reading_is_valid)   -- [FIX] thêm index lọc valid readings
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 7. IRRIGATION_SCHEDULES
-- -----------------------------------------------------------
CREATE TABLE irrigation_schedules (
   schedule_id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   schedule_zone_id          INT UNSIGNED NOT NULL,
   schedule_created_by       INT UNSIGNED NOT NULL,
   schedule_name             VARCHAR(100) NOT NULL,
   schedule_cron_expr        VARCHAR(100),
   schedule_duration_minutes SMALLINT UNSIGNED NOT NULL,
   schedule_water_rate_l_m2  DECIMAL(5,2) NOT NULL,
   schedule_is_auto_adjust   TINYINT(1) NOT NULL DEFAULT 1,
   schedule_is_active        TINYINT(1) NOT NULL DEFAULT 1,
   schedule_notes            TEXT,
   CHECK (schedule_duration_minutes > 0),
   CHECK (schedule_water_rate_l_m2 > 0),
   CHECK (schedule_is_auto_adjust IN (0,1)),
   CHECK (schedule_is_active IN (0,1)),
   FOREIGN KEY (schedule_zone_id)    REFERENCES zones(zone_id) ON DELETE CASCADE,
   FOREIGN KEY (schedule_created_by) REFERENCES users(user_id),
   INDEX idx_schedule_zone   (schedule_zone_id),
   INDEX idx_schedule_active (schedule_is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 8. IRRIGATION_LOGS
-- -----------------------------------------------------------
CREATE TABLE irrigation_logs (
   irrlog_id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   irrlog_schedule_id          INT UNSIGNED,
   irrlog_zone_id              INT UNSIGNED NOT NULL,
   irrlog_started_at           DATETIME NOT NULL,
   irrlog_ended_at             DATETIME,
   irrlog_actual_duration_min  SMALLINT UNSIGNED,
   irrlog_water_used_liters    DECIMAL(10,2),
   irrlog_trigger_type         ENUM('manual','auto','scheduled') NOT NULL,
   irrlog_soil_moisture_before DECIMAL(5,2),
   irrlog_soil_moisture_after  DECIMAL(5,2),
   irrlog_status               ENUM('completed','aborted','in_progress') NOT NULL DEFAULT 'in_progress',
   CHECK (irrlog_ended_at IS NULL OR irrlog_ended_at >= irrlog_started_at),
   CHECK (irrlog_actual_duration_min IS NULL OR irrlog_actual_duration_min > 0),
   CHECK (irrlog_water_used_liters IS NULL OR irrlog_water_used_liters >= 0),
   -- [FIX] manual irrigation không bắt buộc schedule; auto/scheduled bắt buộc
   CHECK (
       irrlog_trigger_type = 'manual'
       OR irrlog_schedule_id IS NOT NULL
   ),
   FOREIGN KEY (irrlog_schedule_id) REFERENCES irrigation_schedules(schedule_id),
   FOREIGN KEY (irrlog_zone_id)     REFERENCES zones(zone_id),
   INDEX idx_irrlog_zone_time (irrlog_zone_id, irrlog_started_at),
   INDEX idx_irrlog_status    (irrlog_status)   -- [FIX] thêm index filter status
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 9. ALERTS
-- -----------------------------------------------------------
CREATE TABLE alerts (
   alert_id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   alert_sensor_id       INT UNSIGNED NOT NULL,
   alert_zone_id         INT UNSIGNED NOT NULL,
   alert_type            ENUM('threshold_high','threshold_low','sensor_offline','valve_error') NOT NULL,
   alert_priority        ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
   alert_message         VARCHAR(500) NOT NULL,
   alert_triggered_value DECIMAL(8,2),
   alert_triggered_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   alert_resolved_at     DATETIME,
   alert_is_resolved     TINYINT(1) NOT NULL DEFAULT 0,
   alert_resolved_by     INT UNSIGNED,
   CHECK (alert_is_resolved IN (0,1)),
   CHECK (
       (alert_is_resolved = 0 AND alert_resolved_at IS NULL AND alert_resolved_by IS NULL)
       OR
       (alert_is_resolved = 1 AND alert_resolved_at IS NOT NULL AND alert_resolved_by IS NOT NULL)
   ),
   FOREIGN KEY (alert_sensor_id)  REFERENCES sensors(sensor_id),
   FOREIGN KEY (alert_zone_id)    REFERENCES zones(zone_id),
   FOREIGN KEY (alert_resolved_by) REFERENCES users(user_id),
   INDEX idx_alert_zone_resolved (alert_zone_id, alert_is_resolved),
   INDEX idx_alert_priority      (alert_priority),
   INDEX idx_alert_triggered_at  (alert_triggered_at)   -- [FIX] thêm index thời gian
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 10. AI_PREDICTIONS
-- -----------------------------------------------------------
CREATE TABLE ai_predictions (
   predict_id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   predict_zone_id      INT UNSIGNED NOT NULL,
   predict_cycle_id     INT UNSIGNED,
   predict_model_type   ENUM('disease','yield','irrigation_opt') NOT NULL,
   predict_result_label VARCHAR(100) NOT NULL,
   predict_confidence   DECIMAL(5,4) NOT NULL,
   predict_detail_json  JSON,
   predict_predicted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   CHECK (predict_confidence >= 0 AND predict_confidence <= 1),
   FOREIGN KEY (predict_zone_id)  REFERENCES zones(zone_id) ON DELETE CASCADE,
   FOREIGN KEY (predict_cycle_id) REFERENCES growing_cycles(cycle_id),
   INDEX idx_predict_zone_type  (predict_zone_id, predict_model_type),
   INDEX idx_predict_cycle      (predict_cycle_id),
   INDEX idx_predict_predicted_at (predict_predicted_at)  -- [FIX] thêm index timeline
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 11. HARVEST_RECORDS  [FIX: thêm harvest_status]
-- -----------------------------------------------------------
CREATE TABLE harvest_records (
   harvest_id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   harvest_zone_id          INT UNSIGNED NOT NULL,
   harvest_cycle_id         INT UNSIGNED NOT NULL,
   harvest_recorded_by      INT UNSIGNED NOT NULL,
   harvest_date             DATE NOT NULL,
   harvest_weight_kg        DECIMAL(10,2) NOT NULL,
   harvest_grade            ENUM('A','B','C') NOT NULL,
   harvest_new_shoots_count INT UNSIGNED,
   harvest_notes            TEXT,
   -- [FIX] thêm harvest_status để quản lý workflow phê duyệt rõ ràng
   harvest_status           ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
   harvest_approved_by      INT UNSIGNED,
   harvest_approved_at      DATETIME,
   CHECK (harvest_weight_kg > 0),
   CHECK (
       (harvest_approved_by IS NULL AND harvest_approved_at IS NULL)
       OR
       (harvest_approved_by IS NOT NULL AND harvest_approved_at IS NOT NULL)
   ),
   FOREIGN KEY (harvest_zone_id)     REFERENCES zones(zone_id),
   FOREIGN KEY (harvest_cycle_id)    REFERENCES growing_cycles(cycle_id),
   FOREIGN KEY (harvest_recorded_by) REFERENCES users(user_id),
   FOREIGN KEY (harvest_approved_by) REFERENCES users(user_id),
   INDEX idx_harvest_zone_date  (harvest_zone_id, harvest_date),
   INDEX idx_harvest_cycle      (harvest_cycle_id),
   INDEX idx_harvest_approved   (harvest_approved_by),   -- [FIX] thêm index
   INDEX idx_harvest_status     (harvest_status)         -- [FIX] thêm index
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 12. WEATHER_DATA
-- -----------------------------------------------------------
CREATE TABLE weather_data (
   weather_id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   weather_forecast_date DATE NOT NULL,
   weather_temp_max      DECIMAL(5,2),
   weather_temp_min      DECIMAL(5,2),
   weather_humidity      DECIMAL(5,2),
   weather_rainfall_mm   DECIMAL(6,2) DEFAULT 0.00,
   weather_wind_speed    DECIMAL(5,2),
   weather_condition     VARCHAR(50),
   weather_is_forecast   TINYINT(1) NOT NULL DEFAULT 1,
   weather_fetched_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   CHECK (weather_humidity IS NULL OR (weather_humidity >= 0 AND weather_humidity <= 100)),
   CHECK (weather_rainfall_mm IS NULL OR weather_rainfall_mm >= 0),
   CHECK (weather_is_forecast IN (0,1)),
   CHECK (
       weather_temp_max IS NULL
       OR weather_temp_min IS NULL
       OR weather_temp_max >= weather_temp_min
   ),
   UNIQUE KEY uq_weather_date_type  (weather_forecast_date, weather_is_forecast),
   INDEX idx_weather_is_forecast    (weather_is_forecast)  -- [FIX] thêm index filter forecast/actual
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- -----------------------------------------------------------
-- 13. AUDIT_LOGS
-- -----------------------------------------------------------
CREATE TABLE audit_logs (
   audit_id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   audit_user_id    INT UNSIGNED,            -- NULL = system-triggered event
   audit_action     ENUM('INSERT','UPDATE','DELETE','LOGIN','LOGOUT','EXPORT') NOT NULL,
   audit_table_name VARCHAR(50),
   audit_record_id  BIGINT UNSIGNED,
   audit_old_json   JSON,
   audit_new_json   JSON,
   audit_ip_address VARCHAR(45),
   audit_logged_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   FOREIGN KEY (audit_user_id) REFERENCES users(user_id),
   INDEX idx_audit_user   (audit_user_id),
   INDEX idx_audit_time   (audit_logged_at),
   INDEX idx_audit_action (audit_action),
   INDEX idx_audit_table  (audit_table_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- ============================================================
-- PHẦN 3: MOCK DATA (5.2)
-- ============================================================


-- -----------------------------------------------------------
-- 4.1 USERS (3 admin, 2 manager, 10 farmer)
-- -----------------------------------------------------------
INSERT INTO users (user_username, user_password_hash, user_email, user_full_name, user_role, user_status, user_phone, user_last_login) VALUES
-- Admin
('admin_system',   '$2y$10$Uyw1U2B7UT9MOx6R6kNm5eEgxFqCBF9FHZoU5c/mEvfa0aEpiwbtu',    'admin@aloefarm.vn',        N'Nguyễn Văn Admin',   'admin',   'active', '0901111111', '2025-06-01 08:00:00'),
('admin_it',       '$2y$10$Uyw1U2B7UT9MOx6R6kNm5eEgxFqCBF9FHZoU5c/mEvfa0aEpiwbtu',     'admin.it@aloefarm.vn',     N'Trần Thị IT Admin',  'admin',   'active', '0901111112', '2025-06-01 09:00:00'),
-- Manager
('mgr_nguyen',     '$2y$10$H239FLogDPSbhnOJsFxiSO4005OzpAukv.Y8B1XN0FYg5l5HFeYry',   'manager1@aloefarm.vn',     N'Phạm Quốc Manager',  'manager', 'active', '0902222221', '2025-06-03 07:30:00'),
('mgr_le',         '$2y$10$H239FLogDPSbhnOJsFxiSO4005OzpAukv.Y8B1XN0FYg5l5HFeYry',       'manager2@aloefarm.vn',     N'Lê Thị Hoa Manager', 'manager', 'active', '0902222222', '2025-06-03 07:45:00'),
-- Farmers
('farmer_minh',    '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',       'minh@aloefarm.vn',         N'Nguyễn Văn Minh',    'farmer',  'active', '0903000001', '2025-06-03 06:00:00'),
('farmer_hoa',     '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',        'hoa@aloefarm.vn',          N'Trần Thị Hoa',       'farmer',  'active', '0903000002', '2025-06-03 06:05:00'),
('farmer_tuan',    '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',       'tuan@aloefarm.vn',         N'Lê Văn Tuấn',        'farmer',  'active', '0903000003', '2025-06-02 18:00:00'),
('farmer_linh',    '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',       'linh@aloefarm.vn',         N'Phạm Thị Linh',      'farmer',  'active', '0903000004', '2025-06-03 06:10:00'),
('farmer_duc',     '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',        'duc@aloefarm.vn',          N'Hoàng Văn Đức',      'farmer',  'active', '0903000005', '2025-06-02 17:30:00'),
('farmer_nga',     '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',        'nga@aloefarm.vn',          N'Võ Thị Nga',         'farmer',  'active', '0903000006', '2025-06-03 06:15:00'),
('farmer_binh',    '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',       'binh@aloefarm.vn',         N'Đặng Văn Bình',      'farmer',  'active', '0903000007', '2025-06-02 16:00:00'),
('farmer_lan',     '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',        'lan@aloefarm.vn',          N'Bùi Thị Lan',        'farmer',  'active', '0903000008', '2025-06-03 06:20:00'),
('farmer_hung',    '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',       'hung@aloefarm.vn',         N'Phan Văn Hùng',      'farmer',  'active', '0903000009', '2025-06-03 06:25:00'),
-- Farmer bị locked (test case bất thường)
('farmer_locked',  '$2y$10$5lY8Q5edr.A5Z.9xsDjNR.6DaS2HXMLIkHRss3MTFLKIGCyTyWsaC',     'locked@aloefarm.vn',       N'Trương Thị Khóa',    'farmer',  'locked', '0903000010', NULL);


-- -----------------------------------------------------------
-- 4.2 ZONES (10 zone, ~0.5 ha mỗi zone)
-- -----------------------------------------------------------
INSERT INTO zones (zone_code, zone_name, zone_area_m2, zone_soil_type, zone_row_count, zone_plants_per_row, zone_irrigation_type, zone_status) VALUES
('Z01', N'Khu Bắc 1 – Đất Thịt Nhẹ',   4800.00, 'loamy',      60, 40, 'drip', 'active'),
('Z02', N'Khu Bắc 2 – Đất Cát Pha',     5200.00, 'sandy_loam', 65, 40, 'drip', 'active'),
('Z03', N'Khu Đông 1 – Đất Thịt Nhẹ',  4600.00, 'loamy',      58, 40, 'drip', 'harvesting'),
('Z04', N'Khu Đông 2 – Đất Sét Pha',    5000.00, 'clay_loam',  62, 40, 'drip', 'active'),
('Z05', N'Khu Nam 1 – Đất Cát Pha',     5100.00, 'sandy_loam', 64, 40, 'drip', 'active'),
('Z06', N'Khu Nam 2 – Đất Thịt Nhẹ',   4900.00, 'loamy',      61, 40, 'drip', 'active'),
('Z07', N'Khu Tây 1 – Đất Cát Pha',     5300.00, 'sandy_loam', 66, 40, 'drip', 'active'),
('Z08', N'Khu Tây 2 – Đất Sét Pha',     4700.00, 'clay_loam',  59, 40, 'drip', 'fallow'),
('Z09', N'Khu Trung Tâm – Đất Thịt',    5000.00, 'loamy',      62, 40, 'drip', 'active'),
('Z10', N'Khu Mở Rộng – Đất Cát Pha',  4500.00, 'sandy_loam', 56, 40, 'drip', 'setup');


-- -----------------------------------------------------------
-- 4.3 USER_ZONE_ASSIGNMENT
-- -----------------------------------------------------------
INSERT INTO user_zone_assignment (assign_user_id, assign_zone_id, assign_assigned_by, assign_is_active) VALUES
(5,  1, 3, 1),   -- farmer_minh  → Z01
(5,  2, 3, 1),   -- farmer_minh  → Z02 (phụ trách 2 zone)
(6,  3, 3, 1),   -- farmer_hoa   → Z03
(7,  4, 3, 1),   -- farmer_tuan  → Z04
(8,  5, 3, 1),   -- farmer_linh  → Z05
(9,  6, 4, 1),   -- farmer_duc   → Z06
(10, 7, 4, 1),   -- farmer_nga   → Z07
(11, 8, 4, 1),   -- farmer_binh  → Z08
(12, 9, 4, 1),   -- farmer_lan   → Z09
(13,10, 3, 1);   -- farmer_hung  → Z10


-- -----------------------------------------------------------
-- 4.4 GROWING_CYCLES
-- -----------------------------------------------------------
INSERT INTO growing_cycles (cycle_zone_id, cycle_variety, cycle_planted_date, cycle_expected_first_harvest, cycle_plant_density, cycle_target_yield_kg, cycle_status) VALUES
(1, 'Aloe barbadensis Miller', '2023-01-15', '2024-07-15', 4, 12000.00, 'harvesting'),
(2, 'Aloe barbadensis Miller', '2023-02-01', '2024-08-01', 4, 13000.00, 'harvesting'),
(3, 'Aloe barbadensis Miller', '2022-11-20', '2024-05-20', 4, 11500.00, 'harvesting'),
(4, 'Aloe vera var. chinensis', '2023-03-10', '2024-09-10', 3, 12500.00, 'growing'),
(5, 'Aloe barbadensis Miller', '2023-04-05', '2024-10-05', 4, 12800.00, 'growing'),
(6, 'Aloe barbadensis Miller', '2023-03-20', '2024-09-20', 4, 12200.00, 'growing'),
(7, 'Aloe vera var. chinensis', '2023-05-01', '2024-11-01', 3, 13200.00, 'growing'),
(9, 'Aloe barbadensis Miller', '2023-01-10', '2024-07-10', 4, 12500.00, 'harvesting');


-- -----------------------------------------------------------
-- 4.5 SENSORS (5 loại sensor × 10 zone = ~50 sensors)
-- -----------------------------------------------------------
INSERT INTO sensors (sensor_zone_id, sensor_code, sensor_type, sensor_model, sensor_unit, sensor_min_threshold, sensor_max_threshold, sensor_status, sensor_installed_at) VALUES
-- Zone 1
(1,'Z01-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2023-01-10'),
(1,'Z01-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2023-01-10'),
(1,'Z01-HM-01','humidity',     'DHT22',           '%',     30.00, 90.00, 'active','2023-01-10'),
(1,'Z01-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'active','2023-01-10'),
(1,'Z01-EC-01','ec',           'EC-Sensor-v1',    'mS/cm', 0.50,   3.00, 'active','2023-01-10'),
-- Zone 2
(2,'Z02-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2023-01-20'),
(2,'Z02-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2023-01-20'),
(2,'Z02-HM-01','humidity',     'DHT22',           '%',     30.00, 90.00, 'active','2023-01-20'),
(2,'Z02-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'active','2023-01-20'),
(2,'Z02-EC-01','ec',           'EC-Sensor-v1',    'mS/cm', 0.50,   3.00, 'active','2023-01-20'),
-- Zone 3
(3,'Z03-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2022-11-15'),
(3,'Z03-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2022-11-15'),
(3,'Z03-HM-01','humidity',     'DHT22',           '%',     30.00, 90.00, 'active','2022-11-15'),
(3,'Z03-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'error', '2022-11-15'),  -- sensor lỗi
(3,'Z03-EC-01','ec',           'EC-Sensor-v1',    'mS/cm', 0.50,   3.00, 'active','2022-11-15'),
-- Zone 4
(4,'Z04-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2023-03-05'),
(4,'Z04-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2023-03-05'),
(4,'Z04-HM-01','humidity',     'DHT22',           '%',     30.00, 90.00, 'active','2023-03-05'),
(4,'Z04-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'active','2023-03-05'),
(4,'Z04-EC-01','ec',           'EC-Sensor-v1',    'mS/cm', 0.50,   3.00, 'active','2023-03-05'),
-- Zone 5
(5,'Z05-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2023-04-01'),
(5,'Z05-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2023-04-01'),
(5,'Z05-HM-01','humidity',     'DHT22',           '%',     30.00, 90.00, 'active','2023-04-01'),
(5,'Z05-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'active','2023-04-01'),
(5,'Z05-EC-01','ec',           'EC-Sensor-v1',    'mS/cm', 0.50,   3.00, 'active','2023-04-01'),
-- Zone 6
(6,'Z06-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2023-03-15'),
(6,'Z06-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2023-03-15'),
(6,'Z06-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'active','2023-03-15'),
-- Zone 7
(7,'Z07-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2023-04-25'),
(7,'Z07-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2023-04-25'),
(7,'Z07-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'active','2023-04-25'),
-- Zone 8 (fallow)
(8,'Z08-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'inactive','2023-01-01'),
-- Zone 9
(9,'Z09-SM-01','soil_moisture','SoilMoist-Pro-v2','%',     50.00, 85.00, 'active','2023-01-05'),
(9,'Z09-TM-01','temperature',  'DHT22',           '°C',    5.00,  40.00, 'active','2023-01-05'),
(9,'Z09-PH-01','ph',           'pH-4502C',        'pH',    6.00,   8.00, 'active','2023-01-05'),
-- Zone 10 (setup)
(10,'Z10-SM-01','soil_moisture','SoilMoist-Pro-v2','%',    50.00, 85.00, 'inactive','2025-05-01');


-- -----------------------------------------------------------
-- 4.6 SENSOR_READINGS (dữ liệu 3 ngày gần nhất, mỗi 30 phút – simplified)
-- Bình thường + bất thường (vượt ngưỡng)
-- -----------------------------------------------------------
SET @base = '2025-06-01 06:00:00';


-- Zone 1 – Soil Moisture (sensor_id=1): bình thường 65-72%
INSERT INTO sensor_readings (reading_sensor_id, reading_value, reading_recorded_at, reading_is_valid) VALUES
(1, 68.50, '2025-06-01 06:00:00', 1), (1, 67.80, '2025-06-01 06:30:00', 1),
(1, 66.20, '2025-06-01 07:00:00', 1), (1, 70.10, '2025-06-01 12:00:00', 1),
(1, 71.30, '2025-06-01 18:00:00', 1), (1, 69.50, '2025-06-02 06:00:00', 1),
(1, 72.10, '2025-06-02 12:00:00', 1), (1, 68.90, '2025-06-02 18:00:00', 1),
(1, 70.30, '2025-06-03 06:00:00', 1), (1, 71.80, '2025-06-03 09:00:00', 1),
-- Zone 1 – Temperature (sensor_id=2): bình thường 28-33°C, 1 spike bất thường
(2, 29.50, '2025-06-01 06:00:00', 1), (2, 31.20, '2025-06-01 12:00:00', 1),
(2, 32.80, '2025-06-01 15:00:00', 1), (2, 41.50, '2025-06-01 13:30:00', 1),  -- vượt ngưỡng 40°C
(2, 30.10, '2025-06-02 06:00:00', 1), (2, 32.50, '2025-06-02 12:00:00', 1),
(2, 29.80, '2025-06-03 06:00:00', 1), (2, 31.60, '2025-06-03 09:00:00', 1),
-- Zone 1 – pH (sensor_id=4): bình thường 6.5-7.2, 1 bất thường pH thấp
(4, 6.80, '2025-06-01 06:00:00', 1), (4, 7.10, '2025-06-01 12:00:00', 1),
(4, 6.90, '2025-06-02 06:00:00', 1), (4, 5.80, '2025-06-02 10:00:00', 1),  -- pH thấp
(4, 6.70, '2025-06-03 06:00:00', 1), (4, 7.00, '2025-06-03 09:00:00', 1),
-- Zone 2 – Soil Moisture (sensor_id=6): đang cạn dần, cần tưới
(6, 72.00, '2025-06-01 06:00:00', 1), (6, 68.50, '2025-06-01 12:00:00', 1),
(6, 62.30, '2025-06-01 18:00:00', 1), (6, 58.10, '2025-06-02 06:00:00', 1),
(6, 52.40, '2025-06-02 12:00:00', 1), (6, 47.80, '2025-06-02 18:00:00', 1),  -- dưới 50% → alert
(6, 45.20, '2025-06-03 06:00:00', 1), (6, 43.60, '2025-06-03 09:00:00', 1),  -- tiếp tục cạn
-- Zone 2 – Temperature (sensor_id=7)
(7, 30.20, '2025-06-01 06:00:00', 1), (7, 34.50, '2025-06-01 12:00:00', 1),
(7, 35.80, '2025-06-01 15:00:00', 1), (7, 29.60, '2025-06-02 06:00:00', 1),
(7, 33.20, '2025-06-02 12:00:00', 1), (7, 30.80, '2025-06-03 06:00:00', 1),
-- Zone 3 – Soil Moisture (sensor_id=11): quá ẩm sau mưa
(11, 75.00, '2025-06-01 06:00:00', 1), (11, 80.50, '2025-06-01 10:00:00', 1),
(11, 86.20, '2025-06-01 14:00:00', 1),  -- vượt 85% → alert critical (root rot risk)
(11, 88.50, '2025-06-01 16:00:00', 1),  -- tiếp tục tăng
(11, 82.10, '2025-06-02 06:00:00', 1), (11, 78.30, '2025-06-02 12:00:00', 1),
(11, 74.50, '2025-06-03 06:00:00', 1), (11, 71.20, '2025-06-03 09:00:00', 1),
-- Zone 4 – Soil Moisture (sensor_id=16): bình thường
(16, 65.30, '2025-06-01 06:00:00', 1), (16, 67.80, '2025-06-01 12:00:00', 1),
(16, 70.20, '2025-06-02 06:00:00', 1), (16, 68.50, '2025-06-02 12:00:00', 1),
(16, 66.90, '2025-06-03 06:00:00', 1),
-- Zone 4 – EC (sensor_id=20): EC cao – cảnh báo nhiễm mặn
(20, 2.50, '2025-06-01 06:00:00', 1), (20, 2.80, '2025-06-01 12:00:00', 1),
(20, 3.20, '2025-06-01 18:00:00', 1),  -- vượt 3.0 mS/cm → warning
(20, 3.60, '2025-06-02 06:00:00', 1),  -- tiếp tục tăng
(20, 3.30, '2025-06-03 06:00:00', 1),
-- Zone 5 – Soil Moisture (sensor_id=21): bình thường
(21, 63.50, '2025-06-01 06:00:00', 1), (21, 66.20, '2025-06-01 12:00:00', 1),
(21, 68.90, '2025-06-02 06:00:00', 1), (21, 65.40, '2025-06-02 12:00:00', 1),
(21, 67.10, '2025-06-03 06:00:00', 1),
-- Zone 9 – Soil Moisture (sensor_id=33): bình thường
(33, 69.80, '2025-06-01 06:00:00', 1), (33, 71.20, '2025-06-01 12:00:00', 1),
(33, 68.50, '2025-06-02 06:00:00', 1), (33, 70.30, '2025-06-02 12:00:00', 1),
(33, 72.10, '2025-06-03 06:00:00', 1),
-- Dữ liệu invalid (giá trị bất hợp lý)
(1, 150.00, '2025-06-01 08:00:00', 0),   -- soil_moisture 150% → không hợp lệ
(2, -5.00,  '2025-06-01 08:05:00', 0);   -- nhiệt độ -5°C → không hợp lệ


-- -----------------------------------------------------------
-- 4.7 IRRIGATION_SCHEDULES
-- -----------------------------------------------------------
INSERT INTO irrigation_schedules (schedule_zone_id, schedule_created_by, schedule_name, schedule_cron_expr, schedule_duration_minutes, schedule_water_rate_l_m2, schedule_is_auto_adjust, schedule_is_active) VALUES
(1, 3, N'Z01 – Tưới sáng mùa khô',   '0 6 * * *',  30, 0.55, 1, 1),
(1, 3, N'Z01 – Tưới chiều mùa khô',  '0 16 * * *', 25, 0.45, 1, 1),
(2, 3, N'Z02 – Tưới sáng',           '0 6 * * *',  30, 0.55, 1, 1),
(2, 3, N'Z02 – Tưới chiều',          '0 17 * * *', 25, 0.45, 1, 1),
(3, 3, N'Z03 – Tưới sáng (thu hoạch)','0 6 * * *', 20, 0.40, 1, 1),
(4, 3, N'Z04 – Tưới sáng',           '0 6 * * *',  30, 0.55, 1, 1),
(5, 4, N'Z05 – Tưới sáng',           '0 6 * * *',  30, 0.55, 1, 1),
(6, 4, N'Z06 – Tưới sáng',           '0 6 * * *',  30, 0.50, 1, 1),
(7, 4, N'Z07 – Tưới sáng',           '0 6 * * *',  30, 0.55, 1, 1),
(9, 4, N'Z09 – Tưới sáng',           '0 6 * * *',  30, 0.55, 1, 1);


-- -----------------------------------------------------------
-- 4.8 IRRIGATION_LOGS (lịch sử 7 ngày, case bình thường + bất thường)
-- -----------------------------------------------------------
INSERT INTO irrigation_logs (irrlog_schedule_id, irrlog_zone_id, irrlog_started_at, irrlog_ended_at, irrlog_actual_duration_min, irrlog_water_used_liters, irrlog_trigger_type, irrlog_soil_moisture_before, irrlog_soil_moisture_after, irrlog_status) VALUES
-- Zone 1 – tưới bình thường
(1, 1, '2025-05-28 06:02:00', '2025-05-28 06:32:00', 30, 2640.00, 'scheduled', 62.50, 72.30, 'completed'),
(2, 1, '2025-05-28 16:01:00', '2025-05-28 16:26:00', 25, 2160.00, 'scheduled', 68.10, 76.50, 'completed'),
(1, 1, '2025-05-29 06:00:00', '2025-05-29 06:30:00', 30, 2640.00, 'scheduled', 64.20, 73.80, 'completed'),
(1, 1, '2025-05-30 06:01:00', '2025-05-30 06:31:00', 30, 2640.00, 'scheduled', 63.70, 72.90, 'completed'),
(1, 1, '2025-06-01 06:00:00', '2025-06-01 06:30:00', 30, 2640.00, 'scheduled', 65.40, 74.10, 'completed'),
(2, 1, '2025-06-01 16:00:00', '2025-06-01 16:25:00', 25, 2160.00, 'scheduled', 70.20, 78.60, 'completed'),
(1, 1, '2025-06-02 06:00:00', '2025-06-02 06:30:00', 30, 2640.00, 'scheduled', 67.30, 76.80, 'completed'),
-- Zone 2 – tưới, nhưng moisture vẫn cạn → auto trigger tưới thêm
(3, 2, '2025-05-28 06:03:00', '2025-05-28 06:33:00', 30, 2760.00, 'scheduled', 70.20, 79.50, 'completed'),
(4, 2, '2025-05-29 17:00:00', '2025-05-29 17:25:00', 25, 2300.00, 'scheduled', 66.50, 75.10, 'completed'),
(3, 2, '2025-05-30 06:00:00', '2025-05-30 06:30:00', 30, 2760.00, 'scheduled', 68.30, 77.90, 'completed'),
(3, 2, '2025-06-01 06:01:00', '2025-06-01 06:31:00', 30, 2760.00, 'scheduled', 64.80, 73.60, 'completed'),
-- Zone 2 – auto trigger lúc 14h vì moisture < 55%
(3, 2, '2025-06-01 14:00:00', '2025-06-01 14:30:00', 30, 2760.00, 'auto', 52.40, 63.20, 'completed'),
-- Zone 2 – lần tưới bị abort
(3, 2, '2025-06-02 06:00:00', NULL, NULL, NULL, 'scheduled', 48.90, NULL, 'aborted'),
-- Zone 2 – manual tưới sau abort
(NULL, 2, '2025-06-02 07:30:00', '2025-06-02 08:10:00', 40, 3680.00, 'manual', 45.20, 62.80, 'completed'),
-- Zone 3 – giảm tưới vì moisture cao
(5, 3, '2025-06-01 06:00:00', '2025-06-01 06:12:00', 12, 984.00,  'scheduled', 78.50, 82.30, 'completed'),
-- Zone 3 – skip vì moisture > 85%
(5, 3, '2025-06-02 06:00:00', '2025-06-02 06:05:00',  5, 410.00,  'auto',      85.20, 85.80, 'aborted'),  -- abort vì đã đủ ẩm
-- Zone 4 tưới bình thường
(6, 4, '2025-06-01 06:02:00', '2025-06-01 06:32:00', 30, 2750.00, 'scheduled', 63.50, 72.80, 'completed'),
(6, 4, '2025-06-02 06:01:00', '2025-06-02 06:31:00', 30, 2750.00, 'scheduled', 65.20, 74.30, 'completed'),
-- Zone 5 tưới bình thường
(7, 5, '2025-06-01 06:03:00', '2025-06-01 06:33:00', 30, 2805.00, 'scheduled', 64.50, 73.90, 'completed'),
(7, 5, '2025-06-02 06:02:00', '2025-06-02 06:32:00', 30, 2805.00, 'scheduled', 66.80, 75.50, 'completed'),
-- Zone 9 tưới
(10, 9, '2025-06-01 06:04:00', '2025-06-01 06:34:00', 30, 2750.00, 'scheduled', 67.20, 76.40, 'completed'),
(10, 9, '2025-06-02 06:03:00', '2025-06-02 06:33:00', 30, 2750.00, 'scheduled', 69.50, 78.20, 'completed'),
-- Đang tưới (in_progress – real-time)
(1, 1, '2025-06-03 06:00:00', NULL, NULL, NULL, 'scheduled', 68.90, NULL, 'in_progress');


-- -----------------------------------------------------------
-- 4.9 ALERTS (manual insert – bổ sung ngoài trigger)
-- Một số alert thủ công để đảm bảo demo data đa dạng
-- -----------------------------------------------------------
-- Alert đã resolve
INSERT INTO alerts (alert_sensor_id, alert_zone_id, alert_type, alert_priority, alert_message, alert_triggered_value, alert_triggered_at, alert_resolved_at, alert_is_resolved, alert_resolved_by) VALUES
(2,  1, 'threshold_high', 'warning',  N'Nhiệt độ Z01 vượt 40°C: 41.5°C lúc 2025-06-01 13:30', 41.50, '2025-06-01 13:30:00', '2025-06-01 14:15:00', 1, 3),
(6,  2, 'threshold_low',  'critical', N'Độ ẩm Z02 xuống dưới 50%: 47.8% – Cần tưới khẩn',   47.80, '2025-06-02 18:00:00', '2025-06-02 19:30:00', 1, 3),
(4,  1, 'threshold_low',  'warning',  N'pH Z01 thấp: 5.8 (min 6.0) – Kiểm tra đất',          5.80,  '2025-06-02 10:00:00', '2025-06-02 16:00:00', 1, 4),
(11, 3, 'threshold_high', 'critical', N'Độ ẩm Z03 vượt 85%: 86.2% – Nguy cơ thối gốc cao',  86.20, '2025-06-01 14:00:00', '2025-06-01 17:30:00', 1, 3);


-- Alert chưa resolve (để hiển thị trên dashboard)
INSERT INTO alerts (alert_sensor_id, alert_zone_id, alert_type, alert_priority, alert_message, alert_triggered_value, alert_triggered_at, alert_is_resolved) VALUES
(6,  2, 'threshold_low',  'critical', N'Độ ẩm Z02 CRITICAL: 43.6% – Van tưới cần kiểm tra',  43.60, '2025-06-03 09:00:00', 0),
(11, 3, 'threshold_high', 'critical', N'Độ ẩm Z03 tiếp tục cao: 88.5% – Root Rot Risk!',     88.50, '2025-06-01 16:00:00', 0),
(20, 4, 'threshold_high', 'warning',  N'EC Z04 cao: 3.6 mS/cm – Nguy cơ nhiễm mặn',          3.60,  '2025-06-02 06:00:00', 0),
(14, 3, 'sensor_offline', 'warning',  N'Sensor pH Z03 (Z03-PH-01) offline/lỗi',               NULL,  '2025-06-01 10:00:00', 0),
(2,  1, 'threshold_high', 'warning',  N'Nhiệt độ Z01 gần ngưỡng: 38.5°C',                    38.50, '2025-06-03 13:00:00', 0);


-- -----------------------------------------------------------
-- 4.10 AI_PREDICTIONS
-- -----------------------------------------------------------
INSERT INTO ai_predictions (predict_zone_id, predict_cycle_id, predict_model_type, predict_result_label, predict_confidence, predict_detail_json, predict_predicted_at) VALUES
-- Disease detection
(3, 3, 'disease',       'Root Rot Detected',       0.8920, '{"disease":"root_rot","affected_area_pct":15,"recommendation":"Reduce irrigation, check drainage"}', '2025-06-01 15:00:00'),
(1, 1, 'disease',       'Healthy – No Disease',    0.9450, '{"disease":"none","health_score":94}',                                                              '2025-06-03 06:30:00'),
(2, 2, 'disease',       'Mealybug Risk – Low',     0.6300, '{"disease":"mealybug","risk":"low","recommendation":"Monitor weekly"}',                             '2025-06-03 06:31:00'),
(4, 4, 'disease',       'Leaf Spot – Moderate',    0.7650, '{"disease":"leaf_spot","severity":"moderate","affected_leaves":12}',                                '2025-06-02 06:30:00'),
(5, 5, 'disease',       'Healthy – No Disease',    0.9120, '{"disease":"none","health_score":91}',                                                              '2025-06-03 06:32:00'),
-- Yield prediction
(1, 1, 'yield',         'High Yield – Grade A 83%', 0.8750, '{"predicted_yield_kg":9850,"grade_a_pct":83,"grade_b_pct":13,"grade_c_pct":4}',                   '2025-06-01 07:00:00'),
(2, 2, 'yield',         'Medium Yield – Grade A 75%',0.7900,'{"predicted_yield_kg":9200,"grade_a_pct":75,"grade_b_pct":19,"grade_c_pct":6}',                   '2025-06-01 07:01:00'),
(3, 3, 'yield',         'Low Yield – Root Rot Impact',0.8200,'{"predicted_yield_kg":7500,"grade_a_pct":60,"impact":"root_rot"}',                                '2025-06-01 15:30:00'),
(9, 8, 'yield',         'High Yield – Grade A 85%', 0.9000, '{"predicted_yield_kg":10200,"grade_a_pct":85,"grade_b_pct":11,"grade_c_pct":4}',                  '2025-06-01 07:02:00'),
-- Irrigation optimization
(2, 2, 'irrigation_opt','Tăng tần suất – Moisture thấp', 0.8500, '{"current_freq":"2x/day","recommended":"3x/day","water_saving_pct":8}',                      '2025-06-03 08:00:00'),
(3, 3, 'irrigation_opt','Giảm tưới – Moisture quá cao',  0.9200, '{"current_freq":"2x/day","recommended":"0x 3 days","reason":"root_rot_risk"}',                '2025-06-01 16:00:00'),
(1, 1, 'irrigation_opt','Lịch tưới tối ưu – giảm 18%',   0.8800, '{"current_water_l_m2":1.0,"recommended":0.82,"saving_pct":18}',                              '2025-06-03 06:35:00');


-- -----------------------------------------------------------
-- 4.11 HARVEST_RECORDS (4 tháng lịch sử)
-- -----------------------------------------------------------
INSERT INTO harvest_records (harvest_zone_id, harvest_cycle_id, harvest_recorded_by, harvest_date, harvest_weight_kg, harvest_grade, harvest_new_shoots_count, harvest_notes, harvest_status, harvest_approved_by, harvest_approved_at) VALUES
-- Zone 1 – approved
(1,1, 5, '2025-02-15', 980.50, 'A', 45, N'Lá đạt chất lượng tốt, nhiều chồi mới',   'approved', 3, '2025-02-16 09:00:00'),
(1,1, 5, '2025-04-01', 1020.00,'A', 52, N'Thu hoạch đợt 2, lá Grade A tốt',          'approved', 3, '2025-04-02 09:00:00'),
(1,1, 5, '2025-05-15', 1055.50,'A', 48, N'Đợt 3 – năng suất tăng',                   'approved', 3, '2025-05-16 10:00:00'),
(1,1, 5, '2025-06-01', 1030.00,'B', 42, N'Đợt 4 – một số lá bị đốm nhẹ',             'approved', 3, '2025-06-02 09:00:00'),
-- Zone 2 – approved
(2,2, 5, '2025-03-01', 960.00, 'A', 40, N'Chu kỳ 2 lần đầu, chất lượng khá',        'approved', 3, '2025-03-02 09:00:00'),
(2,2, 5, '2025-04-15', 990.50, 'A', 43, N'Đợt 2, ổn định',                           'approved', 3, '2025-04-16 09:00:00'),
(2,2, 5, '2025-05-30', 850.00, 'B', 38, N'Đợt 3 – moisture thấp ảnh hưởng chất lượng','approved',3, '2025-05-31 10:00:00'),
-- Zone 3 – approved + pending
(3,3, 6, '2025-01-20', 1100.00,'A', 55, N'Thu hoạch tốt trước khi phát sinh root rot', 'approved', 4, '2025-01-21 09:00:00'),
(3,3, 6, '2025-03-05', 1050.00,'A', 50, N'Thu hoạch đợt 2',                            'approved', 4, '2025-03-06 09:00:00'),
(3,3, 6, '2025-05-10', 820.00, 'B', 35, N'Bị ảnh hưởng bởi root rot – giảm năng suất','approved', 4, '2025-05-11 09:00:00'),
(3,3, 6, '2025-06-02', 760.00, 'C', 28, N'Nhiều lá bị hỏng do độ ẩm quá cao',        'pending',  NULL, NULL),  -- chờ duyệt
-- Zone 9 – approved
(9,8, 12,'2025-02-20', 1050.00,'A', 50, N'Z09 – năng suất cao nhất trang trại',       'approved', 4, '2025-02-21 09:00:00'),
(9,8, 12,'2025-04-10', 1100.00,'A', 55, N'Đợt 2 chất lượng xuất sắc',                 'approved', 4, '2025-04-11 09:00:00'),
(9,8, 12,'2025-06-01', 1080.00,'A', 53, N'Đợt 3 – duy trì chất lượng cao',            'pending',  NULL, NULL),  -- chờ duyệt
-- Zone 4 – 1 bản ghi chờ duyệt
(4,4, 7, '2025-06-02', 780.00, 'B', 30, N'Thu hoạch sớm do leaf spot',                'pending',  NULL, NULL);


-- -----------------------------------------------------------
-- 4.12 WEATHER_DATA (7 ngày dự báo + 7 ngày thực tế)
-- -----------------------------------------------------------
INSERT INTO weather_data (weather_forecast_date, weather_temp_max, weather_temp_min, weather_humidity, weather_rainfall_mm, weather_wind_speed, weather_condition, weather_is_forecast) VALUES
-- Dự báo (is_forecast=1)
('2025-06-03', 34.5, 26.0, 72.0, 5.0,  12.0, N'Nắng nhẹ, có mây',   1),
('2025-06-04', 33.0, 25.5, 75.0, 8.0,  10.0, N'Có mây, khả năng mưa', 1),
('2025-06-05', 30.0, 24.0, 82.0, 25.0, 15.0, N'Mưa vừa',             1),  -- mưa lớn → hoãn tưới
('2025-06-06', 28.5, 23.0, 88.0, 40.0, 18.0, N'Mưa to',              1),  -- mưa > 10mm → auto skip irrigation
('2025-06-07', 32.0, 25.0, 78.0, 3.0,  10.0, N'Nắng sau mưa',        1),
('2025-06-08', 35.0, 26.5, 68.0, 0.0,  8.0,  N'Nắng nóng',           1),
('2025-06-09', 36.5, 27.0, 65.0, 0.0,  7.0,  N'Nắng nóng, khô',      1),  -- nhiệt cao → tăng tưới
-- Thực tế đã qua (is_forecast=0)
('2025-05-28', 33.5, 25.5, 70.0, 2.0,  10.0, N'Nắng nhẹ',            0),
('2025-05-29', 34.0, 26.0, 68.0, 0.0,  9.0,  N'Nắng đẹp',            0),
('2025-05-30', 35.5, 27.0, 65.0, 0.0,  8.0,  N'Nắng nóng',           0),
('2025-05-31', 36.0, 27.5, 63.0, 0.0,  7.0,  N'Nắng nóng',           0),
('2025-06-01', 34.0, 25.5, 71.0, 6.0,  11.0, N'Nắng, chiều có mây',  0),
('2025-06-02', 32.0, 24.5, 78.0, 15.0, 14.0, N'Mưa buổi chiều',      0),
('2025-06-03', 33.0, 25.0, 74.0, 5.0,  12.0, N'Nắng nhẹ',            0);


-- -----------------------------------------------------------
-- 4.13 AUDIT_LOGS (các thao tác quan trọng)
-- -----------------------------------------------------------
INSERT INTO audit_logs (audit_user_id, audit_action, audit_table_name, audit_record_id, audit_new_json, audit_ip_address, audit_logged_at) VALUES
(1, 'INSERT', 'zones',  1, '{"zone_code":"Z01","zone_name":"Khu Bắc 1"}', '192.168.1.10', '2023-01-01 08:00:00'),
(3, 'LOGIN',  NULL,     NULL, NULL, '192.168.1.20', '2025-06-03 07:30:00'),
(4, 'LOGIN',  NULL,     NULL, NULL, '192.168.1.21', '2025-06-03 07:45:00'),
(5, 'LOGIN',  NULL,     NULL, NULL, '10.0.0.5',     '2025-06-03 06:00:00'),
(3, 'UPDATE', 'irrigation_schedules', 1, '{"schedule_is_active":0}', '192.168.1.20', '2025-06-02 10:00:00'),
(3, 'INSERT', 'harvest_records',    14, '{"harvest_zone_id":9,"harvest_weight_kg":1080}', '192.168.1.20', '2025-06-01 18:00:00'),
(4, 'UPDATE', 'alerts',              1, '{"alert_is_resolved":1}', '192.168.1.21', '2025-06-01 14:15:00'),
(3, 'UPDATE', 'harvest_records',    12, '{"harvest_status":"approved"}', '192.168.1.20', '2025-02-21 09:00:00'),
(1, 'UPDATE', 'users',              14, '{"user_status":"locked"}', '192.168.1.10', '2025-05-01 09:00:00'),
(3, 'EXPORT', NULL,                 NULL, '{"report":"monthly","month":"2025-05"}', '192.168.1.20', '2025-06-01 09:00:00');


-- -----------------------------------------------------------
-- VIEWS (BQ-21 Zone Health Summary)
-- -----------------------------------------------------------
CREATE OR REPLACE VIEW vw_zone_health_summary AS
SELECT z.zone_id,
       z.zone_code,
       z.zone_name,
       z.zone_status,
       ROUND(AVG(CASE WHEN s.sensor_type = 'soil_moisture' THEN sr.reading_value END), 2) AS avg_soil_moisture,
       COUNT(DISTINCT CASE WHEN a.alert_is_resolved = 0 THEN a.alert_id END) AS unresolved_alerts,
       COUNT(DISTINCT CASE WHEN s.sensor_status IN ('inactive','error') THEN s.sensor_id END) AS faulty_sensors
FROM zones z
LEFT JOIN sensors s ON z.zone_id = s.sensor_zone_id
LEFT JOIN sensor_readings sr
       ON s.sensor_id = sr.reading_sensor_id
      AND sr.reading_is_valid = 1
LEFT JOIN alerts a ON z.zone_id = a.alert_zone_id
GROUP BY z.zone_id, z.zone_code, z.zone_name, z.zone_status;


-- -----------------------------------------------------------
-- STORED PROCEDURES (BQ-22 Farmer dashboard)
-- -----------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_farmer_zone_dashboard;
DELIMITER $$
CREATE PROCEDURE sp_farmer_zone_dashboard(IN p_farmer_id INT)
BEGIN
    SELECT z.zone_code, z.zone_name, z.zone_status,
           COUNT(DISTINCT a.alert_id) AS unresolved_alerts,
           COUNT(DISTINCT s.sensor_id) AS total_sensors
    FROM user_zone_assignment uza
    JOIN zones z ON uza.assign_zone_id = z.zone_id
    LEFT JOIN sensors s ON z.zone_id = s.sensor_zone_id
    LEFT JOIN alerts a
           ON z.zone_id = a.alert_zone_id
          AND a.alert_is_resolved = 0
    WHERE uza.assign_user_id = p_farmer_id
      AND uza.assign_is_active = 1
    GROUP BY z.zone_id, z.zone_code, z.zone_name, z.zone_status
    ORDER BY z.zone_code;
END$$
DELIMITER ;


-- -----------------------------------------------------------
-- TRIGGERS (BQ-23 Auto alert on threshold breach)
-- -----------------------------------------------------------
DROP TRIGGER IF EXISTS trg_create_alert_after_sensor_reading;
DELIMITER $$
CREATE TRIGGER trg_create_alert_after_sensor_reading
AFTER INSERT ON sensor_readings
FOR EACH ROW
BEGIN
    DECLARE v_min DECIMAL(8,2);
    DECLARE v_max DECIMAL(8,2);
    DECLARE v_zone_id INT UNSIGNED;
    DECLARE v_sensor_type VARCHAR(30);

    SELECT sensor_min_threshold, sensor_max_threshold, sensor_zone_id, sensor_type
    INTO v_min, v_max, v_zone_id, v_sensor_type
    FROM sensors
    WHERE sensor_id = NEW.reading_sensor_id;

    IF NEW.reading_is_valid = 1 AND v_max IS NOT NULL AND NEW.reading_value > v_max THEN
        INSERT INTO alerts (
            alert_sensor_id, alert_zone_id, alert_type, alert_priority,
            alert_message, alert_triggered_value, alert_triggered_at, alert_is_resolved
        )
        VALUES (
            NEW.reading_sensor_id, v_zone_id, 'threshold_high', 'warning',
            CONCAT(v_sensor_type, ' vượt ngưỡng cao: ', NEW.reading_value),
            NEW.reading_value, NEW.reading_recorded_at, 0
        );
    END IF;

    IF NEW.reading_is_valid = 1 AND v_min IS NOT NULL AND NEW.reading_value < v_min THEN
        INSERT INTO alerts (
            alert_sensor_id, alert_zone_id, alert_type, alert_priority,
            alert_message, alert_triggered_value, alert_triggered_at, alert_is_resolved
        )
        VALUES (
            NEW.reading_sensor_id, v_zone_id, 'threshold_low', 'critical',
            CONCAT(v_sensor_type, ' dưới ngưỡng thấp: ', NEW.reading_value),
            NEW.reading_value, NEW.reading_recorded_at, 0
        );
    END IF;
END$$
DELIMITER ;



