<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/audit.php';

$user = current_user();
if ($user) {
    $userId = (int)$user['user_id'];
    audit_log($conn, $userId, 'LOGOUT', 'users', (string)$userId, [
        'username' => $user['username'],
        'ip' => client_ip(),
    ]);
}

$wantsJson = isset($_GET['format']) && $_GET['format'] === 'json'
    || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');

auth_destroy_session();

if ($wantsJson) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Location: login.php');
exit;
