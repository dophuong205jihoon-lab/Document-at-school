<div class="card mb-0 dash-dry-zone-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Zone khô — ưu tiên tưới</span>
        <span class="card-head-right">
            <?php if ($dryZones): echo dash_meta(count($dryZones) . ' zone'); endif; ?>
            <?php echo bq_tag('BQ-11'); ?>
        </span>
    </div>
    <?php echo ui_filter_bar_open(); ?>
        <?php echo ui_filter_search('Tìm kiếm', 'Mã zone, tên khu…'); ?>
    <?php echo ui_filter_bar_close(); ?>
    <?php if (!$dryZones): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Không có zone nào có độ ẩm TB dưới 60% (7 ngày gần nhất).</p>
    <?php else: ?>
        <div class="dash-dry-zone-grid">
            <?php foreach ($dryZones as $i => $z): ?>
                <?php
                $avg = (float)($z['avg_soil_moisture'] ?? 0);
                $min = (float)($z['min_soil_moisture'] ?? 0);
                $moistCls = soil_moisture_level_class($avg);
                $search = strtolower(($z['zone_code'] ?? '') . ' ' . ($z['zone_name'] ?? ''));
                ?>
                <article class="dash-dry-zone-card" data-filter-row data-search="<?php echo e($search); ?>">
                    <div class="dash-dry-zone-head">
                        <div>
                            <div class="dash-dry-zone-code"><?php echo e($z['zone_code']); ?></div>
                            <div class="dash-dry-zone-name"><?php echo e($z['zone_name']); ?></div>
                        </div>
                        <?php if ($i === 0): ?>
                            <span class="dash-dry-zone-priority">Ưu tiên</span>
                        <?php endif; ?>
                    </div>
                    <div class="dash-dry-zone-avg <?php echo e($moistCls); ?>">
                        <?php echo e(number_format($avg, 2)); ?>%
                        <span>TB độ ẩm</span>
                    </div>
                    <div class="dash-dry-zone-meta">
                        <div><span>Thấp nhất</span><strong class="<?php echo e($moistCls); ?>"><?php echo e(number_format($min, 2)); ?>%</strong></div>
                        <div><span>Số đo</span><strong><?php echo e((string)($z['total_readings'] ?? 0)); ?></strong></div>
                    </div>
                    <div class="dash-dry-zone-bar" role="presentation">
                        <div class="dash-dry-zone-bar-fill <?php echo e($moistCls); ?>" style="width:<?php echo e((string)min(100, max(0, $avg))); ?>%"></div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả.</p>
</div>
