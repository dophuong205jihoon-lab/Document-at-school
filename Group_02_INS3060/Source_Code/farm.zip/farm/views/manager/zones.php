    <div class="card-head">
        <span class="card-title">Sensor lỗi / offline</span>
        <?php echo bq_tag('BQ-04'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Trạng thái</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="error">error</option>
                <option value="inactive">inactive</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Mã sensor, zone…">
        </label>
    </div>
    <div class="tbl-wrap">
        <table class="dtbl">
            <thead>
            <tr><th>Sensor</th><th>Loại</th><th>Trạng thái</th><th>Zone</th><th>Tên khu</th></tr>
            </thead>
            <tbody>
            <?php if (!$faultySensors): ?>
                <tr><td colspan="5" class="muted">Không có sensor lỗi hoặc inactive.</td></tr>
            <?php else: ?>
                <?php foreach ($faultySensors as $s): ?>
                    <?php
                    $st = $s['sensor_status'] ?? '';
                    $search = strtolower(
                        ($s['sensor_code'] ?? '') . ' ' . ($s['sensor_type'] ?? '') . ' '
                        . ($s['zone_code'] ?? '') . ' ' . ($s['zone_name'] ?? '')
                    );
                    ?>
                    <tr data-filter-row data-role="<?php echo e($st); ?>" data-search="<?php echo e($search); ?>">
                        <td class="mono"><strong><?php echo e($s['sensor_code']); ?></strong></td>
                        <td><?php echo e($s['sensor_type']); ?></td>
                        <td><?php echo role_badge($st); ?></td>
                        <td><?php echo e($s['zone_code']); ?></td>
                        <td><?php echo e($s['zone_name']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả.</p>
</div>

<div class="card mb-0" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Danh sách zone</span>
        <?php echo bq_tag('BQ-02'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Trạng thái</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="active">active</option>
                <option value="harvesting">harvesting</option>
                <option value="fallow">fallow</option>
                <option value="setup">setup</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input">
        </label>
    </div>
    <div class="dash-zone-map">
        <?php foreach ($zones as $z): ?>
            <?php
            $st = $z['zone_status'] ?? 'active';
            $search = strtolower(($z['zone_code'] ?? '') . ' ' . ($z['zone_name'] ?? ''));
            ?>
            <article class="dash-zone-tile dash-zone-tile--<?php echo e($st); ?>"
                     data-filter-row data-role="<?php echo e($st); ?>" data-search="<?php echo e($search); ?>">
                <div class="dash-zone-tile-code"><?php echo e($z['zone_code']); ?></div>
                <div class="dash-zone-tile-name"><?php echo e($z['zone_name']); ?></div>
                <div class="dash-zone-tile-meta">
                    <span><?php echo e((string)$z['zone_area_m2']); ?> m²</span>
                    <span><?php echo e($z['zone_soil_type']); ?></span>
                </div>
                <?php echo role_badge($st); ?>
            </article>
        <?php endforeach; ?>
    </div>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả.</p>
</div>

<div class="card mb-0" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Phân công farmer → zone</span>
        <?php echo bq_tag('BQ-03'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input">
        </label>
    </div>
    <div class="tbl-wrap">
        <table class="dtbl">
            <thead>
            <tr><th>Farmer</th><th>Zone</th><th>Tên khu</th><th>Phân công</th></tr>
            </thead>
            <tbody>
            <?php if (!$assignments): ?>
                <tr><td colspan="4" class="muted">Không có dữ liệu.</td></tr>
            <?php else: ?>
                <?php foreach ($assignments as $a): ?>
                    <?php
                    $search = strtolower(($a['farmer_name'] ?? '') . ' ' . ($a['zone_code'] ?? '') . ' ' . ($a['zone_name'] ?? ''));
                    ?>
                    <tr data-filter-row data-search="<?php echo e($search); ?>">
                        <td><strong><?php echo e($a['farmer_name']); ?></strong></td>
                        <td><?php echo e($a['zone_code']); ?></td>
                        <td><?php echo e($a['zone_name']); ?></td>
                        <td><?php echo fmt_dt($a['assign_assigned_at'] ?? null); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả.</p>
</div>
