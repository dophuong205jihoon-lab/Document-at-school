<?php if (!empty($_GET['harvest_ok'])): ?>
<p class="dash-harvest-flash dash-harvest-flash--ok">Đã duyệt thu hoạch. <?php echo bq_tag('BQ-24'); ?></p>
<?php elseif (!empty($_GET['harvest_err'])): ?>
<p class="dash-harvest-flash dash-harvest-flash--err"><?php echo e((string)$_GET['harvest_err']); ?></p>
<?php endif; ?>

<div class="card mb-0 dash-harvest-pending-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Thu hoạch chờ duyệt</span>
        <span class="card-head-right">
            <?php if ($pendingHarvests): echo dash_meta(count($pendingHarvests) . ' bản ghi'); endif; ?>
            <?php echo bq_tag('BQ-08'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Hạng</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Zone, farmer, ghi chú…">
        </label>
    </div>
    <?php if (!$pendingHarvests): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Không có thu hoạch chờ duyệt.</p>
    <?php else: ?>
        <div class="dash-harvest-queue">
            <?php foreach ($pendingHarvests as $h): ?>
                <?php
                $grade = (string)($h['harvest_grade'] ?? '');
                $search = strtolower(
                    ($h['zone_code'] ?? '') . ' ' . ($h['zone_name'] ?? '') . ' '
                    . ($h['recorded_by'] ?? '') . ' ' . ($h['harvest_notes'] ?? '')
                );
                $notes = trim((string)($h['harvest_notes'] ?? ''));
                ?>
                <article class="dash-harvest-queue-item" data-filter-row
                         data-role="<?php echo e($grade); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-harvest-queue-head">
                        <div>
                            <span class="dash-harvest-queue-zone"><?php echo e($h['zone_code']); ?></span>
                            <span class="dash-harvest-queue-zone-name"><?php echo e($h['zone_name']); ?></span>
                        </div>
                        <div class="dash-harvest-queue-badges">
                            <?php echo role_badge('pending'); ?>
                            <?php if ($grade !== ''): ?>
                                <?php echo role_badge($grade); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="dash-harvest-queue-metrics">
                        <div><span>Ngày thu</span><strong><?php echo fmt_dt($h['harvest_date'] ?? null); ?></strong></div>
                        <div><span>Khối lượng</span><strong><?php echo e(number_format((float)($h['harvest_weight_kg'] ?? 0), 2)); ?> kg</strong></div>
                        <div><span>Ghi bởi</span><strong><?php echo e($h['recorded_by']); ?></strong></div>
                    </div>
                    <?php if ($notes !== ''): ?>
                        <p class="dash-harvest-queue-notes"><?php echo e($notes); ?></p>
                    <?php endif; ?>
                    <div class="dash-harvest-queue-foot">
                        <span class="mono">#<?php echo e((string)$h['harvest_id']); ?></span>
                        <?php if (rbac_can('harvest.approve')): ?>
                            <form method="post" class="dash-harvest-approve-form">
                                <input type="hidden" name="harvest_approve" value="1">
                                <input type="hidden" name="harvest_id" value="<?php echo e((string)$h['harvest_id']); ?>">
                                <button type="submit" class="btn btn-primary btn-sm">Duyệt</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>

<div class="card mb-0 dash-harvest-leader-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Xếp hạng thu hoạch</span>
        <span class="card-head-right">
            <?php if ($harvestPerformance): echo dash_meta(count($harvestPerformance) . ' zone'); endif; ?>
            <?php echo bq_tag('BQ-18'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Mã zone, tên khu…">
        </label>
    </div>
    <?php if (!$harvestPerformance): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có thu hoạch approved.</p>
    <?php else: ?>
        <ol class="dash-harvest-leaderboard">
            <?php foreach ($harvestPerformance as $rank => $row): ?>
                <?php
                $pos = $rank + 1;
                $totalKg = (float)($row['total_kg'] ?? 0);
                $barPct = $harvestKgMax > 0 ? round(($totalKg / $harvestKgMax) * 100, 1) : 0;
                $times = (int)($row['harvest_times'] ?? 0);
                $gradeA = (int)($row['grade_a_count'] ?? 0);
                $search = strtolower(($row['zone_code'] ?? '') . ' ' . ($row['zone_name'] ?? ''));
                $rankClass = $pos <= 3 ? ' dash-harvest-rank--top' . $pos : '';
                ?>
                <li class="dash-harvest-rank<?php echo e($rankClass); ?>" data-filter-row data-search="<?php echo e($search); ?>">
                    <div class="dash-harvest-rank-pos"><?php echo e((string)$pos); ?></div>
                    <div class="dash-harvest-rank-body">
                        <div class="dash-harvest-rank-head">
                            <div>
                                <span class="dash-harvest-rank-zone"><?php echo e($row['zone_code']); ?></span>
                                <span class="dash-harvest-rank-name"><?php echo e($row['zone_name']); ?></span>
                            </div>
                            <div class="dash-harvest-rank-kg">
                                <?php echo e(number_format($totalKg, 2)); ?> <span>kg</span>
                            </div>
                        </div>
                        <div class="dash-harvest-rank-bar" role="presentation">
                            <div class="dash-harvest-rank-bar-fill" style="width:<?php echo e((string)$barPct); ?>%"></div>
                        </div>
                        <div class="dash-harvest-rank-meta">
                            <span><?php echo e((string)$times); ?> lần thu</span>
                            <span>TB <?php echo e(number_format((float)($row['avg_kg'] ?? 0), 2)); ?> kg</span>
                            <span>Grade A: <strong><?php echo e((string)$gradeA); ?></strong></span>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ol>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>

<div class="card mb-0 dash-yield-rank-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Xếp hạng zone theo sản lượng</span>
        <?php echo bq_tag('BQ-25'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Mã zone, tên khu…">
        </label>
    </div>
    <div class="tbl-wrap">
        <table class="dtbl dash-yield-rank-table">
            <thead>
            <tr>
                <th>Hạng</th>
                <th>Zone</th>
                <th>Tên khu</th>
                <th>Tổng sản lượng (kg)</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!$zoneYieldRank): ?>
                <tr><td colspan="4" class="muted">Chưa có sản lượng approved.</td></tr>
            <?php else: ?>
                <?php foreach ($zoneYieldRank as $row): ?>
                    <?php
                    $rank = (int)($row['yield_rank'] ?? 0);
                    $kg = (float)($row['total_yield_kg'] ?? 0);
                    $barPct = $yieldRankMax > 0 ? round(($kg / $yieldRankMax) * 100, 1) : 0;
                    $search = strtolower(($row['zone_code'] ?? '') . ' ' . ($row['zone_name'] ?? ''));
                    $rankCls = $rank <= 3 ? 'dash-yield-rank-row--top' . $rank : '';
                    ?>
                    <tr class="dash-yield-rank-row <?php echo e($rankCls); ?>" data-filter-row data-search="<?php echo e($search); ?>">
                        <td class="dash-yield-rank-pos"><strong><?php echo e((string)$rank); ?></strong></td>
                        <td class="mono"><strong><?php echo e($row['zone_code']); ?></strong></td>
                        <td><?php echo e($row['zone_name']); ?></td>
                        <td>
                            <div class="dash-yield-rank-kg">
                                <span><?php echo e(number_format($kg, 2)); ?></span>
                                <span class="dash-yield-rank-bar" role="presentation">
                                    <span class="dash-yield-rank-bar-fill" style="width:<?php echo e((string)$barPct); ?>%"></span>
                                </span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả.</p>
</div>

<div class="card mb-0 dash-harvest-kpi-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">KPI đạt target</span>
        <span class="card-head-right">
            <?php
            $kpiMetCount = count(array_filter(
                $harvestKpi,
                static fn(array $r): bool => (float)($r['target_completion_pct'] ?? 0) >= 100
            ));
            if ($kpiMetCount > 0) {
                echo dash_meta($kpiMetCount . ' zone đạt');
            }
            echo bq_tag('BQ-19');
            ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Tiến độ</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="kpi-done">≥ 100%</option>
                <option value="kpi-good">80–99%</option>
                <option value="kpi-mid">50–79%</option>
                <option value="kpi-low">&lt; 50%</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Mã zone, tên khu…">
        </label>
    </div>
    <?php if (!$harvestKpi): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có chu kỳ / target yield.</p>
    <?php else: ?>
        <div class="dash-harvest-kpi-grid">
            <?php foreach ($harvestKpi as $i => $row): ?>
                <?php
                $pct = (float)($row['target_completion_pct'] ?? 0);
                $kpiCls = harvest_kpi_class($pct);
                $barPct = min(100, max(0, $pct));
                $target = (float)($row['cycle_target_yield_kg'] ?? 0);
                $actual = (float)($row['approved_yield_kg'] ?? 0);
                $search = strtolower(($row['zone_code'] ?? '') . ' ' . ($row['zone_name'] ?? ''));
                ?>
                <article class="dash-harvest-kpi-card <?php echo e($kpiCls); ?>" data-filter-row
                         data-role="<?php echo e($kpiCls); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-harvest-kpi-head">
                        <div>
                            <div class="dash-harvest-kpi-zone"><?php echo e($row['zone_code']); ?></div>
                            <div class="dash-harvest-kpi-name"><?php echo e($row['zone_name']); ?></div>
                        </div>
                        <?php if ($i === 0): ?>
                            <span class="dash-harvest-kpi-top">Cao nhất</span>
                        <?php endif; ?>
                    </div>
                    <div class="dash-harvest-kpi-pct"><?php echo e(number_format($pct, 2)); ?>%</div>
                    <div class="dash-harvest-kpi-bar" role="presentation">
                        <div class="dash-harvest-kpi-bar-fill" style="width:<?php echo e((string)$barPct); ?>%"></div>
                    </div>
                    <div class="dash-harvest-kpi-figures">
                        <div><span>Thực tế</span><strong><?php echo e(number_format($actual, 0)); ?> kg</strong></div>
                        <div><span>Target</span><strong><?php echo e(number_format($target, 0)); ?> kg</strong></div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>
