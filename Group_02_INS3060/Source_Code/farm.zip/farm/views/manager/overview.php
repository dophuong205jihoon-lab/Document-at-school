<div class="card mb-0 dash-zone-health-panel" data-table-filter>
    <div class="card-head">
        <span class="card-title">Sức khỏe zone</span>
        <?php echo bq_tag('BQ-21'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Trạng thái zone</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="active">active</option>
                <option value="harvesting">harvesting</option>
                <option value="fallow">fallow</option>
                <option value="setup">setup</option>
            </select>
        </label>
        <label class="dash-filter-item">
            <span class="dash-filter-label">Sức khỏe</span>
            <select data-filter-health class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="critical">Nghiêm trọng</option>
                <option value="warning">Cảnh báo</option>
                <option value="ok">Ổn định</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Mã zone, tên khu…">
        </label>
    </div>
    <?php if (!$zoneHealth): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có dữ liệu zone health.</p>
    <?php else: ?>
        <div class="dash-zone-health-grid">
            <?php foreach ($zoneHealth as $zh): ?>
                <?php
                $st = (string)($zh['zone_status'] ?? 'active');
                $health = zone_health_level($zh);
                $moist = $zh['avg_soil_moisture'] ?? null;
                $moistStr = $moist !== null && $moist !== '' ? number_format((float)$moist, 2) . '%' : '—';
                $moistCls = $moist !== null && $moist !== '' ? soil_moisture_level_class((float)$moist) : '';
                $unres = (int)($zh['unresolved_alerts'] ?? 0);
                $faulty = (int)($zh['faulty_sensors'] ?? 0);
                $search = strtolower(($zh['zone_code'] ?? '') . ' ' . ($zh['zone_name'] ?? ''));
                ?>
                <article class="dash-zone-health-card dash-zone-health--<?php echo e($health); ?>"
                         data-filter-row data-role="<?php echo e($st); ?>"
                         data-health="<?php echo e($health); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-zone-health-head">
                        <div>
                            <div class="dash-zone-health-code"><?php echo e($zh['zone_code']); ?></div>
                            <div class="dash-zone-health-name"><?php echo e($zh['zone_name']); ?></div>
                        </div>
                        <?php echo role_badge($st); ?>
                    </div>
                    <div class="dash-zone-health-moist <?php echo e($moistCls); ?>">
                        <?php echo e($moistStr); ?>
                        <span>Độ ẩm TB</span>
                    </div>
                    <div class="dash-zone-health-stats">
                        <div>
                            <span>Cảnh báo mở</span>
                            <strong class="<?php echo $unres > 0 ? 'has-alert' : ''; ?>"><?php echo e((string)$unres); ?></strong>
                        </div>
                        <div>
                            <span>Sensor lỗi</span>
                            <strong class="<?php echo $faulty > 0 ? 'has-fault' : ''; ?>"><?php echo e((string)$faulty); ?></strong>
                        </div>
                    </div>
                    <?php if ($health === 'critical'): ?>
                        <span class="dash-zone-health-flag">Cần xử lý</span>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>
