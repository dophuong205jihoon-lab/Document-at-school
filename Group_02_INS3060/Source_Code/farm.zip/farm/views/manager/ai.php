<div class="card mb-0 dash-ai-irr-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Khuyến nghị tưới (AI)</span>
        <span class="card-head-right">
            <?php if ($aiIrrigationRecs): echo dash_meta(count($aiIrrigationRecs) . ' KN'); endif; ?>
            <?php echo bq_tag('BQ-16'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Hướng điều chỉnh</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="increase">Tăng tưới</option>
                <option value="decrease">Giảm tưới</option>
                <option value="optimize">Tối ưu</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Zone, nhãn AI…">
        </label>
    </div>
    <?php if (!$aiIrrigationRecs): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có khuyến nghị AI về tưới.</p>
    <?php else: ?>
        <div class="dash-ai-grid" style="padding:0 16px 16px">
            <?php foreach ($aiIrrigationRecs as $rec): ?>
                <?php
                $label = (string)($rec['predict_result_label'] ?? '');
                $action = ai_irrigation_action($label);
                $recSched = trim((string)($rec['recommended_schedule'] ?? ''));
                $saving = $rec['water_saving_pct'] ?? null;
                $savingStr = $saving !== null && $saving !== '' ? e((string)$saving) . '%' : '—';
                $search = strtolower(
                    ($rec['zone_code'] ?? '') . ' ' . ($rec['zone_name'] ?? '') . ' ' . $label . ' ' . $recSched
                );
                $actionBadge = match ($action) {
                    'increase' => 'Tăng tưới',
                    'decrease' => 'Giảm tưới',
                    default => 'Tối ưu',
                };
                ?>
                <article class="dash-ai-card" data-filter-row
                         data-role="<?php echo e($action); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-ai-head">
                        <span class="mono"><?php echo e($rec['zone_code']); ?></span>
                        <span><?php echo fmt_confidence($rec['predict_confidence'] ?? null); ?></span>
                    </div>
                    <div class="dash-ai-label"><?php echo e($rec['zone_name']); ?></div>
                    <p class="dash-ai-detail"><?php echo e($label); ?></p>
                    <div class="dash-ai-irr-metrics">
                        <div>
                            <span>Lịch đề xuất</span>
                            <strong><?php echo e($recSched !== '' ? $recSched : '—'); ?></strong>
                        </div>
                        <div>
                            <span>Tiết kiệm nước</span>
                            <strong><?php echo $savingStr; ?></strong>
                        </div>
                    </div>
                    <div class="dash-ai-irr-foot">
                        <?php echo role_badge($actionBadge); ?>
                        <span class="dash-ai-meta"><?php echo fmt_dt($rec['predict_predicted_at'] ?? null); ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>

<div class="card mb-0 dash-ai-disease-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Rủi ro bệnh (AI)</span>
        <span class="card-head-right">
            <?php
            $diseaseCriticalCount = count(array_filter(
                $aiDiseaseRisks,
                static fn(array $r): bool => ai_disease_risk_level(
                    (string)($r['disease_type'] ?? ''),
                    (string)($r['predict_result_label'] ?? '')
                ) === 'critical'
            ));
            if ($diseaseCriticalCount > 0) {
                echo dash_meta($diseaseCriticalCount . ' nghiêm trọng');
            }
            echo bq_tag('BQ-17');
            ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Mức rủi ro</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="critical">Nghiêm trọng</option>
                <option value="warning">Cảnh báo</option>
                <option value="healthy">Khỏe mạnh</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Zone, loại bệnh…">
        </label>
    </div>
    <?php if (!$aiDiseaseRisks): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có dự đoán bệnh theo zone.</p>
    <?php else: ?>
        <div class="dash-ai-grid dash-ai-disease-grid">
            <?php foreach ($aiDiseaseRisks as $risk): ?>
                <?php
                $label = (string)($risk['predict_result_label'] ?? '');
                $disease = (string)($risk['disease_type'] ?? '');
                $level = ai_disease_risk_level($disease, $label);
                $rec = trim((string)($risk['recommendation'] ?? ''));
                $search = strtolower(
                    ($risk['zone_code'] ?? '') . ' ' . ($risk['zone_name'] ?? '') . ' '
                    . $label . ' ' . $disease . ' ' . $rec
                );
                $cardClass = 'dash-ai-card dash-ai-disease-card dash-ai-disease--' . $level;
                ?>
                <article class="<?php echo e($cardClass); ?>" data-filter-row
                         data-role="<?php echo e($level); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-ai-head">
                        <span class="mono"><?php echo e($risk['zone_code']); ?></span>
                        <span><?php echo fmt_confidence($risk['predict_confidence'] ?? null); ?></span>
                    </div>
                    <div class="dash-ai-label"><?php echo e($risk['zone_name']); ?></div>
                    <p class="dash-ai-detail"><?php echo e($label); ?></p>
                    <div class="dash-ai-disease-meta">
                        <div>
                            <span>Loại bệnh</span>
                            <strong class="mono"><?php echo e($disease !== '' ? $disease : '—'); ?></strong>
                        </div>
                        <?php if ($level === 'critical'): ?>
                            <span class="dash-ai-disease-priority">Ưu tiên kiểm tra</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($rec !== ''): ?>
                        <p class="dash-ai-disease-rec"><?php echo e($rec); ?></p>
                    <?php endif; ?>
                    <div class="dash-ai-irr-foot">
                        <?php echo role_badge($level === 'critical' ? 'critical' : ($level === 'warning' ? 'warning' : 'active')); ?>
                        <span class="dash-ai-meta"><?php echo fmt_dt($risk['predict_predicted_at'] ?? null); ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>
