<div class="card mb-0 dash-irr-eff-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Hiệu quả tưới theo zone</span>
        <span class="card-head-right">
            <?php if ($irrigationEfficiency): echo dash_meta(count($irrigationEfficiency) . ' zone'); endif; ?>
            <?php echo bq_tag('BQ-14'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Mã zone, tên khu…">
        </label>
    </div>
    <?php if (!$irrigationEfficiency): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có lần tưới completed để đánh giá.</p>
    <?php else: ?>
        <div class="dash-irr-eff-grid">
            <?php foreach ($irrigationEfficiency as $i => $row): ?>
                <?php
                $gain = (float)($row['avg_moisture_gain'] ?? 0);
                $gainCls = irrigation_gain_class($gain);
                $barPct = $irrGainMax > 0 ? round(($gain / $irrGainMax) * 100, 1) : 0;
                $search = strtolower(($row['zone_code'] ?? '') . ' ' . ($row['zone_name'] ?? ''));
                ?>
                <article class="dash-irr-eff-card" data-filter-row data-search="<?php echo e($search); ?>">
                    <div class="dash-irr-eff-head">
                        <div>
                            <div class="dash-irr-eff-code"><?php echo e($row['zone_code']); ?></div>
                            <div class="dash-irr-eff-name"><?php echo e($row['zone_name']); ?></div>
                        </div>
                        <?php if ($i === 0): ?>
                            <span class="dash-irr-eff-best">Hiệu quả cao</span>
                        <?php endif; ?>
                    </div>
                    <div class="dash-irr-eff-gain <?php echo e($gainCls); ?>">
                        +<?php echo e(number_format($gain, 2)); ?>%
                        <span>TB tăng độ ẩm / lần</span>
                    </div>
                    <div class="dash-irr-eff-bar" role="presentation">
                        <div class="dash-irr-eff-bar-fill <?php echo e($gainCls); ?>" style="width:<?php echo e((string)$barPct); ?>%"></div>
                    </div>
                    <div class="dash-irr-eff-meta">
                        <div><span>Lần tưới</span><strong><?php echo e((string)($row['completed_irrigations'] ?? 0)); ?></strong></div>
                        <div><span>Tổng nước</span><strong><?php echo e(number_format((float)($row['total_water_liters'] ?? 0), 0)); ?> L</strong></div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>

<div class="card mb-0 dash-irr-fail-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Lỗi tưới (aborted)</span>
        <span class="card-head-right">
            <?php if ($irrigationFailures): echo dash_meta(count($irrigationFailures) . ' lần'); endif; ?>
            <?php echo bq_tag('BQ-15'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Kích hoạt</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="scheduled">scheduled</option>
                <option value="auto">auto</option>
                <option value="manual">manual</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Zone, loại kích hoạt…">
        </label>
    </div>
    <?php if (!$irrigationFailures): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Không có lần tưới aborted.</p>
    <?php else: ?>
        <ul class="dash-irr-fail-list">
            <?php foreach ($irrigationFailures as $fail): ?>
                <?php
                $trigger = (string)($fail['irrlog_trigger_type'] ?? '');
                $moist = $fail['irrlog_soil_moisture_before'] ?? null;
                $moistStr = $moist !== null && $moist !== '' ? number_format((float)$moist, 1) . '%' : '—';
                $search = strtolower(
                    ($fail['zone_code'] ?? '') . ' ' . ($fail['zone_name'] ?? '') . ' ' . $trigger
                );
                ?>
                <li class="dash-irr-fail-item" data-filter-row
                    data-role="<?php echo e($trigger); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-irr-fail-main">
                        <div class="dash-irr-fail-top">
                            <span class="dash-irr-fail-zone"><?php echo e($fail['zone_code']); ?> · <?php echo e($fail['zone_name']); ?></span>
                            <?php echo role_badge('aborted'); ?>
                        </div>
                        <div class="dash-irr-fail-meta">
                            <?php echo role_badge($trigger !== '' ? $trigger : 'manual'); ?>
                            <span>Độ ẩm trước: <strong><?php echo e($moistStr); ?></strong></span>
                            <span class="mono">#<?php echo e((string)$fail['irrlog_id']); ?></span>
                        </div>
                    </div>
                    <time class="dash-irr-fail-time"><?php echo fmt_dt($fail['irrlog_started_at'] ?? null); ?></time>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>
