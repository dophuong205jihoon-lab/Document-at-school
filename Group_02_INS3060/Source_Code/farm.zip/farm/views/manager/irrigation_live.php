<div class="card mb-0 dash-irr-live-panel">
    <div class="card-head">
        <span class="card-title">Đang tưới</span>
        <span class="card-head-right">
            <?php if ($irrigatingNow): echo dash_meta(count($irrigatingNow) . ' zone'); endif; ?>
            <?php echo bq_tag('BQ-07'); ?>
        </span>
    </div>
    <?php if (!$irrigatingNow): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Không có zone nào đang tưới.</p>
    <?php else: ?>
        <div class="dash-irr-live-grid dash-irr-live-grid--stack">
            <?php foreach ($irrigatingNow as $log): ?>
                <?php
                $moist = $log['irrlog_soil_moisture_before'] ?? null;
                $moistStr = $moist !== null && $moist !== '' ? number_format((float)$moist, 1) . '%' : '—';
                $trigger = (string)($log['irrlog_trigger_type'] ?? '');
                ?>
                <article class="dash-irr-live-card">
                    <div class="dash-irr-live-top">
                        <div>
                            <div class="dash-irr-live-zone"><?php echo e($log['zone_code']); ?></div>
                            <div class="dash-irr-live-name"><?php echo e($log['zone_name']); ?></div>
                        </div>
                        <span class="dash-irr-live-dot" aria-hidden="true"></span>
                    </div>
                    <div class="dash-irr-live-metrics">
                        <div>
                            <span>Bắt đầu</span>
                            <strong><?php echo fmt_dt($log['irrlog_started_at'] ?? null); ?></strong>
                        </div>
                        <div>
                            <span>Độ ẩm trước</span>
                            <strong><?php echo e($moistStr); ?></strong>
                        </div>
                        <div>
                            <span>Kích hoạt</span>
                            <strong><?php echo role_badge($trigger !== '' ? $trigger : 'manual'); ?></strong>
                        </div>
                    </div>
                    <div class="dash-irr-live-foot">
                        <?php echo role_badge('in_progress'); ?>
                        <span class="mono">#<?php echo e((string)$log['irrlog_id']); ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
