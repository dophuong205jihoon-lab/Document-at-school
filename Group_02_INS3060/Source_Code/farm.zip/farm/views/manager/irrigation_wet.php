<div class="card mb-0 dash-wet-zone-panel" data-table-filter>
    <div class="card-head">
        <span class="card-title">Rủi ro thối rễ — giảm tưới</span>
        <span class="card-head-right">
            <?php if ($wetZones): echo dash_meta(count($wetZones) . ' zone'); endif; ?>
            <?php echo bq_tag('BQ-12'); ?>
        </span>
    </div>
    <?php echo ui_filter_bar_open(); ?>
        <?php echo ui_filter_search('Tìm kiếm', 'Mã zone, tên khu…'); ?>
    <?php echo ui_filter_bar_close(); ?>
    <?php if (!$wetZones): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Không có zone nào vượt 85% độ ẩm đất.</p>
    <?php else: ?>
        <div class="dash-wet-zone-grid dash-wet-zone-grid--stack">
            <?php foreach ($wetZones as $i => $z): ?>
                <?php
                $avg = (float)($z['avg_moisture'] ?? 0);
                $max = (float)($z['max_moisture'] ?? 0);
                $high = (int)($z['high_readings'] ?? 0);
                $moistCls = soil_moisture_high_class($max);
                $search = strtolower(($z['zone_code'] ?? '') . ' ' . ($z['zone_name'] ?? ''));
                ?>
                <article class="dash-wet-zone-card" data-filter-row data-search="<?php echo e($search); ?>">
                    <div class="dash-wet-zone-head">
                        <div>
                            <div class="dash-wet-zone-code"><?php echo e($z['zone_code']); ?></div>
                            <div class="dash-wet-zone-name"><?php echo e($z['zone_name']); ?></div>
                        </div>
                        <?php if ($i === 0): ?>
                            <span class="dash-wet-zone-risk">Rủi ro cao</span>
                        <?php endif; ?>
                    </div>
                    <div class="dash-wet-zone-max <?php echo e($moistCls); ?>">
                        <?php echo e(number_format($max, 2)); ?>%
                        <span>Độ ẩm cao nhất</span>
                    </div>
                    <div class="dash-wet-zone-meta">
                        <div><span>TB độ ẩm</span><strong><?php echo e(number_format($avg, 2)); ?>%</strong></div>
                        <div><span>Lần &gt; 85%</span><strong class="<?php echo e($moistCls); ?>"><?php echo e((string)$high); ?></strong></div>
                    </div>
                    <div class="dash-wet-zone-bar" role="presentation">
                        <div class="dash-wet-zone-bar-fill <?php echo e($moistCls); ?>" style="width:<?php echo e((string)min(100, max(0, $max))); ?>%"></div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>
