<div class="card mb-0 dash-weather-forecast-panel" style="margin-top:18px">
    <div class="card-head">
        <span class="card-title">Dự báo thời tiết 7 ngày</span>
        <span class="card-head-right">
            <?php if ($weatherForecast): echo dash_meta(count($weatherForecast) . ' ngày'); endif; ?>
            <?php echo bq_tag('BQ-09'); ?>
        </span>
    </div>
    <?php if (!$weatherForecast): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có dữ liệu dự báo.</p>
    <?php else: ?>
        <div class="dash-weather-row" style="padding:0 16px 16px">
            <?php foreach ($weatherForecast as $w): ?>
                <?php
                $dateRaw = (string)($w['weather_forecast_date'] ?? '');
                $dateTs = $dateRaw !== '' ? strtotime($dateRaw) : false;
                $dateLabel = $dateTs !== false ? date('d/m', $dateTs) : '—';
                $rain = (float)($w['weather_rainfall_mm'] ?? 0);
                $maxT = (float)($w['weather_temp_max'] ?? 0);
                $minT = (float)($w['weather_temp_min'] ?? 0);
                $hum = (float)($w['weather_humidity'] ?? 0);
                $cardClass = 'dash-weather-card';
                if ($rain > 10) {
                    $cardClass .= ' dash-weather-card--rain';
                }
                if ($maxT > 35) {
                    $cardClass .= ' dash-weather-card--hot';
                }
                ?>
                <article class="<?php echo e($cardClass); ?>">
                    <div class="dash-weather-date"><?php echo e($dateLabel); ?></div>
                    <div class="dash-weather-temp"><?php echo e(number_format($maxT, 1)); ?>° / <?php echo e(number_format($minT, 1)); ?>°</div>
                    <div class="dash-weather-rain"><?php echo e(number_format($rain, 1)); ?> mm mưa</div>
                    <div class="dash-weather-humid"><?php echo e(number_format($hum, 0)); ?>% ẩm</div>
                    <div class="dash-weather-cond"><?php echo e($w['weather_condition'] ?? ''); ?></div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<div class="card mb-0 dash-weather-irr-plan-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Lịch tưới đề xuất theo thời tiết</span>
        <span class="card-head-right">
            <?php
            $skipDays = count(array_filter(
                $weatherIrrigationPlan,
                static fn(array $d): bool => ($d['irrigation_recommendation'] ?? '') === 'SKIP_IRRIGATION'
            ));
            $increaseDays = count(array_filter(
                $weatherIrrigationPlan,
                static fn(array $d): bool => ($d['irrigation_recommendation'] ?? '') === 'INCREASE_IRRIGATION'
            ));
            if ($skipDays || $increaseDays) {
                $parts = [];
                if ($skipDays) {
                    $parts[] = $skipDays . ' hoãn';
                }
                if ($increaseDays) {
                    $parts[] = $increaseDays . ' tăng';
                }
                echo dash_meta(implode(' · ', $parts));
            }
            echo bq_tag('BQ-20');
            ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Đề xuất</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="SKIP_IRRIGATION">Hoãn tưới</option>
                <option value="INCREASE_IRRIGATION">Tăng tưới</option>
                <option value="NORMAL">Bình thường</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Ngày, điều kiện…">
        </label>
    </div>
    <?php if (!$weatherIrrigationPlan): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có dự báo cho lịch tưới.</p>
    <?php else: ?>
        <div class="dash-weather-irr-schedule">
            <?php foreach ($weatherIrrigationPlan as $day): ?>
                <?php
                $rec = (string)($day['irrigation_recommendation'] ?? 'NORMAL');
                $recLabel = weather_irrigation_rec_label($rec);
                $recCls = weather_irrigation_rec_class($rec);
                $dateRaw = (string)($day['weather_forecast_date'] ?? '');
                $dateTs = $dateRaw !== '' ? strtotime($dateRaw) : false;
                $dateLabel = $dateTs !== false ? date('d/m/Y', $dateTs) : '—';
                $rain = (float)($day['weather_rainfall_mm'] ?? 0);
                $maxT = (float)($day['weather_temp_max'] ?? 0);
                $search = strtolower($dateLabel . ' ' . ($day['weather_condition'] ?? '') . ' ' . $recLabel);
                ?>
                <article class="dash-weather-irr-day <?php echo e($recCls); ?>" data-filter-row
                         data-role="<?php echo e($rec); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-weather-irr-date">
                        <strong><?php echo e($dateLabel); ?></strong>
                        <span class="dash-weather-irr-metrics mono">
                            <?php echo e(number_format($maxT, 1)); ?>°C · <?php echo e(number_format($rain, 1)); ?> mm
                        </span>
                    </div>
                    <p class="dash-weather-irr-cond"><?php echo e($day['weather_condition'] ?? ''); ?></p>
                    <div class="dash-weather-irr-rec">
                        <?php echo role_badge($recLabel); ?>
                        <span class="mono dash-weather-irr-code"><?php echo e($rec); ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>

<div class="card mb-0 dash-dry-zone-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
