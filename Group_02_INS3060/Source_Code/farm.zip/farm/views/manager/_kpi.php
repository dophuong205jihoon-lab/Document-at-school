<div class="dash-kpi-wrap">
    <div class="dash-kpi-row dash-manager-kpi-row">
        <div class="dash-kpi" style="--accent:var(--blue-500)">
            <div class="dash-kpi-value"><?php echo e((string)$kpiActiveZones); ?></div>
            <div class="dash-kpi-label">Zone hoạt động</div>
        </div>
        <div class="dash-kpi" style="--accent:var(--red-500)">
            <div class="dash-kpi-value"><?php echo e((string)$kpiUnresolvedAlerts); ?></div>
            <div class="dash-kpi-label">Cảnh báo mở</div>
        </div>
        <div class="dash-kpi" style="--accent:var(--amber-500)">
            <div class="dash-kpi-value"><?php echo e((string)$kpiPendingHarvests); ?></div>
            <div class="dash-kpi-label">Thu hoạch chờ duyệt</div>
        </div>
        <div class="dash-kpi" style="--accent:var(--teal-500)">
            <div class="dash-kpi-value"><?php echo e((string)$kpiRunningIrrigations); ?></div>
            <div class="dash-kpi-label">Đang tưới</div>
        </div>
        <div class="dash-kpi" style="--accent:var(--purple-500)">
            <div class="dash-kpi-value"><?php echo e((string)$kpiFaultySensors); ?></div>
            <div class="dash-kpi-label">Sensor lỗi</div>
        </div>
    </div>
    <?php echo bq_tag('BQ-30'); ?>
</div>
