<div class="card mb-0" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Lịch tưới đang bật</span>
        <?php echo bq_tag('BQ-06'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Zone, tên lịch, cron…">
        </label>
    </div>
    <?php if (!$schedulesByZone): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Không có lịch tưới active.</p>
    <?php else: ?>
        <?php foreach ($schedulesByZone as $code => $group): ?>
            <?php
            $zoneSearch = strtolower($code . ' ' . ($group['zone_name'] ?? ''));
            ?>
            <section class="dash-sched-zone">
                <div class="dash-sched-zone-head">
                    <?php echo e($code); ?>
                    <span><?php echo e($group['zone_name']); ?></span>
                </div>
                <div class="tbl-wrap" style="padding:0 16px 8px">
                    <table class="dtbl">
                        <thead>
                        <tr>
                            <th>Tên lịch</th>
                            <th>Cron</th>
                            <th>Phút</th>
                            <th>L/m²</th>
                            <th>Tự điều chỉnh</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($group['items'] as $sch): ?>
                            <?php
                            $search = $zoneSearch . ' ' . strtolower(
                                ($sch['schedule_name'] ?? '') . ' ' . ($sch['schedule_cron_expr'] ?? '')
                            );
                            $auto = (int)($sch['schedule_is_auto_adjust'] ?? 0) === 1;
                            ?>
                            <tr data-filter-row data-search="<?php echo e($search); ?>">
                                <td><strong><?php echo e($sch['schedule_name']); ?></strong></td>
                                <td class="mono"><?php echo e($sch['schedule_cron_expr']); ?></td>
                                <td><?php echo e((string)$sch['schedule_duration_minutes']); ?></td>
                                <td><?php echo e(number_format((float)($sch['schedule_water_rate_l_m2'] ?? 0), 2)); ?></td>
                                <td><?php echo $auto ? 'Có' : 'Không'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>
