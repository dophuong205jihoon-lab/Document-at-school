<?php if (!empty($_GET['iot'])): ?>
<p class="dash-flash-msg">Đã gửi reading IoT.</p>
<?php endif; ?>

<div class="card mb-0 dash-iot-sim-panel">
    <div class="card-head">
        <span class="card-title">Demo IoT</span>
        <?php echo bq_tag('BQ-23'); ?>
    </div>
    <form method="post" class="dash-iot-sim-form">
        <input type="hidden" name="iot_sim" value="1">
        <label>
            <span class="dash-filter-label">Mã sensor</span>
            <input type="text" name="sensor_code" class="dash-filter-input" value="Z02-SM-01" required>
        </label>
        <label>
            <span class="dash-filter-label">Giá trị (min 50%)</span>
            <input type="number" step="0.1" name="reading_value" class="dash-filter-input" value="42" required>
        </label>
        <button type="submit" class="btn btn-primary">Gửi reading</button>
    </form>
</div>

<div class="card mb-0" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Cảnh báo chưa xử lý</span>
        <?php echo bq_tag('BQ-05'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Mức độ</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="critical">critical</option>
                <option value="warning">warning</option>
                <option value="info">info</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Zone, sensor, nội dung…">
        </label>
    </div>
    <div class="dash-alert-list" style="padding:0 16px 16px">
        <?php if (!$openAlerts): ?>
            <p class="dash-empty">Không có cảnh báo mở.</p>
        <?php else: ?>
            <?php foreach ($openAlerts as $a): ?>
                <?php
                $pr = $a['alert_priority'] ?? 'info';
                $cls = alert_priority_class($pr);
                $search = strtolower(
                    ($a['zone_code'] ?? '') . ' ' . ($a['sensor_code'] ?? '') . ' '
                    . ($a['alert_type'] ?? '') . ' ' . ($a['alert_message'] ?? '')
                );
                ?>
                <article class="dash-alert-card <?php echo e($cls); ?>"
                         data-filter-row data-role="<?php echo e($pr); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-alert-top">
                        <span class="dash-alert-zone"><?php echo e($a['zone_code']); ?> · <?php echo e($a['sensor_code']); ?></span>
                        <?php echo role_badge($pr); ?>
                    </div>
                    <div class="dash-alert-msg"><?php echo e($a['alert_message']); ?></div>
                    <div class="dash-alert-meta">
                        <?php echo e($a['alert_type']); ?> · <?php echo fmt_dt($a['alert_triggered_at'] ?? null); ?>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>

<div class="card mb-0 dash-alert-summary-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Tổng hợp cảnh báo theo zone</span>
        <span class="card-head-right">
            <?php if ($alertChartRows): echo dash_meta(count($alertChartRows) . ' zone'); endif; ?>
            <?php echo bq_tag('BQ-13'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Mã zone, tên khu…">
        </label>
    </div>
    <div class="dash-alert-chart-legend">
        <span><i class="dash-alert-legend-swatch dash-alert-legend-critical"></i> Critical</span>
        <span><i class="dash-alert-legend-swatch dash-alert-legend-unresolved"></i> Chưa xử lý (warning/info)</span>
        <span><i class="dash-alert-legend-swatch dash-alert-legend-resolved"></i> Đã xử lý</span>
    </div>
    <?php if (!$alertChartRows): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có cảnh báo nào theo zone.</p>
    <?php else: ?>
        <div class="dash-alert-chart chart-wrap">
            <?php foreach ($alertChartRows as $row): ?>
                <?php
                $code = (string)($row['zone_code'] ?? '');
                $total = (int)($row['total_alerts'] ?? 0);
                $critical = (int)($row['critical_alerts'] ?? 0);
                $unresolved = (int)($row['unresolved_alerts'] ?? 0);
                $resolved = max(0, $total - $unresolved);
                $unresolvedCritical = min($critical, $unresolved);
                $unresolvedOther = max(0, $unresolved - $unresolvedCritical);
                $barPct = $alertChartMax > 0 ? round(($total / $alertChartMax) * 100, 2) : 0;
                $segCritical = $total > 0 ? ($unresolvedCritical / $total) * 100 : 0;
                $segUnresolved = $total > 0 ? ($unresolvedOther / $total) * 100 : 0;
                $segResolved = $total > 0 ? ($resolved / $total) * 100 : 0;
                $search = strtolower($code . ' ' . ($row['zone_name'] ?? ''));
                ?>
                <div class="dash-alert-chart-row" data-filter-row data-search="<?php echo e($search); ?>">
                    <div class="dash-alert-chart-label" title="<?php echo e($row['zone_name'] ?? ''); ?>">
                        <?php echo e($code); ?>
                    </div>
                    <div class="dash-alert-chart-track">
                        <div class="dash-alert-chart-bar" style="width:<?php echo e((string)$barPct); ?>%">
                            <span class="dash-alert-seg-critical" style="width:<?php echo e((string)$segCritical); ?>%"></span>
                            <span class="dash-alert-seg-unresolved" style="width:<?php echo e((string)$segUnresolved); ?>%"></span>
                            <span class="dash-alert-seg-resolved" style="width:<?php echo e((string)$segResolved); ?>%"></span>
                        </div>
                    </div>
                    <div class="dash-alert-chart-stats mono">
                        <span title="Tổng"><?php echo e((string)$total); ?></span>
                        <span class="dash-alert-stat-critical" title="Critical"><?php echo e((string)$critical); ?></span>
                        <span class="dash-alert-stat-unresolved" title="Chưa xử lý"><?php echo e((string)$unresolved); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>
