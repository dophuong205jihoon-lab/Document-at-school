<?php
/** @var array $user */
/** @var string $adminPage */

require __DIR__ . '/../includes/layout.php';
?>

<?php if ($adminPage === 'overview' || $adminPage === 'users'): ?>
    <?php require __DIR__ . '/admin/_kpi.php'; ?>
<?php endif; ?>

<?php if ($adminPage === 'overview'): ?>
    <p class="dash-admin-ops-link"><a href="dashboard.php?view=ops&amp;page=overview" class="btn btn-primary">Mở vận hành farm (Manager)</a></p>
<?php endif; ?>

<?php
$partial = __DIR__ . '/admin/' . $adminPage . '.php';
if (is_file($partial)) {
    require $partial;
}
?>

<script src="assets/js/table-filter.js" defer></script>
<?php require __DIR__ . '/../includes/layout_end.php';
