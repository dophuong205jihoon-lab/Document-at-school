<div class="dash-kpi-row">
    <div class="dash-kpi" style="--accent:var(--purple-500)"><div class="dash-kpi-value"><?php echo (int)($total ?? 0); ?></div><div class="dash-kpi-label">Tổng user</div></div>
    <div class="dash-kpi" style="--accent:var(--purple-600)"><div class="dash-kpi-value"><?php echo count($byRole['admin'] ?? []); ?></div><div class="dash-kpi-label">Admin</div></div>
    <div class="dash-kpi" style="--accent:var(--blue-500)"><div class="dash-kpi-value"><?php echo count($byRole['manager'] ?? []); ?></div><div class="dash-kpi-label">Manager</div></div>
    <div class="dash-kpi" style="--accent:var(--green-600)"><div class="dash-kpi-value"><?php echo count($byRole['farmer'] ?? []); ?></div><div class="dash-kpi-label">Farmer</div></div>
</div>
