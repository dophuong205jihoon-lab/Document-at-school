<div class="card mb-0 dash-user-summary-panel">
    <div class="card-head">
        <span class="card-title">Tổng hợp tài khoản theo role &amp; status</span>
        <?php echo bq_tag('BQ-26'); ?>
    </div>
    <?php if (!$userSummary): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có dữ liệu user.</p>
    <?php else: ?>
        <div class="dash-user-summary-cards">
            <?php foreach ($userSummary as $row): ?>
                <?php
                $role = (string)($row['user_role'] ?? '');
                $status = (string)($row['user_status'] ?? '');
                $n = (int)($row['total_users'] ?? 0);
                $statusCls = match ($status) {
                    'active' => 'green',
                    'locked' => 'red',
                    default => 'gray',
                };
                ?>
                <article class="dash-user-summary-card dash-user-summary-card--<?php echo e($role); ?>">
                    <div class="dash-user-summary-card-top">
                        <?php echo role_badge($roleLabels[$role] ?? ucfirst($role)); ?>
                        <span class="dash-badge dash-badge-<?php echo e($statusCls); ?>"><?php echo e($status); ?></span>
                    </div>
                    <div class="dash-user-summary-card-value"><?php echo e((string)$n); ?></div>
                    <div class="dash-user-summary-card-label">tài khoản</div>
                </article>
            <?php endforeach; ?>
            <article class="dash-user-summary-card dash-user-summary-card--total">
                <div class="dash-user-summary-card-top"><span class="dash-user-summary-total-label">Tổng</span></div>
                <div class="dash-user-summary-card-value"><?php echo e((string)$userSummaryTotal); ?></div>
                <div class="dash-user-summary-card-label">theo nhóm role/status</div>
            </article>
        </div>
        <?php if ($userChartRows): ?>
            <div class="dash-user-summary-chart-wrap">
                <div class="dash-user-summary-chart-legend">
                    <span><i class="dash-user-legend-swatch dash-user-legend-active"></i> Active</span>
                    <span><i class="dash-user-legend-swatch dash-user-legend-locked"></i> Locked</span>
                    <span><i class="dash-user-legend-swatch dash-user-legend-inactive"></i> Inactive</span>
                </div>
                <div class="dash-user-summary-chart chart-wrap">
                    <?php foreach ($userChartRows as $chart): ?>
                        <?php
                        $role = $chart['role'];
                        $total = $chart['total'];
                        $barPct = $userChartMax > 0 ? round(($total / $userChartMax) * 100, 1) : 0;
                        $segActive = $total > 0 ? round(($chart['active'] / $total) * 100, 2) : 0;
                        $segLocked = $total > 0 ? round(($chart['locked'] / $total) * 100, 2) : 0;
                        $segInactive = $total > 0 ? round(($chart['inactive'] / $total) * 100, 2) : 0;
                        $roleLabel = $roleLabels[$role] ?? ucfirst($role);
                        ?>
                        <div class="dash-user-summary-chart-row">
                            <div class="dash-user-summary-chart-label"><?php echo role_badge($roleLabel); ?></div>
                            <div class="dash-user-summary-chart-track">
                                <div class="dash-user-summary-chart-bar" style="width:<?php echo e((string)$barPct); ?>%">
                                    <span class="dash-user-seg-active" style="width:<?php echo e((string)$segActive); ?>%"></span>
                                    <span class="dash-user-seg-locked" style="width:<?php echo e((string)$segLocked); ?>%"></span>
                                    <span class="dash-user-seg-inactive" style="width:<?php echo e((string)$segInactive); ?>%"></span>
                                </div>
                            </div>
                            <div class="dash-user-summary-chart-stats mono" title="Tổng / active / locked / inactive">
                                <span><?php echo e((string)$total); ?></span>
                                <span class="dash-user-stat-active"><?php echo e((string)$chart['active']); ?></span>
                                <span class="dash-user-stat-locked"><?php echo e((string)$chart['locked']); ?></span>
                                <span class="dash-user-stat-inactive"><?php echo e((string)$chart['inactive']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
