
<div class="card mb-0 dash-user-risk-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Tài khoản cần kiểm tra</span>
        <span class="card-head-right">
            <?php echo dash_meta(count($usersAtRisk) . ' TK'); ?>
            <?php echo bq_tag('BQ-27'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Vai trò</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="admin">Admin</option>
                <option value="manager">Manager</option>
                <option value="farmer">Farmer</option>
            </select>
        </label>
        <label class="dash-filter-item">
            <span class="dash-filter-label">Lý do</span>
            <select data-filter-health class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="locked">Bị khóa</option>
                <option value="no_login">Chưa đăng nhập</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Username, họ tên…">
        </label>
    </div>
    <div class="tbl-wrap">
        <table class="dtbl dash-user-risk-table">
            <thead>
            <tr>
                <th>Lý do</th>
                <th>Username</th>
                <th>Họ tên</th>
                <th>Role</th>
                <th>Status</th>
                <th>Đăng nhập lần cuối</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!$usersAtRisk): ?>
                <tr><td colspan="6" class="muted">Không có tài khoản cần kiểm tra.</td></tr>
            <?php else: ?>
                <?php foreach ($usersAtRisk as $u): ?>
                    <?php
                    $role = (string)($u['user_role'] ?? '');
                    $status = (string)($u['user_status'] ?? '');
                    $isLocked = $status === 'locked';
                    $noLogin = ($u['user_last_login'] ?? null) === null || ($u['user_last_login'] ?? '') === '';
                    $issue = $isLocked ? 'locked' : 'no_login';
                    $search = strtolower(
                        ($u['user_username'] ?? '') . ' ' . ($u['user_full_name'] ?? '') . ' ' . $role . ' ' . $status
                    );
                    $rowCls = $isLocked ? 'dash-user-risk-row--locked' : 'dash-user-risk-row--no-login';
                    ?>
                    <tr class="dash-user-risk-row <?php echo e($rowCls); ?>"
                        data-filter-row
                        data-role="<?php echo e($role); ?>"
                        data-health="<?php echo e($issue); ?>"
                        data-search="<?php echo e($search); ?>">
                        <td>
                            <?php if ($isLocked): ?>
                                <span class="dash-badge dash-badge-red">Bị khóa</span>
                            <?php endif; ?>
                            <?php if ($noLogin): ?>
                                <span class="dash-badge dash-badge-amber">Chưa login</span>
                            <?php endif; ?>
                        </td>
                        <td class="mono"><strong><?php echo e($u['user_username']); ?></strong></td>
                        <td><?php echo e($u['user_full_name']); ?></td>
                        <td><?php echo role_badge($roleLabels[$role] ?? ucfirst($role)); ?></td>
                        <td><span class="dash-badge dash-badge-<?php echo e($isLocked ? 'red' : 'gray'); ?>"><?php echo e($status); ?></span></td>
                        <td class="muted"><?php echo $noLogin ? '—' : fmt_dt($u['user_last_login']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả.</p>
</div>

<div class="card mb-0" data-table-filter>
    <div class="card-head">
        <span class="card-title">Danh sách người dùng</span>
        <?php echo bq_tag('BQ-01'); ?>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Vai trò</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="admin">Admin</option>
                <option value="manager">Manager</option>
                <option value="farmer">Farmer</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="Username, họ tên…">
        </label>
    </div>

    <?php foreach (['admin' => 'Admin', 'manager' => 'Manager', 'farmer' => 'Farmer'] as $role => $label): ?>
        <section class="dash-user-role-block">
            <div class="dash-user-role-head"><?php echo role_badge($label); ?></div>
            <div class="tbl-wrap">
                <table class="dtbl">
                    <thead>
                    <tr><th>Username</th><th>Họ tên</th><th>Status</th><th>Đăng nhập</th></tr>
                    </thead>
                    <tbody>
                    <?php if (!$byRole[$role]): ?>
                        <tr><td colspan="4" class="muted">Không có dữ liệu.</td></tr>
                    <?php else: ?>
                        <?php foreach ($byRole[$role] as $u): ?>
                            <?php
                            $search = strtolower(($u['user_username'] ?? '') . ' ' . ($u['user_full_name'] ?? ''));
                            ?>
                            <tr data-filter-row data-role="<?php echo e($role); ?>" data-search="<?php echo e($search); ?>">
                                <td class="mono"><?php echo e($u['user_username']); ?></td>
                                <td><strong><?php echo e($u['user_full_name']); ?></strong></td>
                                <td><?php echo e($u['user_status']); ?></td>
                                <td><?php echo fmt_dt($u['user_last_login'] ?? null); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endforeach; ?>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả.</p>
</div>
