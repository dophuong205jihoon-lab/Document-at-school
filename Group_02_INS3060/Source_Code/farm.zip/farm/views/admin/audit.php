<div class="card mb-0 dash-activity-panel" style="margin-top:18px" data-table-filter>
    <div class="card-head">
        <span class="card-title">Nhật ký hoạt động</span>
        <span class="card-head-right">
            <?php echo dash_meta('20 mới nhất'); ?>
            <?php echo bq_tag('BQ-10'); ?>
        </span>
    </div>
    <div class="dash-filter-bar">
        <label class="dash-filter-item">
            <span class="dash-filter-label">Thao tác</span>
            <select data-filter-role class="dash-filter-input">
                <option value="">Tất cả</option>
                <option value="INSERT">INSERT</option>
                <option value="UPDATE">UPDATE</option>
                <option value="LOGIN">LOGIN</option>
                <option value="LOGOUT">LOGOUT</option>
            </select>
        </label>
        <label class="dash-filter-item dash-filter-grow">
            <span class="dash-filter-label">Tìm kiếm</span>
            <input type="search" data-filter-search class="dash-filter-input" placeholder="User, bảng, IP…">
        </label>
    </div>
    <?php if (!$auditLog): ?>
        <p class="dash-empty" style="padding:0 16px 16px">Chưa có nhật ký hoạt động.</p>
    <?php else: ?>
        <ul class="dash-activity-log">
            <?php foreach ($auditLog as $row): ?>
                <?php
                $action = (string)($row['audit_action'] ?? '');
                $actor = trim((string)($row['user_full_name'] ?? ''));
                if ($actor === '') {
                    $actor = 'Hệ thống';
                }
                $table = (string)($row['audit_table_name'] ?? '—');
                $recId = $row['audit_record_id'] ?? null;
                $recLabel = $recId !== null && $recId !== '' ? (string)$recId : '—';
                $search = strtolower(
                    $actor . ' ' . $action . ' ' . $table . ' '
                    . ($row['audit_ip_address'] ?? '')
                );
                ?>
                <li class="dash-activity-item" data-filter-row
                    data-role="<?php echo e($action); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-activity-main">
                        <div class="dash-activity-top">
                            <?php echo role_badge($action !== '' ? $action : 'UPDATE'); ?>
                            <span class="dash-activity-table mono"><?php echo e($table); ?></span>
                            <span class="dash-activity-record mono">#<?php echo e($recLabel); ?></span>
                        </div>
                        <div class="dash-activity-actor"><?php echo e($actor); ?></div>
                    </div>
                    <div class="dash-activity-meta">
                        <span class="mono"><?php echo e($row['audit_ip_address'] ?? '—'); ?></span>
                        <time><?php echo fmt_dt($row['audit_logged_at'] ?? null); ?></time>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden style="padding:0 16px 16px">Không có kết quả.</p>
</div>

<script src="assets/js/table-filter.js" defer></script>
<?php require __DIR__ . '/../includes/layout_end.php';
