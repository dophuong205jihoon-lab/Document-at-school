<?php
/** @var array $user */
/** @var string $farmerPage */

require __DIR__ . '/../includes/layout.php';
?>

<?php require __DIR__ . '/farmer/_kpi.php'; ?>

<?php
$partial = __DIR__ . '/farmer/' . $farmerPage . '.php';
if (is_file($partial)) {
    require $partial;
}
?>

<script src="assets/js/table-filter.js" defer></script>
<?php require __DIR__ . '/../includes/layout_end.php';
