<?php
/** @var array $user */
/** @var bool $isAdmin */
/** @var string $managerPage */

require __DIR__ . '/../includes/layout.php';
?>
<?php if ($isAdmin): ?>
<p class="dash-ops-back"><a href="dashboard.php" class="btn btn-ghost btn-sm">← Quay lại Admin</a></p>
<?php endif; ?>

<?php require __DIR__ . '/manager/_kpi.php'; ?>

<?php
$partial = __DIR__ . '/manager/' . $managerPage . '.php';
if ($managerPage === 'irrigation') {
    echo '<div class="dash-split-2">';
    require __DIR__ . '/manager/irrigation_live.php';
    require __DIR__ . '/manager/irrigation_wet.php';
    echo '</div>';
    require __DIR__ . '/manager/irrigation.php';
    require __DIR__ . '/manager/irrigation_schedules.php';
    require __DIR__ . '/manager/irrigation_dry.php';
} elseif (is_file($partial)) {
    require $partial;
}
?>

<script src="assets/js/table-filter.js" defer></script>
<?php require __DIR__ . '/../includes/layout_end.php';
