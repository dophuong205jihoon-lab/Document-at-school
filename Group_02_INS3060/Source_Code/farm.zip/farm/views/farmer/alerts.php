<div class="card mb-0 dash-farmer-alerts-panel" data-table-filter>
    <div class="card-head">
        <span class="card-title">Cảnh báo chưa xử lý</span>
        <span class="card-head-right">
            <?php echo dash_meta(count($farmerOpenAlerts) . ' alert'); ?>
            <?php echo bq_tag('BQ-29'); ?>
        </span>
    </div>
    <?php echo ui_filter_bar_open(); ?>
        <?php echo ui_filter_select('Mức độ', 'data-filter-role', [
            '' => 'Tất cả',
            'critical' => 'Critical',
            'warning' => 'Warning',
            'info' => 'Info',
        ]); ?>
        <?php
        $zoneFilterOpts = ['' => 'Tất cả'];
        foreach ($alertZoneCodes as $zc) {
            $zoneFilterOpts[$zc] = $zc;
        }
        echo ui_filter_select('Zone', 'data-filter-health', $zoneFilterOpts);
        ?>
        <?php echo ui_filter_search('Tìm kiếm', 'Zone, sensor, nội dung…'); ?>
    <?php echo ui_filter_bar_close(); ?>
    <div class="dash-alert-list dash-farmer-alert-list">
        <?php if (!$farmerOpenAlerts): ?>
            <p class="dash-empty">Không có cảnh báo mở trong zone được phân công.</p>
        <?php else: ?>
            <?php foreach ($farmerOpenAlerts as $a): ?>
                <?php
                $pr = (string)($a['alert_priority'] ?? 'info');
                $zone = (string)($a['zone_code'] ?? '');
                $cls = alert_priority_class($pr);
                $search = strtolower(
                    $zone . ' ' . ($a['sensor_code'] ?? '') . ' '
                    . ($a['alert_type'] ?? '') . ' ' . ($a['alert_message'] ?? '')
                );
                ?>
                <article class="dash-alert-card <?php echo e($cls); ?>"
                         data-filter-row
                         data-role="<?php echo e($pr); ?>"
                         data-health="<?php echo e($zone); ?>"
                         data-search="<?php echo e($search); ?>">
                    <div class="dash-alert-top">
                        <span class="dash-alert-zone"><?php echo e($zone); ?> · <?php echo e($a['sensor_code']); ?></span>
                        <?php echo role_badge($pr); ?>
                    </div>
                    <div class="dash-alert-msg"><?php echo e($a['alert_message']); ?></div>
                    <div class="dash-alert-meta">
                        <?php echo e($a['alert_type']); ?> · <?php echo fmt_dt($a['alert_triggered_at'] ?? null); ?>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả phù hợp bộ lọc.</p>
</div>
