<div class="card mb-0 dash-farmer-zones-panel" data-table-filter>
    <div class="card-head">
        <span class="card-title">Khu vực của tôi</span>
        <span class="card-head-right">
            <?php if ($farmerZones): echo dash_meta(count($farmerZones) . ' zone'); endif; ?>
            <?php echo bq_tag('BQ-22'); ?>
        </span>
    </div>
    <?php echo ui_filter_bar_open(); ?>
        <?php echo ui_filter_select('Trạng thái', 'data-filter-role', [
            '' => 'Tất cả',
            'active' => 'Active',
            'harvesting' => 'Harvesting',
            'fallow' => 'Fallow',
            'setup' => 'Setup',
        ]); ?>
        <?php echo ui_filter_search('Tìm kiếm', 'Mã zone, tên khu…'); ?>
    <?php echo ui_filter_bar_close(); ?>
    <?php if (!$farmerZones): ?>
        <div class="dash-empty-state">
            <p><strong>Chưa có khu vực được phân công.</strong></p>
            <p class="muted">Liên hệ Manager/Admin để được gán zone trên hệ thống.</p>
        </div>
    <?php else: ?>
        <div class="dash-farmer-zone-grid">
            <?php foreach ($farmerZones as $z): ?>
                <?php
                $st = (string)($z['zone_status'] ?? 'active');
                $alerts = (int)($z['unresolved_alerts'] ?? 0);
                $sensors = (int)($z['total_sensors'] ?? 0);
                $search = strtolower(($z['zone_code'] ?? '') . ' ' . ($z['zone_name'] ?? ''));
                $alertCls = $alerts > 0 ? 'has-alerts' : '';
                ?>
                <article class="dash-farmer-zone-card dash-zone-tile--<?php echo e($st); ?>"
                         data-filter-row data-role="<?php echo e($st); ?>" data-search="<?php echo e($search); ?>">
                    <div class="dash-farmer-zone-head">
                        <div class="dash-zone-tile-code"><?php echo e($z['zone_code']); ?></div>
                        <?php echo role_badge($st); ?>
                    </div>
                    <div class="dash-zone-tile-name"><?php echo e($z['zone_name']); ?></div>
                    <div class="dash-farmer-zone-metrics">
                        <div>
                            <span>Cảnh báo mở</span>
                            <strong class="<?php echo e($alertCls); ?>"><?php echo e((string)$alerts); ?></strong>
                        </div>
                        <div>
                            <span>Sensor</span>
                            <strong><?php echo e((string)$sensors); ?></strong>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả phù hợp bộ lọc.</p>
</div>
