<div class="card mb-0 dash-farmer-readings-panel" data-table-filter>
    <div class="card-head">
        <span class="card-title">Chỉ số sensor mới nhất</span>
        <span class="card-head-right">
            <?php if ($farmerLatestReadings): echo dash_meta(count($farmerLatestReadings) . ' reading'); endif; ?>
            <?php echo bq_tag('BQ-28'); ?>
        </span>
    </div>
    <?php
    $sensorTypeOpts = ['' => 'Tất cả', 'soil_moisture' => 'Độ ẩm', 'temperature' => 'Nhiệt độ', 'ph' => 'pH'];
    $zoneOpts = ['' => 'Tất cả'];
    foreach (array_keys($readingsByZone) as $zc) {
        $zoneOpts[$zc] = $zc;
    }
    echo ui_filter_bar_open();
    echo ui_filter_select('Zone', 'data-filter-role', $zoneOpts);
    echo ui_filter_select('Loại sensor', 'data-filter-health', $sensorTypeOpts);
    echo ui_filter_search('Tìm kiếm', 'Mã zone, sensor…');
    echo ui_filter_bar_close();
    ?>
    <?php if (!$farmerLatestReadings): ?>
        <div class="dash-empty-state">
            <p><strong>Chưa có dữ liệu sensor.</strong></p>
            <p class="muted">Khi có reading hợp lệ, bảng sẽ hiển thị giá trị mới nhất theo từng zone.</p>
        </div>
    <?php else: ?>
        <?php foreach ($readingsByZone as $zoneCode => $block): ?>
            <section class="dash-farmer-readings-zone">
                <div class="dash-farmer-readings-zone-head">
                    <span class="mono"><strong><?php echo e($zoneCode); ?></strong></span>
                    <span class="muted"><?php echo e($block['zone_name']); ?></span>
                </div>
                <div class="tbl-wrap">
                    <table class="dtbl dash-farmer-readings-table">
                        <thead>
                        <tr>
                            <th>Sensor</th>
                            <th>Loại</th>
                            <th>Giá trị</th>
                            <th>Thời điểm</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($block['items'] as $r): ?>
                            <?php
                            $stype = (string)($r['sensor_type'] ?? '');
                            $val = (float)($r['reading_value'] ?? 0);
                            $unit = (string)($r['sensor_unit'] ?? '');
                            $valCls = '';
                            if ($stype === 'soil_moisture') {
                                $valCls = soil_moisture_level_class($val);
                                if ($val >= 85) {
                                    $valCls = soil_moisture_high_class($val);
                                }
                            }
                            $search = strtolower(
                                $zoneCode . ' ' . ($block['zone_name'] ?? '') . ' '
                                . ($r['sensor_code'] ?? '') . ' ' . $stype
                            );
                            ?>
                            <tr class="dash-farmer-reading-row"
                                data-filter-row
                                data-role="<?php echo e($zoneCode); ?>"
                                data-health="<?php echo e($stype); ?>"
                                data-search="<?php echo e($search); ?>">
                                <td class="mono"><strong><?php echo e($r['sensor_code']); ?></strong></td>
                                <td><?php echo e($stype); ?></td>
                                <td>
                                    <span class="dash-farmer-reading-value <?php echo e($valCls); ?>">
                                        <?php echo e(number_format($val, 2)); ?>
                                        <?php if ($unit !== ''): ?>
                                            <span class="dash-farmer-reading-unit"><?php echo e($unit); ?></span>
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td class="muted"><?php echo fmt_dt($r['reading_recorded_at'] ?? null); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>
    <p class="dash-empty" data-filter-empty hidden>Không có kết quả phù hợp bộ lọc.</p>
</div>
