<div class="dash-kpi-wrap">
    <div class="dash-kpi-row">
        <div class="dash-kpi" style="--accent:var(--green-600)">
            <div class="dash-kpi-value"><?php echo count($farmerZones ?? []); ?></div>
            <div class="dash-kpi-label">Zone phân công</div>
        </div>
        <div class="dash-kpi" style="--accent:var(--red-500)">
            <div class="dash-kpi-value"><?php echo (int)($totalAlerts ?? 0); ?></div>
            <div class="dash-kpi-label">Cảnh báo mở</div>
        </div>
        <div class="dash-kpi" style="--accent:var(--blue-500)">
            <div class="dash-kpi-value"><?php echo (int)($totalSensors ?? 0); ?></div>
            <div class="dash-kpi-label">Sensor</div>
        </div>
    </div>
</div>
