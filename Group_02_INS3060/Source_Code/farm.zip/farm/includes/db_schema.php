<?php
/**
 * Helpers: schema theo sql/aloe_farm_dashboard.sql + extensions tùy chọn (install/migrate.php).
 */

function db_table_exists(mysqli $conn, string $table): bool
{
    static $cache = [];
    if (isset($cache[$table])) {
        return $cache[$table];
    }
    $t = mysqli_real_escape_string($conn, $table);
    $r = mysqli_query($conn, "SHOW TABLES LIKE '{$t}'");
    $cache[$table] = $r && mysqli_num_rows($r) > 0;

    return $cache[$table];
}

function db_ensure_alert_reading_trigger(mysqli $conn): void
{
    static $ensured = false;
    if ($ensured) {
        return;
    }

    $check = mysqli_query(
        $conn,
        "SHOW TRIGGERS WHERE `Trigger` = 'trg_create_alert_after_sensor_reading'"
    );
    if ($check instanceof mysqli_result && mysqli_num_rows($check) > 0) {
        $ensured = true;

        return;
    }

    mysqli_query($conn, 'DROP TRIGGER IF EXISTS trg_create_alert_after_sensor_reading');

    $sql = <<<'SQL'
CREATE TRIGGER trg_create_alert_after_sensor_reading
AFTER INSERT ON sensor_readings
FOR EACH ROW
BEGIN
    DECLARE v_min DECIMAL(8,2);
    DECLARE v_max DECIMAL(8,2);
    DECLARE v_zone_id INT UNSIGNED;
    DECLARE v_sensor_type VARCHAR(30);

    SELECT sensor_min_threshold, sensor_max_threshold, sensor_zone_id, sensor_type
    INTO v_min, v_max, v_zone_id, v_sensor_type
    FROM sensors
    WHERE sensor_id = NEW.reading_sensor_id;

    IF NEW.reading_is_valid = 1 AND v_max IS NOT NULL AND NEW.reading_value > v_max THEN
        INSERT INTO alerts (
            alert_sensor_id, alert_zone_id, alert_type, alert_priority,
            alert_message, alert_triggered_value, alert_triggered_at, alert_is_resolved
        )
        VALUES (
            NEW.reading_sensor_id, v_zone_id, 'threshold_high', 'warning',
            CONCAT(v_sensor_type, ' vượt ngưỡng cao: ', NEW.reading_value),
            NEW.reading_value, NEW.reading_recorded_at, 0
        );
    END IF;

    IF NEW.reading_is_valid = 1 AND v_min IS NOT NULL AND NEW.reading_value < v_min THEN
        INSERT INTO alerts (
            alert_sensor_id, alert_zone_id, alert_type, alert_priority,
            alert_message, alert_triggered_value, alert_triggered_at, alert_is_resolved
        )
        VALUES (
            NEW.reading_sensor_id, v_zone_id, 'threshold_low', 'critical',
            CONCAT(v_sensor_type, ' dưới ngưỡng thấp: ', NEW.reading_value),
            NEW.reading_value, NEW.reading_recorded_at, 0
        );
    END IF;
END
SQL;

    mysqli_query($conn, $sql);
    $ensured = true;
}

function db_ensure_farmer_zone_dashboard_proc(mysqli $conn): void
{
    static $ensured = false;
    if ($ensured) {
        return;
    }

    mysqli_query($conn, 'DROP PROCEDURE IF EXISTS sp_farmer_zone_dashboard');

    $sql = <<<'SQL'
CREATE PROCEDURE sp_farmer_zone_dashboard(IN p_farmer_id INT)
BEGIN
    SELECT z.zone_code, z.zone_name, z.zone_status,
           COUNT(DISTINCT a.alert_id) AS unresolved_alerts,
           COUNT(DISTINCT s.sensor_id) AS total_sensors
    FROM user_zone_assignment uza
    JOIN zones z ON uza.assign_zone_id = z.zone_id
    LEFT JOIN sensors s ON z.zone_id = s.sensor_zone_id
    LEFT JOIN alerts a
           ON z.zone_id = a.alert_zone_id
          AND a.alert_is_resolved = 0
    WHERE uza.assign_user_id = p_farmer_id
      AND uza.assign_is_active = 1
    GROUP BY z.zone_id, z.zone_code, z.zone_name, z.zone_status
    ORDER BY z.zone_code;
END
SQL;

    mysqli_query($conn, $sql);
    $ensured = true;
}

function db_ensure_zone_health_view(mysqli $conn): void
{
    static $ensured = false;
    if ($ensured) {
        return;
    }

    $sql = <<<'SQL'
CREATE OR REPLACE VIEW vw_zone_health_summary AS
SELECT z.zone_id,
       z.zone_code,
       z.zone_name,
       z.zone_status,
       ROUND(AVG(CASE WHEN s.sensor_type = 'soil_moisture' THEN sr.reading_value END), 2) AS avg_soil_moisture,
       COUNT(DISTINCT CASE WHEN a.alert_is_resolved = 0 THEN a.alert_id END) AS unresolved_alerts,
       COUNT(DISTINCT CASE WHEN s.sensor_status IN ('inactive','error') THEN s.sensor_id END) AS faulty_sensors
FROM zones z
LEFT JOIN sensors s ON z.zone_id = s.sensor_zone_id
LEFT JOIN sensor_readings sr
       ON s.sensor_id = sr.reading_sensor_id
      AND sr.reading_is_valid = 1
LEFT JOIN alerts a ON z.zone_id = a.alert_zone_id
GROUP BY z.zone_id, z.zone_code, z.zone_name, z.zone_status
SQL;

    mysqli_query($conn, $sql);
    $ensured = true;
}

function db_column_exists(mysqli $conn, string $table, string $column): bool
{
    static $cache = [];
    $key = "{$table}.{$column}";
    if (isset($cache[$key])) {
        return $cache[$key];
    }
    $t = mysqli_real_escape_string($conn, $table);
    $c = mysqli_real_escape_string($conn, $column);
    $r = mysqli_query($conn, "SHOW COLUMNS FROM `{$t}` LIKE '{$c}'");
    $cache[$key] = $r && mysqli_num_rows($r) > 0;

    return $cache[$key];
}

/** @return array{moisture_threshold: float, start_time: string} */
function irrigation_schedule_meta(array $row): array
{
    $meta = ['moisture_threshold' => 50.0, 'start_time' => '06:00'];
    if (isset($row['schedule_moisture_threshold']) && $row['schedule_moisture_threshold'] !== null) {
        $meta['moisture_threshold'] = (float)$row['schedule_moisture_threshold'];
    } elseif (isset($row['moisture_threshold']) && $row['moisture_threshold'] !== null) {
        $meta['moisture_threshold'] = (float)$row['moisture_threshold'];
    }
    if (!empty($row['schedule_start_time'])) {
        $meta['start_time'] = (string)$row['schedule_start_time'];
    } elseif (!empty($row['start_time'])) {
        $meta['start_time'] = (string)$row['start_time'];
    }
    $notes = (string)($row['schedule_notes'] ?? $row['notes'] ?? '');
    if ($notes !== '' && str_starts_with(trim($notes), '{')) {
        $j = json_decode($notes, true);
        if (is_array($j)) {
            if (isset($j['moisture_threshold'])) {
                $meta['moisture_threshold'] = (float)$j['moisture_threshold'];
            }
            if (!empty($j['start_time'])) {
                $meta['start_time'] = (string)$j['start_time'];
            }
            if (!empty($j['valve_status'])) {
                $meta['valve_status'] = (string)$j['valve_status'];
            }
        }
    }

    return $meta;
}

function irrigation_weather_skip(mysqli $conn, array $scheduleRow): bool
{
    if (isset($scheduleRow['schedule_weather_adjusted'])) {
        return (int)($scheduleRow['schedule_weather_adjusted'] ?? 0) === 1;
    }
    if (db_column_exists($conn, 'irrigation_schedules', 'schedule_weather_adjusted')) {
        return (int)($scheduleRow['weather_adjusted'] ?? 0) === 1;
    }
    if ((int)($scheduleRow['schedule_is_auto_adjust'] ?? $scheduleRow['is_auto_adjust'] ?? 1) === 0) {
        return true;
    }
    $notes = (string)($scheduleRow['schedule_notes'] ?? $scheduleRow['notes'] ?? '');
    if (str_contains($notes, '[weather_skip]')) {
        return true;
    }

    return false;
}

function harvest_active_cycle_id(mysqli $conn, int $zoneId): ?int
{
    $stmt = mysqli_prepare(
        $conn,
        "SELECT cycle_id FROM growing_cycles
         WHERE cycle_zone_id = ? AND cycle_status IN ('harvesting', 'growing')
         ORDER BY FIELD(cycle_status, 'harvesting', 'growing'), cycle_planted_date DESC, cycle_id DESC
         LIMIT 1"
    );
    mysqli_stmt_bind_param($stmt, 'i', $zoneId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    return $row ? (int)$row['cycle_id'] : null;
}

function ai_active_cycle(mysqli $conn, int $zoneId): ?array
{
    $stmt = mysqli_prepare(
        $conn,
        "SELECT cycle_id,
                cycle_planted_date AS planted_date,
                cycle_target_yield_kg AS target_yield_kg,
                cycle_status AS status
         FROM growing_cycles
         WHERE cycle_zone_id = ? AND cycle_status IN ('harvesting', 'growing')
         ORDER BY FIELD(cycle_status, 'harvesting', 'growing'), cycle_planted_date DESC LIMIT 1"
    );
    mysqli_stmt_bind_param($stmt, 'i', $zoneId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if (!$row) {
        return null;
    }
    $planted = new DateTime($row['planted_date']);
    $days = (int)$planted->diff(new DateTime('today'))->days;
    $row['days_since_planting'] = $days;

    return $row;
}
