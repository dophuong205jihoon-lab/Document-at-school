<?php
/**
 * FR-11: Đồng bộ dự báo thời tiết (Open-Meteo, không cần API key).
 */
require_once __DIR__ . '/db_schema.php';

function weather_map_condition(int $code): string
{
    return match (true) {
        $code === 0 => 'Trời quang',
        in_array($code, [1, 2, 3], true) => 'Nhiều mây',
        in_array($code, [45, 48], true) => 'Sương mù',
        in_array($code, [51, 53, 55, 56, 57], true) => 'Mưa phùn',
        in_array($code, [61, 63, 65, 66, 67, 80, 81, 82], true) => 'Mưa',
        in_array($code, [71, 73, 75, 77, 85, 86], true) => 'Tuyết',
        in_array($code, [95, 96, 99], true) => 'Dông',
        default => 'Không xác định',
    };
}

/**
 * @return array{synced: int, errors: list<string>}
 */
function weather_sync_forecast(mysqli $conn, int $days = 7): array
{
    $lat = defined('WEATHER_LAT') ? (float)WEATHER_LAT : 10.8231;
    $lon = defined('WEATHER_LON') ? (float)WEATHER_LON : 106.6297;
    $days = max(1, min(14, $days));

    $url = sprintf(
        'https://api.open-meteo.com/v1/forecast?latitude=%F&longitude=%F&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,weathercode&timezone=Asia%%2FHo_Chi_Minh&forecast_days=%d',
        $lat,
        $lon,
        $days
    );

    $ctx = stream_context_create(['http' => ['timeout' => 15, 'header' => "User-Agent: AloeFarmDashboard/1.0\r\n"]]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) {
        return ['synced' => 0, 'errors' => ['Không kết nối được Open-Meteo']];
    }

    $data = json_decode($raw, true);
    if (!is_array($data) || empty($data['daily']['time'])) {
        return ['synced' => 0, 'errors' => ['Phản hồi thời tiết không hợp lệ']];
    }

    $daily = $data['daily'];
    $times = $daily['time'];
    $synced = 0;
    $errors = [];

    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO weather_data
            (weather_forecast_date, weather_temp_max, weather_temp_min, weather_humidity, weather_rainfall_mm, weather_wind_speed, weather_condition, weather_is_forecast, weather_fetched_at)
         VALUES (?, ?, ?, NULL, ?, ?, ?, 1, NOW())
         ON DUPLICATE KEY UPDATE
            weather_temp_max = VALUES(weather_temp_max),
            weather_temp_min = VALUES(weather_temp_min),
            weather_rainfall_mm = VALUES(weather_rainfall_mm),
            weather_wind_speed = VALUES(weather_wind_speed),
            weather_condition = VALUES(weather_condition),
            weather_is_forecast = 1,
            weather_fetched_at = NOW()'
    );

    foreach ($times as $i => $dateStr) {
        $tMax = isset($daily['temperature_2m_max'][$i]) ? (float)$daily['temperature_2m_max'][$i] : null;
        $tMin = isset($daily['temperature_2m_min'][$i]) ? (float)$daily['temperature_2m_min'][$i] : null;
        $rain = isset($daily['precipitation_sum'][$i]) ? (float)$daily['precipitation_sum'][$i] : 0.0;
        $wind = isset($daily['wind_speed_10m_max'][$i]) ? (float)$daily['wind_speed_10m_max'][$i] : null;
        $code = (int)($daily['weathercode'][$i] ?? 0);
        $condition = weather_map_condition($code);

        if ($tMax === null || $tMin === null) {
            $errors[] = "Thiếu nhiệt độ ngày {$dateStr}";
            continue;
        }

        mysqli_stmt_bind_param(
            $stmt,
            'sdddds',
            $dateStr,
            $tMax,
            $tMin,
            $rain,
            $wind,
            $condition
        );
        if (mysqli_stmt_execute($stmt)) {
            $synced++;
        } else {
            $errors[] = mysqli_error($conn);
        }
    }
    mysqli_stmt_close($stmt);

    return ['synced' => $synced, 'errors' => $errors];
}
