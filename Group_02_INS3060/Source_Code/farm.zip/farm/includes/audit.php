<?php
require_once __DIR__ . '/db_schema.php';

function audit_log(
    mysqli $conn,
    ?int $user_id,
    string $action,
    ?string $table_name = 'users',
    ?string $record_id = null,
    ?array $meta = null
): void {
    $allowed = ['INSERT', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'EXPORT'];
    if (!in_array($action, $allowed, true)) {
        return;
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $recordId = ($record_id !== null && preg_match('/^\d+$/', $record_id)) ? (int)$record_id : null;
    $newJson = $meta !== null ? json_encode($meta, JSON_UNESCAPED_UNICODE) : null;
    $oldJson = null;
    if (is_array($meta) && array_key_exists('old_status', $meta)) {
        $oldJson = json_encode(['status' => $meta['old_status']], JSON_UNESCAPED_UNICODE);
    }

    if (db_column_exists($conn, 'audit_logs', 'audit_old_json')) {
        $stmt = mysqli_prepare(
            $conn,
            'INSERT INTO audit_logs (audit_user_id, audit_action, audit_table_name, audit_record_id, audit_old_json, audit_new_json, audit_ip_address)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        mysqli_stmt_bind_param($stmt, 'ississs', $user_id, $action, $table_name, $recordId, $oldJson, $newJson, $ip);
    } else {
        $stmt = mysqli_prepare(
            $conn,
            'INSERT INTO audit_logs (audit_user_id, audit_action, audit_table_name, audit_record_id, audit_new_json, audit_ip_address)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        mysqli_stmt_bind_param($stmt, 'ississ', $user_id, $action, $table_name, $recordId, $newJson, $ip);
    }
    mysqli_stmt_execute($stmt);
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
