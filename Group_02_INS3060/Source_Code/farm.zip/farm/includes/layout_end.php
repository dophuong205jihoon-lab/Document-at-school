<?php if (!empty($GLOBALS['_layout_has_shell'])): ?>
        </div>
    </main>
</div>
<?php elseif (in_array(basename($_SERVER['PHP_SELF'] ?? ''), ['login.php', 'register.php'], true)): ?>
</div>
<?php else: ?>
</div>
<?php endif; ?>
</body>
</html>
