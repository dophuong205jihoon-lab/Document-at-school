<?php

function bq_tag(string $code): string
{
    return '<span class="bq-tag">' . e($code) . '</span>';
}

function dash_meta(string $text): string
{
    return '<span class="dash-card-meta">' . e($text) . '</span>';
}

function fmt_dt(mixed $value): string
{
    if ($value === null || $value === '') {
        return '—';
    }
    $ts = is_numeric($value) ? (int)$value : strtotime((string)$value);
    if ($ts === false) {
        return e((string)$value);
    }

    return date('Y-m-d H:i', $ts);
}

function soil_moisture_level_class(float $avg): string
{
    if ($avg < 45) {
        return 'moist-critical';
    }
    if ($avg < 55) {
        return 'moist-low';
    }

    return 'moist-warn';
}

function zone_health_level(array $row): string
{
    $unres = (int)($row['unresolved_alerts'] ?? 0);
    $faulty = (int)($row['faulty_sensors'] ?? 0);
    $moist = $row['avg_soil_moisture'] ?? null;
    $m = $moist !== null && $moist !== '' ? (float)$moist : null;

    if ($unres >= 2 || $faulty >= 2 || ($m !== null && $m < 45)) {
        return 'critical';
    }
    if ($unres >= 1 || $faulty >= 1 || ($m !== null && ($m < 55 || $m > 85))) {
        return 'warning';
    }

    return 'ok';
}

function weather_irrigation_rec_label(string $rec): string
{
    return match ($rec) {
        'SKIP_IRRIGATION' => 'Hoãn tưới',
        'INCREASE_IRRIGATION' => 'Tăng tưới',
        default => 'Bình thường',
    };
}

function weather_irrigation_rec_class(string $rec): string
{
    return match ($rec) {
        'SKIP_IRRIGATION' => 'rec-skip',
        'INCREASE_IRRIGATION' => 'rec-increase',
        default => 'rec-normal',
    };
}

function harvest_kpi_class(float $pct): string
{
    if ($pct >= 100) {
        return 'kpi-done';
    }
    if ($pct >= 80) {
        return 'kpi-good';
    }
    if ($pct >= 50) {
        return 'kpi-mid';
    }

    return 'kpi-low';
}

function ai_disease_risk_level(string $diseaseType, string $label): string
{
    $d = strtolower(trim($diseaseType));
    $lbl = strtolower($label);

    if ($d === 'none' || str_contains($lbl, 'healthy') || str_contains($lbl, 'no disease')) {
        return 'healthy';
    }
    if (in_array($d, ['root_rot', 'leaf_spot'], true)
        || str_contains($lbl, 'detected')
        || str_contains($lbl, 'moderate')) {
        return 'critical';
    }

    return 'warning';
}

function ai_irrigation_action(string $label): string
{
    if (preg_match('/tăng/i', $label)) {
        return 'increase';
    }
    if (preg_match('/giảm/i', $label)) {
        return 'decrease';
    }

    return 'optimize';
}

function fmt_confidence(mixed $value): string
{
    if ($value === null || $value === '') {
        return '—';
    }

    $n = (float)$value;

    return $n <= 1 ? number_format($n * 100, 1) . '%' : number_format($n, 1) . '%';
}

function irrigation_gain_class(float $gain): string
{
    if ($gain >= 15) {
        return 'gain-high';
    }
    if ($gain >= 8) {
        return 'gain-mid';
    }

    return 'gain-low';
}

function soil_moisture_high_class(float $max): string
{
    if ($max >= 88) {
        return 'moist-critical';
    }

    return 'moist-high';
}

function alert_priority_class(string $priority): string
{
    return match ($priority) {
        'critical' => 'critical',
        'warning' => 'warning',
        default => 'info',
    };
}

function role_badge(string $role): string
{
    $map = [
        'admin' => 'purple',
        'manager' => 'blue',
        'farmer' => 'green',
        'active' => 'green',
        'harvesting' => 'amber',
        'fallow' => 'gray',
        'setup' => 'blue',
        'critical' => 'red',
        'warning' => 'amber',
        'inactive' => 'gray',
        'error' => 'red',
        'in_progress' => 'blue',
        'scheduled' => 'blue',
        'auto' => 'green',
        'manual' => 'amber',
        'pending' => 'amber',
        'A' => 'green',
        'B' => 'blue',
        'C' => 'gray',
        'INSERT' => 'green',
        'UPDATE' => 'blue',
        'LOGIN' => 'purple',
        'LOGOUT' => 'gray',
        'aborted' => 'red',
        'Tăng tưới' => 'green',
        'Giảm tưới' => 'amber',
        'Tối ưu' => 'blue',
        'Hoãn tưới' => 'red',
        'Tăng tưới' => 'amber',
        'Bình thường' => 'green',
    ];
    $cls = $map[$role] ?? 'gray';

    return '<span class="dash-badge dash-badge-' . $cls . '">' . e($role) . '</span>';
}
