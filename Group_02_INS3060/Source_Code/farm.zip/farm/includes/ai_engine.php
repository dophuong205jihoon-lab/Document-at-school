<?php
require_once __DIR__ . '/db_schema.php';

const AI_DISEASES = [
    'root_rot' => ['label' => 'Bệnh thối gốc (Root rot)', 'icon' => '🦠'],
    'leaf_spot' => ['label' => 'Bệnh đốm lá (Leaf spot)', 'icon' => '🍂'],
    'mealybug' => ['label' => 'Rệp sáp (Mealybug)', 'icon' => '🐛'],
    'thrips' => ['label' => 'Bọ trĩ (Thrips)', 'icon' => '🪲'],
];

function ai_analyze_disease(mysqli $conn, int $zoneId): array
{
    $moist = ai_latest_sensor($conn, $zoneId, 'soil_moisture');
    $temp = ai_latest_sensor($conn, $zoneId, 'temperature');
    $ph = ai_latest_sensor($conn, $zoneId, 'ph');

    $disease = 'leaf_spot';
    $confidence = 0.72;
    $detail = 'Phân tích heuristic dựa trên cảm biến Zone.';

    if ($moist !== null && $moist > 85) {
        $disease = 'root_rot';
        $confidence = 0.88;
        $detail = 'Độ ẩm đất cao kéo dài — nguy cơ thối gốc.';
    } elseif ($temp !== null && $temp > 38) {
        $disease = 'thrips';
        $confidence = 0.76;
        $detail = 'Nhiệt độ cao — bọ trĩ phát triển mạnh.';
    } elseif ($ph !== null && ($ph < 6.0 || $ph > 8.0)) {
        $disease = 'leaf_spot';
        $confidence = 0.81;
        $detail = 'pH lệch — stress lá, đốm lá.';
    } elseif ($moist !== null && $moist < 45) {
        $disease = 'mealybug';
        $confidence = 0.69;
        $detail = 'Khô hạn — rệp sáp dễ xâm nhập.';
    }

    $label = AI_DISEASES[$disease]['label'] ?? $disease;
    ai_save_prediction($conn, $zoneId, 'disease', $label, $confidence, [
        'disease_key' => $disease,
        'detail' => $detail,
        'soil_moisture' => $moist,
        'temperature' => $temp,
        'ph' => $ph,
    ]);

    return [
        'disease_key' => $disease,
        'label' => $label,
        'confidence' => $confidence,
        'confidence_pct' => round($confidence * 100, 1),
        'detail' => $detail,
    ];
}

function ai_predict_yield(mysqli $conn, int $zoneId): array
{
    $cycle = ai_active_cycle($conn, $zoneId);
    $target = (float)($cycle['target_yield_kg'] ?? 0);

    $moist = ai_latest_sensor($conn, $zoneId, 'soil_moisture') ?? 65;
    $temp = ai_latest_sensor($conn, $zoneId, 'temperature') ?? 28;
    $factor = 1.0;
    if ($moist >= 60 && $moist <= 80) {
        $factor += 0.08;
    }
    if ($temp > 35) {
        $factor -= 0.12;
    } elseif ($temp < 20) {
        $factor -= 0.05;
    }

    $predicted = round(max(0, $target * $factor), 2);
    $confidence = min(0.95, 0.65 + abs($moist - 70) / 200);
    $label = "Dự báo {$predicted} kg lá/Zone";
    ai_save_prediction($conn, $zoneId, 'yield', $label, $confidence, [
        'predicted_yield_kg' => $predicted,
        'target_yield_kg' => $target,
        'moisture' => $moist,
        'temperature' => $temp,
        'humidity' => ai_latest_sensor($conn, $zoneId, 'humidity'),
        'ph' => ai_latest_sensor($conn, $zoneId, 'ph'),
        'ec' => ai_latest_sensor($conn, $zoneId, 'ec'),
    ]);

    return compact('predicted', 'target', 'confidence', 'label') + [
        'confidence_pct' => round($confidence * 100, 1),
    ];
}

function ai_optimize_irrigation(mysqli $conn, int $zoneId): array
{
    $moist = ai_latest_sensor($conn, $zoneId, 'soil_moisture') ?? 55;
    $baseMin = 30;
    $saving = rand(15, 20);
    $suggested = max(15, (int)round($baseMin * (1 - $saving / 100)));
    if ($moist < 55) {
        $suggested = $baseMin;
    } elseif ($moist > 75) {
        $suggested = max(10, $suggested - 5);
    }

    $label = "Tưới {$suggested} phút/lần — tiết kiệm ~{$saving}% nước";
    $confidence = 0.78;
    ai_save_prediction($conn, $zoneId, 'irrigation_opt', $label, $confidence, [
        'duration_min' => $suggested,
        'saving_pct' => $saving,
        'moisture' => $moist,
    ]);

    return [
        'label' => $label,
        'confidence' => $confidence,
        'confidence_pct' => round($confidence * 100, 1),
        'saving_pct' => $saving,
        'duration_min' => $suggested,
    ];
}

function ai_save_prediction(
    mysqli $conn,
    int $zoneId,
    string $modelType,
    string $label,
    float $confidence,
    array $detail
): void {
    $cycle = ai_active_cycle($conn, $zoneId);
    if ($cycle) {
        $detail['days_since_planting'] = $cycle['days_since_planting'];
        $detail['cycle_status'] = $cycle['status'];
    }
    $json = json_encode($detail, JSON_UNESCAPED_UNICODE);
    $cycleId = $cycle ? (int)$cycle['cycle_id'] : null;

    if ($cycleId !== null) {
        $stmt = mysqli_prepare(
            $conn,
            'INSERT INTO ai_predictions (predict_zone_id, predict_cycle_id, predict_model_type, predict_result_label, predict_confidence, predict_detail_json)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        mysqli_stmt_bind_param($stmt, 'iissds', $zoneId, $cycleId, $modelType, $label, $confidence, $json);
    } else {
        $stmt = mysqli_prepare(
            $conn,
            'INSERT INTO ai_predictions (predict_zone_id, predict_model_type, predict_result_label, predict_confidence, predict_detail_json)
             VALUES (?, ?, ?, ?, ?)'
        );
        mysqli_stmt_bind_param($stmt, 'issds', $zoneId, $modelType, $label, $confidence, $json);
    }
    mysqli_stmt_execute($stmt);
}

function ai_latest_sensor(mysqli $conn, int $zoneId, string $type): ?float
{
    $row = mysqli_fetch_assoc(mysqli_query(
        $conn,
        "SELECT sr.reading_value AS value FROM sensors s
         JOIN sensor_readings sr ON sr.reading_id = (
            SELECT reading_id FROM sensor_readings WHERE reading_sensor_id = s.sensor_id AND reading_is_valid = 1
            ORDER BY reading_recorded_at DESC LIMIT 1)
         WHERE s.sensor_zone_id = {$zoneId} AND s.sensor_type = '{$type}' LIMIT 1"
    ));

    return $row && $row['value'] !== null ? (float)$row['value'] : null;
}

function ai_list_for_zone(mysqli $conn, int $zoneId, ?string $modelType = null, int $limit = 10): array
{
    $sql = 'SELECT ap.predict_id AS prediction_id,
                   ap.predict_zone_id AS zone_id,
                   ap.predict_cycle_id AS cycle_id,
                   ap.predict_model_type AS model_type,
                   ap.predict_result_label AS result_label,
                   ap.predict_confidence AS confidence,
                   ap.predict_detail_json AS detail_json,
                   ap.predict_predicted_at AS predicted_at,
                   z.zone_code
            FROM ai_predictions ap JOIN zones z ON z.zone_id = ap.predict_zone_id
            WHERE ap.predict_zone_id = ?';
    if ($modelType) {
        $sql .= " AND ap.predict_model_type = '" . mysqli_real_escape_string($conn, $modelType) . "'";
    }
    $sql .= ' ORDER BY ap.predict_predicted_at DESC LIMIT ' . (int)$limit;
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $zoneId);
    mysqli_stmt_execute($stmt);

    return mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
}
