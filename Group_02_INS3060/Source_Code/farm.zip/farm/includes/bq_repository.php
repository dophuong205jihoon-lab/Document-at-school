<?php
/**
 * Query loader/executor for Q01-Q33 in sql/aloe_farm_dashboard.sql.
 */
require_once __DIR__ . '/db_schema.php';

function bq_source_file(): string
{
    return dirname(__DIR__) . '/sql/aloe_farm_dashboard.sql';
}

/** @return array<string, array{code: string, title: string, technique: string, story: string, sql_type: string, sql: string}> */
function bq_load_queries(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $file = bq_source_file();
    $raw = is_readable($file) ? (string)file_get_contents($file) : '';
    $cache = [];
    if ($raw === '') {
        return $cache;
    }

    preg_match_all('/^--\s+(?:BONUS\s+)?Q(\d{2})\s+[–-]\s+(.+)$/mu', $raw, $matches, PREG_OFFSET_CAPTURE);
    $count = count($matches[0]);
    for ($i = 0; $i < $count; $i++) {
        $num = $matches[1][$i][0];
        $code = str_pad($num, 2, '0', STR_PAD_LEFT);
        $start = $matches[0][$i][1];
        $end = $i + 1 < $count ? $matches[0][$i + 1][1] : strlen($raw);
        $block = substr($raw, $start, $end - $start);
        $sql = bq_extract_sql_from_block($block);
        $technique = bq_extract_comment_value($block, 'Technical');
        $story = bq_extract_comment_value($block, 'User story');

        $cache[$code] = [
            'code' => $code,
            'title' => trim($matches[2][$i][0]),
            'technique' => $technique !== '' ? $technique : bq_infer_sql_type($sql),
            'story' => $story,
            'sql_type' => bq_infer_sql_type($sql),
            'sql' => $sql,
        ];
    }

    return $cache;
}

function bq_extract_comment_value(string $block, string $label): string
{
    $quoted = preg_quote($label, '/');
    if (preg_match('/^--\s+' . $quoted . ':\s*(.+)$/mu', $block, $m)) {
        return trim($m[1]);
    }

    return '';
}

function bq_extract_sql_from_block(string $block): string
{
    $lines = preg_split('/\R/u', $block) ?: [];
    $started = false;
    $sql = [];
    foreach ($lines as $line) {
        $trim = ltrim($line);
        if (!$started && preg_match('/^(SELECT|WITH|START\s+TRANSACTION|SET\s+@)/i', $trim)) {
            $started = true;
        }
        if ($started) {
            $sql[] = $line;
        }
    }

    return trim(implode("\n", $sql));
}

function bq_infer_sql_type(string $sql): string
{
    $trim = ltrim($sql);
    if (preg_match('/^START\s+TRANSACTION/i', $trim)) {
        return 'TRANSACTION';
    }
    if (preg_match('/^WITH\b/i', $trim)) {
        return str_contains(strtoupper($sql), 'OVER (') ? 'CTE + WINDOW' : 'CTE';
    }
    if (str_contains($sql, ' v_')) {
        return 'VIEW SELECT';
    }
    if (str_contains(strtoupper($sql), 'OVER (')) {
        return 'WINDOW';
    }

    return 'SELECT';
}

function bq_installed(mysqli $conn): bool
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    if (!db_table_exists($conn, 'zones') || !db_table_exists($conn, 'sensor_readings')) {
        return $cache = false;
    }

    $view = @mysqli_query($conn, 'SELECT 1 FROM v_latest_sensor_readings LIMIT 1');
    if (!$view instanceof mysqli_result) {
        return $cache = false;
    }

    $sp = @mysqli_query($conn, "SHOW PROCEDURE STATUS WHERE Db = DATABASE() AND Name = 'sp_approve_harvest'");

    return $cache = ($sp instanceof mysqli_result && mysqli_num_rows($sp) > 0);
}

function bq_has_trigger_alert(mysqli $conn): bool
{
    $r = @mysqli_query($conn, "SHOW TRIGGERS WHERE `Trigger` = 'trg_create_alert_after_sensor_reading'");

    return $r instanceof mysqli_result && mysqli_num_rows($r) > 0;
}

/** @param array{user_id?: int, zone_id?: int} $ctx */
function bq_execute_file_query(mysqli $conn, string $code, string $sql, array $ctx = []): array
{
    if ($sql === '') {
        return ['rows' => [], 'message' => 'Không tìm thấy SQL cho query này trong sql/aloe_farm_dashboard.sql.'];
    }
    if ($code === '24') {
        return [
            'rows' => bq_fetch_all($conn, "SELECT harvest_id, harvest_status, harvest_approved_by, harvest_approved_at FROM harvest_records ORDER BY harvest_id DESC LIMIT 20"),
            'message' => 'Q24 là transaction mẫu có UPDATE/INSERT audit. Trang demo chỉ hiển thị SQL; thao tác thật chạy qua harvest.php và sp_approve_harvest.',
        ];
    }

    $exec = bq_strip_sql_comments($sql);
    $exec = bq_apply_demo_params($exec, $code, $ctx);
    $exec = trim($exec);
    $exec = rtrim($exec, " \t\n\r;");

    if (preg_match('/\b(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|TRUNCATE|START\s+TRANSACTION|COMMIT|ROLLBACK)\b/i', $exec)) {
        return ['rows' => [], 'message' => 'Query này có thay đổi dữ liệu nên không tự chạy trên trang demo.'];
    }

    $r = @mysqli_query($conn, $exec);
    if (!$r instanceof mysqli_result) {
        return [
            'rows' => [['sql_error' => mysqli_error($conn)]],
            'message' => 'MySQL báo lỗi khi chạy query từ aloe_farm_dashboard.sql.',
        ];
    }

    return ['rows' => mysqli_fetch_all($r, MYSQLI_ASSOC), 'message' => ''];
}

function bq_fetch_all(mysqli $conn, string $sql): array
{
    $r = @mysqli_query($conn, $sql);
    if (!$r instanceof mysqli_result) {
        return [];
    }

    return mysqli_fetch_all($r, MYSQLI_ASSOC);
}

/** @param array{user_id?: int, zone_id?: int} $ctx */
function bq_apply_demo_params(string $sql, string $code, array $ctx): string
{
    $zoneId = max(1, (int)($ctx['zone_id'] ?? 1));
    $userId = max(1, (int)($ctx['user_id'] ?? 1));

    if ($code === '02') {
        $sql = preg_replace('/WHERE\s+zone_id\s*=\s*\d+/i', 'WHERE zone_id = ' . $zoneId, $sql) ?? $sql;
    } elseif ($code === '06') {
        $sql = preg_replace('/WHERE\s+s\.sensor_zone_id\s*=\s*\d+/i', 'WHERE s.sensor_zone_id = ' . $zoneId, $sql) ?? $sql;
    } elseif ($code === '26') {
        $sql = preg_replace('/^\s*SET\s+@p_farmer_id\s*=\s*\d+\s*;\s*/i', '', $sql) ?? $sql;
        $sql = str_replace('@p_farmer_id', (string)$userId, $sql);
    } elseif ($code === '29') {
        $sql = preg_replace('/WHERE\s+il\.irrlog_zone_id\s*=\s*\d+/i', 'WHERE il.irrlog_zone_id = ' . $zoneId, $sql) ?? $sql;
    }

    return $sql;
}

function bq_strip_sql_comments(string $sql): string
{
    $out = [];
    foreach (preg_split('/\R/u', $sql) ?: [] as $line) {
        if (str_starts_with(ltrim($line), '--')) {
            continue;
        }
        $out[] = bq_strip_line_comment($line);
    }

    return trim(implode("\n", $out));
}

function bq_strip_line_comment(string $line): string
{
    $inQuote = false;
    $len = strlen($line);
    for ($i = 0; $i < $len - 1; $i++) {
        $ch = $line[$i];
        if ($ch === "'" && ($i === 0 || $line[$i - 1] !== '\\')) {
            $inQuote = !$inQuote;
        }
        if (!$inQuote && $line[$i] === '-' && $line[$i + 1] === '-') {
            return rtrim(substr($line, 0, $i));
        }
    }

    return $line;
}

function bq05_call_adjust_irrigation(mysqli $conn, float $rainThreshold, int $managerId): ?string
{
    if (!function_exists('irrigation_apply_weather_rules')) {
        require_once __DIR__ . '/irrigation_engine.php';
    }
    $updates = irrigation_apply_weather_rules($conn);

    return $updates ? implode('; ', $updates) : 'Không có lịch tưới cần điều chỉnh theo thời tiết.';
}

function bq_render_table(array $rows): void
{
    if (!$rows) {
        echo '<p class="muted" style="padding:12px;background:#f8fafc;border-radius:8px;border:1px dashed #cbd5e1">'
            . 'Không có dòng kết quả trong dữ liệu hiện tại.</p>';
        return;
    }
    $headers = array_keys($rows[0]);
    echo '<div class="tbl-wrap"><table class="dtbl"><thead><tr>';
    foreach ($headers as $h) {
        echo '<th>' . htmlspecialchars($h, ENT_QUOTES, 'UTF-8') . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr>';
        foreach ($headers as $h) {
            echo '<td>' . htmlspecialchars((string)($row[$h] ?? ''), ENT_QUOTES, 'UTF-8') . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}
