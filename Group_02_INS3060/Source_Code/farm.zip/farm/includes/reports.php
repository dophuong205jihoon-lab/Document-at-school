<?php
/**
 * Chạy Business Query (BQ-01 … BQ-30) bằng mysqli.
 */
require_once __DIR__ . '/report_definitions.php';

function report_run(mysqli $conn, string $code, array $ctx = []): array
{
    $defs = report_definitions();
    $def = $defs[$code] ?? null;
    if (!$def || empty($def['executable'])) {
        return [];
    }

    if (($def['ensure_view'] ?? '') === 'vw_zone_health_summary') {
        db_ensure_zone_health_view($conn);
    }
    if (($def['ensure_procedure'] ?? '') === 'sp_farmer_zone_dashboard') {
        db_ensure_farmer_zone_dashboard_proc($conn);
    }

    $sql = trim($def['sql']);
    $types = '';
    $params = [];

    if (($def['params'] ?? null) === 'demo_date') {
        $types = 's';
        $params = [REPORT_DEMO_DATE];
    } elseif (($def['params'] ?? null) === 'farmer') {
        $uid = (int)($ctx['userId'] ?? 0);
        if ($uid <= 0) {
            return [];
        }
        $types = 'i';
        $params = [$uid];
    }

    if ($types !== '') {
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            return [];
        }
        mysqli_stmt_bind_param($stmt, $types, ...$params);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $rows = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
        while (mysqli_more_results($conn)) {
            mysqli_next_result($conn);
        }

        return $rows;
    }

    $result = mysqli_query($conn, $sql);

    return $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}
