<?php
/**
 * Protected app bootstrap: DB + auth + RBAC helpers.
 * Call rbac_middleware() after including this file.
 */
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/db_schema.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/rbac.php';

db_ensure_alert_reading_trigger($conn);
