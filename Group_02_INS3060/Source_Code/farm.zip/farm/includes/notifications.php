<?php

function notify_ensure_table(mysqli $conn): void
{
    static $done = false;
    if ($done) {
        return;
    }
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS notifications (
        notification_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NULL,
        zone_id INT UNSIGNED NULL,
        alert_id INT UNSIGNED NULL,
        title VARCHAR(200) NOT NULL,
        message VARCHAR(500) NOT NULL,
        priority ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        digest_key VARCHAR(32) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (notification_id),
        KEY idx_user_read (user_id, is_read, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done = true;
}

/**
 * FR-13: critical ngay; warning gom theo giờ (digest_key).
 */
function notify_from_alert(mysqli $conn, array $alert, int $zoneId): void
{
    notify_ensure_table($conn);

    $priority = $alert['priority'] ?? 'warning';
    $priority = $alert['alert_priority'] ?? $priority;
    $title = 'Cảnh báo Zone';
    $message = $alert['message'] ?? '';
    $message = $alert['alert_message'] ?? $message;
    $alertId = (int)($alert['alert_id'] ?? 0);

    $digestKey = null;
    if ($priority === 'warning') {
        $digestKey = 'warn_' . date('YmdH') . '_z' . $zoneId . '_' . md5(substr($message, 0, 80));
        $dup = mysqli_prepare($conn, 'SELECT notification_id FROM notifications WHERE digest_key = ? LIMIT 1');
        mysqli_stmt_bind_param($dup, 's', $digestKey);
        mysqli_stmt_execute($dup);
        if (mysqli_fetch_assoc(mysqli_stmt_get_result($dup))) {
            return;
        }
    }

    $roles = [
        'farmer' => "SELECT u.user_id FROM users u
                     JOIN user_zone_assignment uza ON uza.assign_user_id = u.user_id AND uza.assign_is_active = 1
                     WHERE u.user_role = 'farmer' AND uza.assign_zone_id = ? AND u.user_status = 'active'",
        'manager' => "SELECT user_id FROM users WHERE user_role IN ('manager','admin') AND user_status = 'active'",
    ];

    $farmerStmt = mysqli_prepare($conn, $roles['farmer']);
    mysqli_stmt_bind_param($farmerStmt, 'i', $zoneId);
    mysqli_stmt_execute($farmerStmt);
    $farmerIds = array_column(mysqli_fetch_all(mysqli_stmt_get_result($farmerStmt), MYSQLI_ASSOC), 'user_id');

    $managerRows = mysqli_fetch_all(mysqli_query($conn, $roles['manager']), MYSQLI_ASSOC);
    $managerIds = array_column($managerRows, 'user_id');

    $userIds = array_unique(array_merge($farmerIds, $managerIds));
    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO notifications (user_id, zone_id, alert_id, title, message, priority, digest_key)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );

    foreach ($userIds as $userId) {
        $uid = (int)$userId;
        $aid = $alertId > 0 ? $alertId : null;
        mysqli_stmt_bind_param($stmt, 'iiissss', $uid, $zoneId, $aid, $title, $message, $priority, $digestKey);
        mysqli_stmt_execute($stmt);
    }
}

function notify_count_unread(mysqli $conn, int $userId): int
{
    notify_ensure_table($conn);
    $stmt = mysqli_prepare($conn, 'SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0');
    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);

    return (int)(mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['c'] ?? 0);
}

function notify_list(mysqli $conn, int $userId, int $limit = 20): array
{
    notify_ensure_table($conn);
    $stmt = mysqli_prepare(
        $conn,
        'SELECT n.*, z.zone_code FROM notifications n
         LEFT JOIN zones z ON z.zone_id = n.zone_id
         WHERE n.user_id = ? ORDER BY n.created_at DESC LIMIT ?'
    );
    mysqli_stmt_bind_param($stmt, 'ii', $userId, $limit);
    mysqli_stmt_execute($stmt);

    return mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
}

function notify_mark_read(mysqli $conn, int $userId, int $notificationId): void
{
    $stmt = mysqli_prepare(
        $conn,
        'UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?'
    );
    mysqli_stmt_bind_param($stmt, 'ii', $notificationId, $userId);
    mysqli_stmt_execute($stmt);
}
