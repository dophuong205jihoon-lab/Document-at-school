<?php
/**
 * FR-17: Xuất báo cáo HTML in/PDF (trình duyệt → In → Lưu PDF).
 */

/** @return array{title: string, headers: list<string>, rows: list<list<string|int|float|null>>} */
function report_dataset(mysqli $conn, string $type, int $days): array
{
    $days = max(1, min(90, $days));

    if ($type === 'moisture') {
        $rows = mysqli_fetch_all(mysqli_query(
            $conn,
            "SELECT z.zone_code, sr.reading_recorded_at AS recorded_at, sr.reading_value AS value
             FROM sensor_readings sr
             JOIN sensors s ON s.sensor_id = sr.reading_sensor_id
             JOIN zones z ON z.zone_id = s.sensor_zone_id
             WHERE s.sensor_type = 'soil_moisture' AND sr.reading_is_valid = 1
               AND sr.reading_recorded_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
             ORDER BY sr.reading_recorded_at DESC LIMIT 500"
        ), MYSQLI_ASSOC);

        return [
            'title' => "Báo cáo ẩm đất ({$days} ngày)",
            'headers' => ['Zone', 'Thời gian', 'Ẩm %'],
            'rows' => array_map(static fn($r) => [$r['zone_code'], $r['recorded_at'], $r['value']], $rows),
        ];
    }

    if ($type === 'temperature') {
        $rows = mysqli_fetch_all(mysqli_query(
            $conn,
            "SELECT z.zone_code, sr.reading_recorded_at AS recorded_at, sr.reading_value AS value
             FROM sensor_readings sr
             JOIN sensors s ON s.sensor_id = sr.reading_sensor_id
             JOIN zones z ON z.zone_id = s.sensor_zone_id
             WHERE s.sensor_type = 'temperature' AND sr.reading_is_valid = 1
               AND sr.reading_recorded_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
             ORDER BY sr.reading_recorded_at DESC LIMIT 500"
        ), MYSQLI_ASSOC);

        return [
            'title' => "Báo cáo nhiệt độ ({$days} ngày)",
            'headers' => ['Zone', 'Thời gian', '°C'],
            'rows' => array_map(static fn($r) => [$r['zone_code'], $r['recorded_at'], $r['value']], $rows),
        ];
    }

    if ($type === 'irrigation') {
        $rows = mysqli_fetch_all(mysqli_query(
            $conn,
            "SELECT z.zone_code,
                    l.irrlog_started_at AS started_at,
                    l.irrlog_actual_duration_min AS actual_duration_min,
                    l.irrlog_water_used_liters AS water_used_liters,
                    l.irrlog_trigger_type AS trigger_type,
                    l.irrlog_status AS status
             FROM irrigation_logs l JOIN zones z ON z.zone_id = l.irrlog_zone_id
             WHERE l.irrlog_started_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
             ORDER BY l.irrlog_started_at DESC LIMIT 500"
        ), MYSQLI_ASSOC);

        return [
            'title' => "Báo cáo tưới ({$days} ngày)",
            'headers' => ['Zone', 'Bắt đầu', 'Phút', 'Lít', 'Kích hoạt', 'TT'],
            'rows' => array_map(static fn($r) => [
                $r['zone_code'], $r['started_at'], $r['actual_duration_min'],
                $r['water_used_liters'], $r['trigger_type'], $r['status'],
            ], $rows),
        ];
    }

    $rows = mysqli_fetch_all(mysqli_query(
        $conn,
        "SELECT z.zone_code, hr.harvest_date,
                hr.harvest_weight_kg AS weight_kg,
                hr.harvest_grade AS grade,
                hr.harvest_new_shoots_count AS new_shoots_count
         FROM harvest_records hr JOIN zones z ON z.zone_id = hr.harvest_zone_id
         WHERE hr.harvest_date >= DATE_SUB(CURDATE(), INTERVAL {$days} DAY)
         ORDER BY hr.harvest_date DESC LIMIT 500"
    ), MYSQLI_ASSOC);

    return [
        'title' => "Báo cáo thu hoạch ({$days} ngày)",
        'headers' => ['Zone', 'Ngày', 'Kg', 'Hạng', 'Chồi mới'],
        'rows' => array_map(static fn($r) => [
            $r['zone_code'], $r['harvest_date'], $r['weight_kg'], $r['grade'], $r['new_shoots_count'],
        ], $rows),
    ];
}

function report_render_printable_html(string $title, array $headers, array $rows, string $generatedBy): void
{
    header('Content-Type: text/html; charset=utf-8');
    ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></title>
    <style>
        body { font-family: system-ui, sans-serif; margin: 24px; color: #111; }
        h1 { font-size: 20px; margin: 0 0 8px; }
        .meta { color: #555; font-size: 13px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; font-size: 12px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
        th { background: #f3f4f6; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>
    <p class="no-print"><button onclick="window.print()">In / Lưu PDF</button></p>
    <h1><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></h1>
    <p class="meta">Aloe Farm Dashboard · <?php echo htmlspecialchars($generatedBy, ENT_QUOTES, 'UTF-8'); ?>
        · <?php echo date('Y-m-d H:i'); ?></p>
    <table>
        <thead><tr><?php foreach ($headers as $h): ?><th><?php echo htmlspecialchars((string)$h, ENT_QUOTES, 'UTF-8'); ?></th><?php endforeach; ?></tr></thead>
        <tbody>
        <?php if (!$rows): ?>
            <tr><td colspan="<?php echo count($headers); ?>">Không có dữ liệu.</td></tr>
        <?php else: ?>
            <?php foreach ($rows as $row): ?>
                <tr><?php foreach ($row as $cell): ?><td><?php echo htmlspecialchars((string)$cell, ENT_QUOTES, 'UTF-8'); ?></td><?php endforeach; ?></tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
    <?php
    exit;
}
