<?php
require_once __DIR__ . '/rbac.php';

function ui_initials(string $fullName): string
{
    $parts = preg_split('/\s+/u', trim($fullName)) ?: [];
    if (count($parts) >= 2) {
        return mb_strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[count($parts) - 1], 0, 1));
    }

    return mb_strtoupper(mb_substr($fullName, 0, 2));
}

function ui_priority_badge(string $priority): string
{
    $class = match ($priority) {
        'critical' => 'badge-red',
        'warning' => 'badge-amber',
        default => 'badge-gray',
    };

    return '<span class="badge ' . $class . '">' . htmlspecialchars($priority) . '</span>';
}

function ui_stat_card(string $label, string $value, string $tagsHtml, string $accent, string $icon): void
{
    ?>
    <div class="stat-card" style="--accent:<?php echo $accent; ?>">
        <div class="stat-icon"><?php echo $icon; ?></div>
        <div class="stat-value"><?php echo $value; ?></div>
        <div class="stat-label"><?php echo htmlspecialchars($label); ?></div>
        <div class="stat-tags"><?php echo $tagsHtml; ?></div>
    </div>
    <?php
}

function ui_filter_bar_open(): string
{
    return '<div class="dash-filter-bar"><div class="dash-filter-fields">';
}

function ui_filter_bar_close(): string
{
    return '</div></div>';
}

/** @param array<string, string> $options */
function ui_filter_select(string $label, string $dataAttr, array $options): string
{
    $attr = htmlspecialchars($dataAttr, ENT_QUOTES, 'UTF-8');
    $html = '<label class="dash-filter-item"><span class="dash-filter-label">' . htmlspecialchars($label) . '</span>';
    $html .= '<select ' . $attr . ' class="dash-filter-input">';
    foreach ($options as $value => $text) {
        $html .= '<option value="' . htmlspecialchars((string)$value) . '">' . htmlspecialchars($text) . '</option>';
    }
    $html .= '</select></label>';

    return $html;
}

function ui_filter_search(string $label, string $placeholder): string
{
    return '<label class="dash-filter-item dash-filter-grow"><span class="dash-filter-label">'
        . htmlspecialchars($label)
        . '</span><input type="search" data-filter-search class="dash-filter-input" placeholder="'
        . htmlspecialchars($placeholder) . '"></label>';
}

/** @param callable(string): bool $canPage */
function ui_render_sidebar_nav(mysqli $conn, string $role, string $currentPage, callable $canPage): void
{
    require_once __DIR__ . '/nav_config.php';
    require_once __DIR__ . '/reports.php';

    $adminOps = $role === 'admin' && str_contains($_SERVER['REQUEST_URI'] ?? '', 'view=ops');
    $activePage = nav_sanitize_page((string)($_GET['page'] ?? 'overview'), $role, $adminOps);
    $badges = nav_badge_counts($conn, $role, $adminOps);

    foreach (nav_items_for_role($role, $adminOps) as $item) {
        $page = $item['page'];
        if ($page === 'ops') {
            $href = $item['href'] ?? 'dashboard.php?view=ops&page=overview';
            $active = $adminOps;
            $cls = 'nav-item' . ($active ? ' active' : '');
            echo '<a class="' . $cls . '" href="' . htmlspecialchars($href) . '">';
            echo '<span class="nav-icon">' . ui_nav_icon($item['icon'] ?? 'farm') . '</span>';
            echo '<span class="nav-label">' . htmlspecialchars($item['label']) . '</span>';
            echo '</a>';
            continue;
        }

        if (!$canPage('dashboard.php')) {
            continue;
        }

        $href = nav_dashboard_url($page, $role, $adminOps);
        $active = $activePage === $page;
        $cls = 'nav-item' . ($active ? ' active' : '');
        echo '<a class="' . $cls . '" href="' . htmlspecialchars($href) . '">';
        echo '<span class="nav-icon">' . ui_nav_icon($item['icon'] ?? 'grid') . '</span>';
        echo '<span class="nav-label">' . htmlspecialchars($item['label']) . '</span>';

        $badgeKey = $item['badge_key'] ?? '';
        if ($badgeKey !== '' && !empty($badges[$badgeKey])) {
            $n = (int)$badges[$badgeKey];
            $color = match ($badgeKey) {
                'alerts' => 'red',
                'harvest' => 'amber',
                default => 'blue',
            };
            echo '<span class="nav-badge ' . $color . '">' . $n . '</span>';
        }

        echo '</a>';
    }
}

function ui_nav_icon(string $icon): string
{
    return match ($icon) {
        'grid' => '📊',
        'alert' => '🔔',
        'water' => '💧',
        'weather' => '🌤',
        'harvest' => '🌾',
        'ai' => '🤖',
        'zones' => '🗺',
        'sensor' => '📡',
        'users' => '👥',
        'log' => '📋',
        'farm' => '🌱',
        default => '•',
    };
}
