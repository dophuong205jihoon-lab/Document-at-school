<?php

/** @var array<string, array{label: string, unit: string, min: float, max: float, icon: string}> */
const SENSOR_TYPES = [
    'soil_moisture' => [
        'label' => 'Độ ẩm đất',
        'unit' => '%',
        'min' => 30.0,
        'max' => 70.0,
        'icon' => '💧',
    ],
    'temperature' => [
        'label' => 'Nhiệt độ không khí',
        'unit' => '°C',
        'min' => 18.0,
        'max' => 38.0,
        'icon' => '🌡️',
    ],
    'humidity' => [
        'label' => 'Độ ẩm không khí',
        'unit' => '%',
        'min' => 40.0,
        'max' => 85.0,
        'icon' => '💨',
    ],
    'ph' => [
        'label' => 'pH đất',
        'unit' => 'pH',
        'min' => 5.5,
        'max' => 7.5,
        'icon' => '⚗️',
    ],
    'ec' => [
        'label' => 'EC (độ dẫn điện)',
        'unit' => 'mS/cm',
        'min' => 0.5,
        'max' => 3.0,
        'icon' => '⚡',
    ],
];

const SENSOR_REQUIRED_SOIL = 'soil_moisture';
const SENSOR_REQUIRED_TEMP = 'temperature';

/**
 * Dải vật lý hợp lệ (FR-07) — ngoài dải → is_valid=0, không dùng tính toán.
 * @var array<string, array{min: float, max: float}>
 */
const SENSOR_PHYSICAL_RANGES = [
    'soil_moisture' => ['min' => 0.0, 'max' => 100.0],
    'temperature' => ['min' => -10.0, 'max' => 60.0],
    'humidity' => ['min' => 0.0, 'max' => 100.0],
    'ph' => ['min' => 3.0, 'max' => 9.0],
    'ec' => ['min' => 0.0, 'max' => 20.0],
];

/**
 * @return array{valid: bool, reason: ?string}
 */
function sensor_validate_physical(string $sensorType, float $value): array
{
    if (!isset(SENSOR_PHYSICAL_RANGES[$sensorType])) {
        return ['valid' => false, 'reason' => 'Loại cảm biến không hỗ trợ.'];
    }

    $range = SENSOR_PHYSICAL_RANGES[$sensorType];
    $label = sensor_type_label($sensorType);
    $unit = sensor_default_unit($sensorType);

    if ($value < $range['min'] || $value > $range['max']) {
        return [
            'valid' => false,
            'reason' => sprintf(
                '%s %.4f%s ngoài dải hợp lệ [%.1f – %.1f%s]',
                $label,
                $value,
                $unit,
                $range['min'],
                $range['max'],
                $unit
            ),
        ];
    }

    return ['valid' => true, 'reason' => null];
}

function sensor_physical_range_text(string $sensorType): string
{
    if (!isset(SENSOR_PHYSICAL_RANGES[$sensorType])) {
        return '—';
    }
    $r = SENSOR_PHYSICAL_RANGES[$sensorType];
    $u = sensor_default_unit($sensorType);

    return $r['min'] . ' – ' . $r['max'] . $u;
}

function sensor_type_label(string $type): string
{
    return SENSOR_TYPES[$type]['label'] ?? $type;
}

function sensor_default_unit(string $type): string
{
    return SENSOR_TYPES[$type]['unit'] ?? '';
}

function sensor_is_valid_type(string $type): bool
{
    return isset(SENSOR_TYPES[$type]);
}

/**
 * @return array{ok: bool, soil: int, temp: int, compliant: bool}
 */
function sensor_zone_compliance(mysqli $conn, int $zoneId): array
{
    $stmt = mysqli_prepare(
        $conn,
        "SELECT sensor_type, COUNT(*) AS c FROM sensors
         WHERE sensor_zone_id = ? AND sensor_status = 'active'
         GROUP BY sensor_type"
    );
    mysqli_stmt_bind_param($stmt, 'i', $zoneId);
    mysqli_stmt_execute($stmt);
    $rows = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

    $soil = 0;
    $temp = 0;
    foreach ($rows as $r) {
        if ($r['sensor_type'] === SENSOR_REQUIRED_SOIL) {
            $soil = (int)$r['c'];
        }
        if ($r['sensor_type'] === SENSOR_REQUIRED_TEMP) {
            $temp = (int)$r['c'];
        }
    }

    return [
        'ok' => true,
        'soil' => $soil,
        'temp' => $temp,
        'compliant' => $soil >= 1 && $temp >= 1,
    ];
}

/**
 * @return list<array{zone_id: int, zone_code: string, soil: int, temp: int, compliant: bool}>
 */
function sensor_all_zones_compliance(mysqli $conn): array
{
    $zones = mysqli_fetch_all(
        mysqli_query($conn, 'SELECT zone_id, zone_code FROM zones ORDER BY zone_code'),
        MYSQLI_ASSOC
    );
    $out = [];
    foreach ($zones as $z) {
        $c = sensor_zone_compliance($conn, (int)$z['zone_id']);
        $out[] = [
            'zone_id' => (int)$z['zone_id'],
            'zone_code' => $z['zone_code'],
            'soil' => $c['soil'],
            'temp' => $c['temp'],
            'compliant' => $c['compliant'],
        ];
    }

    return $out;
}

/**
 * @return array{ok: bool, is_valid: bool, reason: ?string, reading_id: ?int}
 */
function sensor_record_reading(
    mysqli $conn,
    int $sensorId,
    string $sensorType,
    float $value,
    ?string $recordedAt = null
): array {
    $validation = sensor_validate_physical($sensorType, $value);
    $isValid = $validation['valid'] ? 1 : 0;
    $at = $recordedAt ?? date('Y-m-d H:i:s');

    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO sensor_readings (reading_sensor_id, reading_value, reading_recorded_at, reading_is_valid) VALUES (?, ?, ?, ?)'
    );
    mysqli_stmt_bind_param($stmt, 'idsi', $sensorId, $value, $at, $isValid);

    if (!mysqli_stmt_execute($stmt)) {
        return ['ok' => false, 'is_valid' => false, 'reason' => mysqli_error($conn), 'reading_id' => null];
    }

    return [
        'ok' => true,
        'is_valid' => (bool)$isValid,
        'reason' => $validation['reason'],
        'reading_id' => (int)mysqli_insert_id($conn),
    ];
}

function sensor_check_anomaly_alert(mysqli $conn, array $sensor, float $value, string $reason): void
{
    // Schema moi khong co alert_type=data_anomaly; invalid reading duoc luu voi reading_is_valid=0 de bao cao chat luong du lieu.
}

function sensor_check_threshold_alert(mysqli $conn, array $sensor, float $value): void
{
    if ($sensor['sensor_status'] !== 'active') {
        return;
    }

    $min = $sensor['sensor_min_threshold'] !== null ? (float)$sensor['sensor_min_threshold'] : null;
    $max = $sensor['sensor_max_threshold'] !== null ? (float)$sensor['sensor_max_threshold'] : null;
    $zoneId = (int)$sensor['sensor_zone_id'];
    $sensorId = (int)$sensor['sensor_id'];
    $label = sensor_type_label($sensor['sensor_type']);
    $unit = $sensor['sensor_unit'];

    $alertType = null;
    $priority = 'warning';
    $message = null;

    if ($max !== null && $value > $max) {
        $alertType = 'threshold_high';
        $message = "{$label} vượt ngưỡng: {$value}{$unit} (max {$max}{$unit})";
        $priority = 'critical';
    } elseif ($min !== null && $value < $min) {
        $alertType = 'threshold_low';
        $message = "{$label} dưới ngưỡng: {$value}{$unit} (min {$min}{$unit})";
    }

    if (!$alertType || !$message) {
        return;
    }

    $dup = mysqli_prepare(
        $conn,
        'SELECT alert_id FROM alerts WHERE alert_sensor_id = ? AND alert_type = ? AND alert_is_resolved = 0
         AND alert_triggered_at > DATE_SUB(NOW(), INTERVAL 1 HOUR) LIMIT 1'
    );
    mysqli_stmt_bind_param($dup, 'is', $sensorId, $alertType);
    mysqli_stmt_execute($dup);
    if (mysqli_fetch_assoc(mysqli_stmt_get_result($dup))) {
        return;
    }

    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO alerts (alert_sensor_id, alert_zone_id, alert_type, alert_priority, alert_message, alert_triggered_value)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    mysqli_stmt_bind_param($stmt, 'iisssd', $sensorId, $zoneId, $alertType, $priority, $message, $value);
    mysqli_stmt_execute($stmt);
}

function sensor_ingest_by_code(mysqli $conn, string $sensorCode, float $value, ?string $recordedAt = null): array
{
    $stmt = mysqli_prepare(
        $conn,
        'SELECT sensor_id, sensor_zone_id, sensor_type, sensor_unit, sensor_min_threshold, sensor_max_threshold, sensor_status
         FROM sensors WHERE sensor_code = ? LIMIT 1'
    );
    mysqli_stmt_bind_param($stmt, 's', $sensorCode);
    mysqli_stmt_execute($stmt);
    $sensor = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$sensor) {
        return ['ok' => false, 'error' => 'Sensor code not found.'];
    }
    if ($sensor['sensor_status'] !== 'active') {
        return ['ok' => false, 'error' => 'Sensor is not active.'];
    }

    $record = sensor_record_reading(
        $conn,
        (int)$sensor['sensor_id'],
        $sensor['sensor_type'],
        $value,
        $recordedAt
    );

    if (!$record['ok']) {
        return ['ok' => false, 'error' => $record['reason'] ?? 'Insert failed'];
    }

    if ($record['is_valid']) {
        if (!function_exists('bq_has_trigger_alert')) {
            require_once __DIR__ . '/bq_repository.php';
        }
        if (!bq_has_trigger_alert($conn)) {
            sensor_check_threshold_alert($conn, $sensor, $value);
        }
        if (!function_exists('alert_check_zone_sensors')) {
            require_once __DIR__ . '/alerts_engine.php';
        }
        alert_check_zone_sensors($conn, (int)$sensor['sensor_zone_id']);
    } else {
        sensor_check_anomaly_alert($conn, $sensor, $value, (string)$record['reason']);
    }

    return [
        'ok' => true,
        'sensor_id' => (int)$sensor['sensor_id'],
        'zone_id' => (int)$sensor['sensor_zone_id'],
        'value' => $value,
        'is_valid' => $record['is_valid'],
        'invalid_reason' => $record['reason'],
        'reading_id' => $record['reading_id'],
    ];
}
