<?php
/** Auto từ businessQueries.js — 30 BQ */
const REPORT_DEMO_DATE = '2025-06-03';
function report_definitions(): array {
    return [
        'BQ-01' => [
            'title' => 'Admin xem danh sách user theo role',
            'role' => 'admin',
            'sql' => 'SELECT user_id, user_username, user_full_name, user_role, user_status, user_last_login
FROM users
WHERE user_status = \'active\'
ORDER BY user_role, user_full_name',
            'params' => null,
            'executable' => true,
        ],
        'BQ-02' => [
            'title' => 'Manager xem trạng thái các Zone',
            'role' => 'manager',
            'sql' => 'SELECT zone_code, zone_name, zone_area_m2, zone_soil_type, zone_status
FROM zones
ORDER BY zone_code',
            'params' => null,
            'executable' => true,
        ],
        'BQ-03' => [
            'title' => 'Manager xem Farmer đang phụ trách Zone nào',
            'role' => 'manager',
            'sql' => 'SELECT u.user_full_name AS farmer_name,
       z.zone_code,
       z.zone_name,
       uza.assign_assigned_at
FROM user_zone_assignment uza
JOIN users u ON uza.assign_user_id = u.user_id
JOIN zones z ON uza.assign_zone_id = z.zone_id
WHERE uza.assign_is_active = 1
ORDER BY z.zone_code',
            'params' => null,
            'executable' => true,
        ],
        'BQ-04' => [
            'title' => 'Manager xem sensor đang lỗi hoặc inactive',
            'role' => 'manager',
            'sql' => 'SELECT s.sensor_code, s.sensor_type, s.sensor_status,
       z.zone_code, z.zone_name
FROM sensors s
JOIN zones z ON s.sensor_zone_id = z.zone_id
WHERE s.sensor_status IN (\'inactive\', \'error\')
ORDER BY z.zone_code, s.sensor_type',
            'params' => null,
            'executable' => true,
        ],
        'BQ-05' => [
            'title' => 'Manager xem cảnh báo chưa xử lý',
            'role' => 'manager',
            'sql' => 'SELECT a.alert_id, z.zone_code, s.sensor_code,
       a.alert_type, a.alert_priority, a.alert_message,
       a.alert_triggered_at
FROM alerts a
JOIN zones z ON a.alert_zone_id = z.zone_id
JOIN sensors s ON a.alert_sensor_id = s.sensor_id
WHERE a.alert_is_resolved = 0
ORDER BY FIELD(a.alert_priority, \'critical\', \'warning\', \'info\'),
         a.alert_triggered_at DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-06' => [
            'title' => 'Manager xem lịch tưới đang active',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       isch.schedule_name,
       isch.schedule_cron_expr,
       isch.schedule_duration_minutes,
       isch.schedule_water_rate_l_m2,
       isch.schedule_is_auto_adjust
FROM irrigation_schedules isch
JOIN zones z ON isch.schedule_zone_id = z.zone_id
WHERE isch.schedule_is_active = 1
ORDER BY z.zone_code, isch.schedule_cron_expr',
            'params' => null,
            'executable' => true,
        ],
        'BQ-07' => [
            'title' => 'Manager xem lần tưới đang in-progress',
            'role' => 'manager',
            'sql' => 'SELECT il.irrlog_id, z.zone_code, z.zone_name,
       il.irrlog_started_at,
       il.irrlog_trigger_type,
       il.irrlog_soil_moisture_before,
       il.irrlog_status
FROM irrigation_logs il
JOIN zones z ON il.irrlog_zone_id = z.zone_id
WHERE il.irrlog_status = \'in_progress\'
ORDER BY il.irrlog_started_at DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-08' => [
            'title' => 'Manager xem thu hoạch đang chờ duyệt',
            'role' => 'manager',
            'sql' => 'SELECT h.harvest_id, z.zone_code, z.zone_name,
       u.user_full_name AS recorded_by,
       h.harvest_date,
       h.harvest_weight_kg,
       h.harvest_grade,
       h.harvest_notes
FROM harvest_records h
JOIN zones z ON h.harvest_zone_id = z.zone_id
JOIN users u ON h.harvest_recorded_by = u.user_id
WHERE h.harvest_status = \'pending\'
ORDER BY h.harvest_date DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-09' => [
            'title' => 'Manager xem dự báo thời tiết 7 ngày',
            'role' => 'manager',
            'sql' => 'SELECT weather_forecast_date,
       weather_temp_max,
       weather_temp_min,
       weather_humidity,
       weather_rainfall_mm,
       weather_condition
FROM weather_data
WHERE weather_is_forecast = 1
ORDER BY weather_forecast_date',
            'params' => null,
            'executable' => true,
        ],
        'BQ-10' => [
            'title' => 'Admin xem audit log gần nhất',
            'role' => 'admin',
            'sql' => 'SELECT al.audit_id,
       u.user_full_name,
       al.audit_action,
       al.audit_table_name,
       al.audit_record_id,
       al.audit_ip_address,
       al.audit_logged_at
FROM audit_logs al
LEFT JOIN users u ON al.audit_user_id = u.user_id
ORDER BY al.audit_logged_at DESC
LIMIT 20',
            'params' => null,
            'executable' => true,
        ],
        'BQ-11' => [
            'title' => 'Manager xem Zone có độ ẩm trung bình thấp',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       ROUND(AVG(sr.reading_value), 2) AS avg_soil_moisture,
       MIN(sr.reading_value) AS min_soil_moisture,
       COUNT(*) AS total_readings
FROM sensor_readings sr
JOIN sensors s ON sr.reading_sensor_id = s.sensor_id
JOIN zones z ON s.sensor_zone_id = z.zone_id
WHERE s.sensor_type = \'soil_moisture\'
  AND sr.reading_is_valid = 1
  AND sr.reading_recorded_at >= DATE_SUB(?, INTERVAL 7 DAY)
GROUP BY z.zone_id, z.zone_code, z.zone_name
HAVING AVG(sr.reading_value) < 60
ORDER BY avg_soil_moisture ASC',
            'params' => 'demo_date',
            'executable' => true,
        ],
        'BQ-12' => [
            'title' => 'Manager xem Zone có độ ẩm quá cao, nguy cơ root rot',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       ROUND(AVG(sr.reading_value), 2) AS avg_moisture,
       MAX(sr.reading_value) AS max_moisture,
       SUM(CASE WHEN sr.reading_value > 85 THEN 1 ELSE 0 END) AS high_readings
FROM sensor_readings sr
JOIN sensors s ON sr.reading_sensor_id = s.sensor_id
JOIN zones z ON s.sensor_zone_id = z.zone_id
WHERE s.sensor_type = \'soil_moisture\'
  AND sr.reading_is_valid = 1
GROUP BY z.zone_id, z.zone_code, z.zone_name
HAVING MAX(sr.reading_value) > 85
ORDER BY max_moisture DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-13' => [
            'title' => 'Manager xem số alert theo Zone và mức độ',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       COUNT(a.alert_id) AS total_alerts,
       SUM(CASE WHEN a.alert_priority = \'critical\' THEN 1 ELSE 0 END) AS critical_alerts,
       SUM(CASE WHEN a.alert_is_resolved = 0 THEN 1 ELSE 0 END) AS unresolved_alerts
FROM zones z
LEFT JOIN alerts a ON z.zone_id = a.alert_zone_id
GROUP BY z.zone_id, z.zone_code, z.zone_name
ORDER BY critical_alerts DESC, unresolved_alerts DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-14' => [
            'title' => 'Manager xem hiệu quả tưới theo Zone',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       COUNT(il.irrlog_id) AS completed_irrigations,
       ROUND(SUM(il.irrlog_water_used_liters), 2) AS total_water_liters,
       ROUND(AVG(il.irrlog_soil_moisture_after - il.irrlog_soil_moisture_before), 2) AS avg_moisture_gain
FROM irrigation_logs il
JOIN zones z ON il.irrlog_zone_id = z.zone_id
WHERE il.irrlog_status = \'completed\'
GROUP BY z.zone_id, z.zone_code, z.zone_name
ORDER BY avg_moisture_gain DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-15' => [
            'title' => 'Manager xem các lần tưới thất bại',
            'role' => 'manager',
            'sql' => 'SELECT il.irrlog_id, z.zone_code, z.zone_name,
       il.irrlog_started_at,
       il.irrlog_trigger_type,
       il.irrlog_soil_moisture_before,
       il.irrlog_status
FROM irrigation_logs il
JOIN zones z ON il.irrlog_zone_id = z.zone_id
WHERE il.irrlog_status = \'aborted\'
ORDER BY il.irrlog_started_at DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-16' => [
            'title' => 'Manager xem Zone cần tăng hoặc giảm tưới theo AI',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       ap.predict_result_label,
       ap.predict_confidence,
       JSON_UNQUOTE(JSON_EXTRACT(ap.predict_detail_json, \'$.recommended\')) AS recommended_schedule,
       JSON_UNQUOTE(JSON_EXTRACT(ap.predict_detail_json, \'$.water_saving_pct\')) AS water_saving_pct,
       ap.predict_predicted_at
FROM ai_predictions ap
JOIN zones z ON ap.predict_zone_id = z.zone_id
WHERE ap.predict_model_type = \'irrigation_opt\'
ORDER BY ap.predict_confidence DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-17' => [
            'title' => 'Manager xem AI disease risk theo Zone',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       ap.predict_result_label,
       ap.predict_confidence,
       JSON_UNQUOTE(JSON_EXTRACT(ap.predict_detail_json, \'$.disease\')) AS disease_type,
       JSON_UNQUOTE(JSON_EXTRACT(ap.predict_detail_json, \'$.recommendation\')) AS recommendation,
       ap.predict_predicted_at
FROM ai_predictions ap
JOIN zones z ON ap.predict_zone_id = z.zone_id
WHERE ap.predict_model_type = \'disease\'
ORDER BY ap.predict_confidence DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-18' => [
            'title' => 'Manager xem năng suất thu hoạch theo Zone',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       COUNT(h.harvest_id) AS harvest_times,
       ROUND(SUM(h.harvest_weight_kg), 2) AS total_kg,
       ROUND(AVG(h.harvest_weight_kg), 2) AS avg_kg,
       SUM(CASE WHEN h.harvest_grade = \'A\' THEN 1 ELSE 0 END) AS grade_a_count
FROM harvest_records h
JOIN zones z ON h.harvest_zone_id = z.zone_id
WHERE h.harvest_status = \'approved\'
GROUP BY z.zone_id, z.zone_code, z.zone_name
ORDER BY total_kg DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-19' => [
            'title' => 'Manager so sánh sản lượng thực tế với target',
            'role' => 'manager',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       gc.cycle_target_yield_kg,
       ROUND(COALESCE(SUM(h.harvest_weight_kg), 0), 2) AS approved_yield_kg,
       ROUND(COALESCE(SUM(h.harvest_weight_kg), 0) / gc.cycle_target_yield_kg * 100, 2) AS target_completion_pct
FROM growing_cycles gc
JOIN zones z ON gc.cycle_zone_id = z.zone_id
LEFT JOIN harvest_records h
       ON gc.cycle_id = h.harvest_cycle_id
      AND h.harvest_status = \'approved\'
GROUP BY z.zone_id, z.zone_code, z.zone_name, gc.cycle_target_yield_kg
ORDER BY target_completion_pct DESC',
            'params' => null,
            'executable' => true,
        ],
        'BQ-20' => [
            'title' => 'Manager xem ngày nên hoãn/tăng tưới theo thời tiết',
            'role' => 'manager',
            'sql' => 'SELECT weather_forecast_date,
       weather_temp_max,
       weather_rainfall_mm,
       weather_condition,
       CASE
           WHEN weather_rainfall_mm > 10 THEN \'SKIP_IRRIGATION\'
           WHEN weather_temp_max > 35 THEN \'INCREASE_IRRIGATION\'
           ELSE \'NORMAL\'
       END AS irrigation_recommendation
FROM weather_data
WHERE weather_is_forecast = 1
ORDER BY weather_forecast_date',
            'params' => null,
            'executable' => true,
        ],
        'BQ-21' => [
            'title' => 'Dashboard View tổng quan Zone Health',
            'role' => 'manager',
            'sql' => 'SELECT *
FROM vw_zone_health_summary
ORDER BY unresolved_alerts DESC, avg_soil_moisture ASC',
            'params' => null,
            'executable' => true,
            'ensure_view' => 'vw_zone_health_summary',
        ],
        'BQ-22' => [
            'title' => 'Procedure lấy dashboard cho một Farmer',
            'role' => 'farmer',
            'sql' => 'CALL sp_farmer_zone_dashboard(?)',
            'params' => 'farmer',
            'executable' => true,
            'ensure_procedure' => 'sp_farmer_zone_dashboard',
        ],
        'BQ-23' => [
            'title' => 'Trigger tự tạo alert khi sensor reading vượt ngưỡng',
            'role' => 'shared',
            'sql' => '-- TRIGGER trg_create_alert_after_sensor_reading ON sensor_readings (AFTER INSERT)',
            'params' => null,
            'executable' => false,
            'ensure_trigger' => 'trg_create_alert_after_sensor_reading',
        ],
        'BQ-24' => [
            'title' => 'Transaction duyệt bản ghi thu hoạch',
            'role' => 'manager',
            'sql' => '-- TRANSACTION: harvest_engine::harvest_approve()',
            'params' => null,
            'executable' => false,
        ],
        'BQ-25' => [
            'title' => 'Xếp hạng Zone theo sản lượng bằng Window Function',
            'role' => 'manager',
            'sql' => 'WITH zone_yield AS (
    SELECT z.zone_id, z.zone_code, z.zone_name,
           SUM(h.harvest_weight_kg) AS total_yield_kg
    FROM zones z
    JOIN harvest_records h ON z.zone_id = h.harvest_zone_id
    WHERE h.harvest_status = \'approved\'
    GROUP BY z.zone_id, z.zone_code, z.zone_name
)
SELECT zone_code,
       zone_name,
       total_yield_kg,
       RANK() OVER (ORDER BY total_yield_kg DESC) AS yield_rank
FROM zone_yield
ORDER BY yield_rank',
            'params' => null,
            'executable' => true,
        ],
        'BQ-26' => [
            'title' => 'Admin xem số lượng user theo role/status',
            'role' => 'admin',
            'sql' => 'SELECT user_role, user_status, COUNT(*) AS total_users
FROM users
GROUP BY user_role, user_status
ORDER BY user_role, user_status',
            'params' => null,
            'executable' => true,
        ],
        'BQ-27' => [
            'title' => 'Admin xem tài khoản bị khóa hoặc chưa login',
            'role' => 'admin',
            'sql' => 'SELECT user_username, user_full_name, user_role, user_status, user_last_login
FROM users
WHERE user_status = \'locked\' OR user_last_login IS NULL
ORDER BY user_status, user_full_name',
            'params' => null,
            'executable' => true,
        ],
        'BQ-28' => [
            'title' => 'Farmer xem latest sensor readings của Zone mình',
            'role' => 'farmer',
            'sql' => 'SELECT z.zone_code, z.zone_name,
       s.sensor_type, s.sensor_code,
       sr.reading_value, s.sensor_unit,
       sr.reading_recorded_at
FROM user_zone_assignment uza
JOIN zones z ON uza.assign_zone_id = z.zone_id
JOIN sensors s ON z.zone_id = s.sensor_zone_id
JOIN sensor_readings sr ON s.sensor_id = sr.reading_sensor_id
WHERE uza.assign_user_id = ?
  AND uza.assign_is_active = 1
  AND sr.reading_is_valid = 1
  AND sr.reading_recorded_at = (
      SELECT MAX(sr2.reading_recorded_at)
      FROM sensor_readings sr2
      WHERE sr2.reading_sensor_id = s.sensor_id
        AND sr2.reading_is_valid = 1
  )
ORDER BY z.zone_code, s.sensor_type',
            'params' => 'farmer',
            'executable' => true,
        ],
        'BQ-29' => [
            'title' => 'Farmer xem alert chưa xử lý trong Zone mình',
            'role' => 'farmer',
            'sql' => 'SELECT z.zone_code, s.sensor_code,
       a.alert_priority, a.alert_type,
       a.alert_message, a.alert_triggered_at
FROM user_zone_assignment uza
JOIN zones z ON uza.assign_zone_id = z.zone_id
JOIN alerts a ON z.zone_id = a.alert_zone_id
JOIN sensors s ON a.alert_sensor_id = s.sensor_id
WHERE uza.assign_user_id = ?
  AND uza.assign_is_active = 1
  AND a.alert_is_resolved = 0
ORDER BY FIELD(a.alert_priority, \'critical\', \'warning\', \'info\'),
         a.alert_triggered_at DESC',
            'params' => 'farmer',
            'executable' => true,
        ],
        'BQ-30' => [
            'title' => 'Manager dashboard KPI cards',
            'role' => 'manager',
            'sql' => 'SELECT
    (SELECT COUNT(*) FROM zones WHERE zone_status IN (\'active\',\'harvesting\')) AS active_zones,
    (SELECT COUNT(*) FROM alerts WHERE alert_is_resolved = 0) AS unresolved_alerts,
    (SELECT COUNT(*) FROM harvest_records WHERE harvest_status = \'pending\') AS pending_harvests,
    (SELECT COUNT(*) FROM irrigation_logs WHERE irrlog_status = \'in_progress\') AS running_irrigations,
    (SELECT COUNT(*) FROM sensors WHERE sensor_status IN (\'inactive\',\'error\')) AS faulty_sensors',
            'params' => null,
            'executable' => true,
        ],
    ];
}