<?php
require_once __DIR__ . '/db_schema.php';

function irrigation_ensure_valve(mysqli $conn, int $zoneId): void
{
    if (!db_table_exists($conn, 'zone_valves')) {
        return;
    }
    $chk = mysqli_prepare($conn, 'SELECT valve_id FROM zone_valves WHERE zone_id = ?');
    mysqli_stmt_bind_param($chk, 'i', $zoneId);
    mysqli_stmt_execute($chk);
    if (!mysqli_fetch_assoc(mysqli_stmt_get_result($chk))) {
        $code = 'V-Z' . $zoneId;
        $ins = mysqli_prepare($conn, "INSERT INTO zone_valves (zone_id, valve_code, status) VALUES (?, ?, 'closed')");
        mysqli_stmt_bind_param($ins, 'is', $zoneId, $code);
        mysqli_stmt_execute($ins);
    }
}

function irrigation_set_valve(mysqli $conn, int $zoneId, string $status): void
{
    if (!db_table_exists($conn, 'zone_valves')) {
        return;
    }
    irrigation_ensure_valve($conn, $zoneId);
    $stmt = mysqli_prepare($conn, 'UPDATE zone_valves SET status = ? WHERE zone_id = ?');
    mysqli_stmt_bind_param($stmt, 'si', $status, $zoneId);
    mysqli_stmt_execute($stmt);
}

function irrigation_zone_moisture(mysqli $conn, int $zoneId): ?float
{
    $row = mysqli_fetch_assoc(mysqli_query(
        $conn,
        "SELECT sr.reading_value AS value FROM sensors s
         JOIN sensor_readings sr ON sr.reading_id = (
            SELECT reading_id FROM sensor_readings WHERE reading_sensor_id = s.sensor_id AND reading_is_valid = 1
            ORDER BY reading_recorded_at DESC LIMIT 1)
         WHERE s.sensor_zone_id = {$zoneId} AND s.sensor_type = 'soil_moisture' AND s.sensor_status = 'active' LIMIT 1"
    ));

    return $row && $row['value'] !== null ? (float)$row['value'] : null;
}

/** FR-11: hoãn khi mưa > 10mm; tăng tần suất khi >35°C 3 ngày — dùng is_auto_adjust / notes / cột extension */
function irrigation_apply_weather_rules(mysqli $conn): array
{
    $notes = [];
    $todayRain = mysqli_fetch_assoc(mysqli_query(
        $conn,
        'SELECT weather_rainfall_mm AS rainfall_mm FROM weather_data WHERE weather_forecast_date = CURDATE() LIMIT 1'
    ));
    $rain = (float)($todayRain['rainfall_mm'] ?? 0);

    if ($rain > 10) {
        mysqli_query($conn, "UPDATE irrigation_schedules SET schedule_is_auto_adjust = 0,
            schedule_notes = CONCAT(COALESCE(schedule_notes,''), ' [weather_skip] mưa {$rain}mm') WHERE schedule_is_active = 1");
        $notes[] = "Hoãn tưới: mưa dự báo {$rain}mm > 10mm";
    }

    $hotDays = mysqli_fetch_assoc(mysqli_query(
        $conn,
        "SELECT COUNT(*) AS c FROM weather_data
         WHERE weather_forecast_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 2 DAY)
         AND weather_temp_max > 35"
    ));
    if ((int)($hotDays['c'] ?? 0) >= 3) {
        mysqli_query($conn, "UPDATE irrigation_schedules SET schedule_notes = CONCAT(COALESCE(schedule_notes,''), ' [weather_hot]') WHERE schedule_is_active = 1");
        $notes[] = 'Tăng tần suất tưới: nhiệt >35°C liên tục 3 ngày';
    }

    return $notes;
}

function irrigation_log_event(
    mysqli $conn,
    int $scheduleId,
    int $zoneId,
    int $durationMin,
    string $triggerType,
    ?float $moistBefore = null,
    ?float $moistAfter = null,
    ?float $waterLiters = null
): void
{
    $ended = date('Y-m-d H:i:s', time() + $durationMin * 60);
    if (db_column_exists($conn, 'irrigation_logs', 'irrlog_soil_moisture_before')) {
        $stmt = mysqli_prepare(
            $conn,
            'INSERT INTO irrigation_logs
             (irrlog_schedule_id, irrlog_zone_id, irrlog_started_at, irrlog_ended_at, irrlog_actual_duration_min, irrlog_water_used_liters,
              irrlog_trigger_type, irrlog_soil_moisture_before, irrlog_soil_moisture_after, irrlog_status)
             VALUES (?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?)'
        );
        $st = 'completed';
        mysqli_stmt_bind_param(
            $stmt,
            'iisidsdds',
            $scheduleId,
            $zoneId,
            $ended,
            $durationMin,
            $waterLiters,
            $triggerType,
            $moistBefore,
            $moistAfter,
            $st
        );
    } else {
        $stmt = mysqli_prepare(
            $conn,
            'INSERT INTO irrigation_logs (irrlog_schedule_id, irrlog_zone_id, irrlog_started_at, irrlog_actual_duration_min, irrlog_trigger_type, irrlog_status)
             VALUES (?, ?, NOW(), ?, ?, ?)'
        );
        $st = 'completed';
        mysqli_stmt_bind_param($stmt, 'iiiss', $scheduleId, $zoneId, $durationMin, $triggerType, $st);
    }
    mysqli_stmt_execute($stmt);
}

function irrigation_check_moisture_auto(mysqli $conn): array
{
    $triggered = [];
    $schedules = mysqli_fetch_all(
        mysqli_query($conn, 'SELECT s.*, z.zone_code FROM irrigation_schedules s JOIN zones z ON z.zone_id = s.schedule_zone_id WHERE s.schedule_is_active = 1'),
        MYSQLI_ASSOC
    );

    foreach ($schedules as $sch) {
        if (irrigation_weather_skip($conn, $sch)) {
            continue;
        }
        $meta = irrigation_schedule_meta($sch);
        $threshold = $meta['moisture_threshold'];
        $zoneId = (int)$sch['schedule_zone_id'];
        $moist = irrigation_zone_moisture($conn, $zoneId);
        if ($moist === null || $moist >= $threshold) {
            continue;
        }

        irrigation_set_valve($conn, $zoneId, 'open');
        $dur = (int)$sch['schedule_duration_minutes'];
        $rate = (float)($sch['schedule_water_rate_l_m2'] ?? 0);
        $water = $rate > 0 ? round($rate * 10, 2) : null;
        irrigation_log_event($conn, (int)$sch['schedule_id'], $zoneId, $dur, 'auto', $moist, irrigation_zone_moisture($conn, $zoneId), $water);
        irrigation_set_valve($conn, $zoneId, 'closed');
        $triggered[] = $sch['zone_code'] . " (ẩm {$moist}% < {$threshold}%)";
    }

    return $triggered;
}

function irrigation_time_to_cron(string $time): string
{
    $parts = explode(':', $time);

    return sprintf('%d %d * * *', (int)($parts[1] ?? 0), (int)($parts[0] ?? 6));
}
