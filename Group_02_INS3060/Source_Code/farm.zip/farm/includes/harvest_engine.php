<?php

require_once __DIR__ . '/audit.php';

/**
 * BQ-24: duyệt harvest trong transaction + audit log.
 *
 * @return array{ok: bool, error?: string}
 */
function harvest_approve(mysqli $conn, int $harvestId, int $approverId, ?string $ip = null): array
{
    if ($harvestId <= 0 || $approverId <= 0) {
        return ['ok' => false, 'error' => 'Thiếu harvest_id hoặc người duyệt.'];
    }

    $ip ??= client_ip();

    mysqli_begin_transaction($conn);

    try {
        $stmt = mysqli_prepare(
            $conn,
            'UPDATE harvest_records
             SET harvest_status = \'approved\',
                 harvest_approved_by = ?,
                 harvest_approved_at = NOW()
             WHERE harvest_id = ?
               AND harvest_status = \'pending\''
        );
        if (!$stmt) {
            throw new RuntimeException(mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt, 'ii', $approverId, $harvestId);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) !== 1) {
            mysqli_rollback($conn);

            return ['ok' => false, 'error' => 'Bản ghi không tồn tại hoặc không còn trạng thái pending.'];
        }

        $auditStmt = mysqli_prepare(
            $conn,
            'INSERT INTO audit_logs (
                audit_user_id, audit_action, audit_table_name,
                audit_record_id, audit_new_json, audit_ip_address
            )
            VALUES (?, \'UPDATE\', \'harvest_records\', ?, ?, ?)'
        );
        if (!$auditStmt) {
            throw new RuntimeException(mysqli_error($conn));
        }

        $newJson = json_encode(
            ['harvest_status' => 'approved', 'approved_by' => $approverId],
            JSON_UNESCAPED_UNICODE
        );
        mysqli_stmt_bind_param($auditStmt, 'iiss', $approverId, $harvestId, $newJson, $ip);
        mysqli_stmt_execute($auditStmt);

        mysqli_commit($conn);

        return ['ok' => true];
    } catch (Throwable $e) {
        mysqli_rollback($conn);

        return ['ok' => false, 'error' => 'Transaction thất bại: ' . $e->getMessage()];
    }
}
