<?php
require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/db_schema.php';

/** Ngưỡng nha đam FR-12 */
const ALOE_MOISTURE_LOW = 50.0;
const ALOE_MOISTURE_HIGH = 85.0;
const ALOE_MOISTURE_IDEAL_MIN = 60.0;
const ALOE_MOISTURE_IDEAL_MAX = 80.0;
const ALOE_TEMP_CRITICAL = 40.0;
const ALOE_PH_LOW = 6.0;
const ALOE_PH_HIGH = 8.0;

function alert_create_if_new(
    mysqli $conn,
    int $zoneId,
    ?int $sensorId,
    string $type,
    string $priority,
    string $message,
    ?float $value = null
): ?int {
    $dup = mysqli_prepare(
        $conn,
        'SELECT alert_id FROM alerts WHERE alert_zone_id = ? AND alert_type = ? AND alert_is_resolved = 0
         AND alert_triggered_at > DATE_SUB(NOW(), INTERVAL 2 HOUR) LIMIT 1'
    );
    mysqli_stmt_bind_param($dup, 'is', $zoneId, $type);
    mysqli_stmt_execute($dup);
    if (mysqli_fetch_assoc(mysqli_stmt_get_result($dup))) {
        return null;
    }

    if ($sensorId === null) {
        $fallback = mysqli_prepare($conn, 'SELECT sensor_id FROM sensors WHERE sensor_zone_id = ? ORDER BY sensor_id LIMIT 1');
        mysqli_stmt_bind_param($fallback, 'i', $zoneId);
        mysqli_stmt_execute($fallback);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($fallback));
        $sensorId = $row ? (int)$row['sensor_id'] : null;
    }
    if ($sensorId === null) {
        return null;
    }

    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO alerts (alert_sensor_id, alert_zone_id, alert_type, alert_priority, alert_message, alert_triggered_value)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    mysqli_stmt_bind_param($stmt, 'iisssd', $sensorId, $zoneId, $type, $priority, $message, $value);
    mysqli_stmt_execute($stmt);
    $alertId = (int)mysqli_insert_id($conn);

    notify_from_alert($conn, [
        'alert_id' => $alertId,
        'priority' => $priority,
        'message' => $message,
    ], $zoneId);

    return $alertId;
}

function alert_check_zone_sensors(mysqli $conn, int $zoneId): void
{
    $sql = "SELECT s.sensor_id, s.sensor_type, s.sensor_unit AS unit, s.sensor_status AS status,
                   sr.reading_value AS value, sr.reading_recorded_at AS recorded_at
            FROM sensors s
            LEFT JOIN sensor_readings sr ON sr.reading_id = (
                SELECT reading_id FROM sensor_readings
                WHERE reading_sensor_id = s.sensor_id AND reading_is_valid = 1
                ORDER BY reading_recorded_at DESC LIMIT 1
            )
            WHERE s.sensor_zone_id = ? AND s.sensor_status = 'active'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $zoneId);
    mysqli_stmt_execute($stmt);
    $sensors = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

    foreach ($sensors as $s) {
        $sid = (int)$s['sensor_id'];
        if ($s['value'] === null) {
            $offline = mysqli_prepare(
                $conn,
                'SELECT alert_id FROM alerts WHERE alert_sensor_id = ? AND alert_type = ? AND alert_is_resolved = 0 LIMIT 1'
            );
            $t = 'sensor_offline';
            mysqli_stmt_bind_param($offline, 'is', $sid, $t);
            mysqli_stmt_execute($offline);
            if (!mysqli_fetch_assoc(mysqli_stmt_get_result($offline))) {
                alert_create_if_new(
                    $conn,
                    $zoneId,
                    $sid,
                    'sensor_offline',
                    'critical',
                    'Cảm biến mất kết nối / chưa có dữ liệu',
                    null
                );
            }
            continue;
        }

        $v = (float)$s['value'];
        $type = $s['sensor_type'];

        if ($type === 'soil_moisture') {
            if ($v < ALOE_MOISTURE_LOW) {
                alert_create_if_new($conn, $zoneId, $sid, 'threshold_low', 'critical',
                    "Độ ẩm đất {$v}% < 50% (nha đam cần 60–80%)", $v);
            } elseif ($v > ALOE_MOISTURE_HIGH) {
                alert_create_if_new($conn, $zoneId, $sid, 'threshold_high', 'warning',
                    "Độ ẩm đất {$v}% > 85%", $v);
            }
        } elseif ($type === 'temperature' && $v > ALOE_TEMP_CRITICAL) {
            alert_create_if_new($conn, $zoneId, $sid, 'threshold_high', 'critical',
                "Nhiệt độ {$v}°C > 40°C", $v);
        } elseif ($type === 'ph' && ($v < ALOE_PH_LOW || $v > ALOE_PH_HIGH)) {
            alert_create_if_new($conn, $zoneId, $sid, $v < ALOE_PH_LOW ? 'threshold_low' : 'threshold_high',
                'critical', "pH đất {$v} ngoài 6.0–8.0", $v);
        }
    }

    if (db_table_exists($conn, 'zone_valves')) {
        $valve = mysqli_prepare($conn, 'SELECT status FROM zone_valves WHERE zone_id = ? LIMIT 1');
        mysqli_stmt_bind_param($valve, 'i', $zoneId);
        mysqli_stmt_execute($valve);
        $vrow = mysqli_fetch_assoc(mysqli_stmt_get_result($valve));
        if ($vrow && $vrow['status'] === 'error') {
            alert_create_if_new($conn, $zoneId, null, 'valve_error', 'critical', 'Van tưới lỗi', null);
        }
    }
}

function alert_run_all_zones(mysqli $conn): void
{
    $zones = mysqli_fetch_all(mysqli_query($conn, 'SELECT zone_id FROM zones'), MYSQLI_ASSOC);
    foreach ($zones as $z) {
        alert_check_zone_sensors($conn, (int)$z['zone_id']);
    }
}
