<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/ui.php';
if (!function_exists('notify_count_unread')) {
    require_once __DIR__ . '/notifications.php';
}

$user = current_user();
$notifUnread = 0;
if ($user && isset($conn)) {
    $notifUnread = notify_count_unread($conn, (int)$user['user_id']);
}

$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$isAuthPage = in_array($currentPage, ['login.php', 'register.php'], true);
$GLOBALS['_layout_has_shell'] = (bool)$user;

if ($user && !function_exists('rbac_can_access_page')) {
    require_once __DIR__ . '/rbac.php';
}

$canPage = static function (string $page) use ($user): bool {
    if (!$user) {
        return false;
    }
    return rbac_can_access_page($page);
};

$pageTitles = [
    'dashboard.php' => 'Dashboard',
    'login.php' => 'Đăng nhập',
    'register.php' => 'Đăng ký',
];
$pageTitle = $GLOBALS['dash_page_title'] ?? $pageTitles[$currentPage] ?? 'Aloe Farm Dashboard';
$role = $user['role'] ?? '';
$initials = $user ? ui_initials($user['full_name']) : '';
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($pageTitle); ?> · Aloe Vera Farm</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <?php $styleVer = @filemtime(__DIR__ . '/../assets/style.css') ?: time(); ?>
    <link rel="stylesheet" href="assets/style.css?v=<?php echo (int)$styleVer; ?>">
</head>
<body<?php echo $isAuthPage ? ' class="auth-page"' : ''; ?>>
<?php if ($isAuthPage): ?>
<div class="auth-wrap">
    <div class="auth-bg"></div>
    <div class="auth-leaf">🌿</div>
    <div class="auth-leaf2">🌵</div>
<?php elseif ($user): ?>
<div class="app-shell">
    <nav class="sidebar">
        <div class="sb-logo">
            <div class="sb-logo-wrap">
                <div class="sb-logo-icon">🌱</div>
                <div>
                    <div class="sb-brand">Aloe Vera Farm</div>
                    <div class="sb-brand-sub">Dashboard System</div>
                </div>
            </div>
        </div>
        <div class="nav-wrap">
            <?php
            if (isset($conn)) {
                ui_render_sidebar_nav($conn, $role, $currentPage, $canPage);
            }
            ?>
        </div>
        <div class="sb-footer">
            <div class="sb-user">
                <div class="sb-avatar <?php echo e($role); ?>"><?php echo e($initials); ?></div>
                <div class="sb-user-text">
                    <div class="sb-user-name"><?php echo e($user['full_name']); ?></div>
                    <span class="sb-user-role tag tag-<?php echo $role === 'admin' ? 'purple' : ($role === 'manager' ? 'blue' : 'green'); ?>"><?php echo e(strtoupper($role)); ?></span>
                </div>
            </div>
            <a class="sb-logout" href="logout.php">
                <span class="nav-icon">🚪</span>
                <span>Đăng xuất</span>
            </a>
        </div>
    </nav>
    <div class="main">
        <header class="topbar">
            <div class="topbar-left">
                <span class="page-title"><?php echo e($pageTitle); ?></span>
            </div>
            <div class="topbar-right">
                <span class="topbar-clock" id="topbarClock">--:--:--</span>
                <div class="topbar-icon notif-bell" id="notifBell" title="Thông báo">
                    🔔
                    <?php if ($notifUnread > 0): ?><span class="notif-dot"><?php echo $notifUnread > 9 ? '9+' : $notifUnread; ?></span><?php endif; ?>
                    <div class="notif-dropdown" id="notifDropdown"></div>
                </div>
                <?php
                $refreshHref = htmlspecialchars($_SERVER['REQUEST_URI'] ?? 'dashboard.php', ENT_QUOTES, 'UTF-8');
                ?>
                <a href="<?php echo $refreshHref; ?>" class="btn btn-ghost btn-sm">↻ Làm mới</a>
            </div>
        </header>
        <div class="content">
        <script>
        (function(){
            function tick(){ var el=document.getElementById('topbarClock'); if(el) el.textContent=new Date().toLocaleTimeString('vi-VN'); }
            tick(); setInterval(tick,1000);
            var bell=document.getElementById('notifBell'), box=document.getElementById('notifDropdown');
            if(bell&&box){
                bell.addEventListener('click',function(e){
                    e.stopPropagation();
                    box.style.display=box.style.display==='block'?'none':'block';
                    fetch('api/notifications.php').then(function(r){return r.json();}).then(function(d){
                        box.innerHTML=(d.items||[]).map(function(n){
                            return '<div class="notif-item"><b>'+n.title+'</b><br>'+n.message+'<small>'+n.created_at+'</small></div>';
                        }).join('')||'<div class="notif-item muted">Không có thông báo</div>';
                    });
                });
                document.addEventListener('click',function(){box.style.display='none';});
            }
        })();
        </script>
<?php else: ?>
<div class="content" style="padding:40px 20px;">
<?php endif; ?>
