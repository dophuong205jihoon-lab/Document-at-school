<?php

const CYCLE_HARVEST_MONTHS_MIN = 18;
const CYCLE_HARVEST_MONTHS_MAX = 24;
const CYCLE_HARVEST_MONTHS_DEFAULT = 21;

/** @var list<string> */
const CYCLE_VARIETIES = [
    'Aloe Barbadensis Miller',
    'Aloe Vera (Barbadensis)',
    'Aloe Chinensis',
    'Aloe Saponaria',
];

function cycle_add_months(string $date, int $months): string
{
    $dt = new DateTime($date);

    return $dt->modify("+{$months} months")->format('Y-m-d');
}

function cycle_months_between(string $plantedDate, string $harvestDate): int
{
    $p = new DateTime($plantedDate);
    $h = new DateTime($harvestDate);

    return ($p->diff($h)->y * 12) + $p->diff($h)->m;
}

/**
 * @return string|null Error message if invalid
 */
function cycle_validate_harvest_date(string $plantedDate, string $expectedHarvest): ?string
{
    if ($expectedHarvest < $plantedDate) {
        return 'Ngày dự kiến thu hoạch phải sau ngày trồng.';
    }

    $months = cycle_months_between($plantedDate, $expectedHarvest);
    if ($months < CYCLE_HARVEST_MONTHS_MIN) {
        return 'Dự kiến thu hoạch phải từ ' . CYCLE_HARVEST_MONTHS_MIN . ' tháng trở lên sau ngày trồng.';
    }
    if ($months > CYCLE_HARVEST_MONTHS_MAX) {
        return 'Dự kiến thu hoạch không quá ' . CYCLE_HARVEST_MONTHS_MAX . ' tháng sau ngày trồng.';
    }

    return null;
}

function cycle_status_label(string $status): string
{
    return match ($status) {
        'growing' => 'Đang trồng',
        'harvesting' => 'Đang thu hoạch',
        'ended' => 'Đã kết thúc',
        default => $status,
    };
}
