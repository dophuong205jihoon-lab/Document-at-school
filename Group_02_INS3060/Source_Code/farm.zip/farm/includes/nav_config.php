<?php

/**
 * Sidebar navigation + dashboard page routing.
 */

/** @return list<string> */
function nav_manager_pages(): array
{
    return ['overview', 'alerts', 'irrigation', 'weather', 'harvest', 'ai', 'zones'];
}

/** @return list<string> */
function nav_farmer_pages(): array
{
    return ['overview', 'alerts', 'sensors'];
}

/** @return list<string> */
function nav_admin_pages(): array
{
    return ['overview', 'users', 'audit'];
}

function nav_sanitize_page(string $page, string $role, bool $adminOps = false): string
{
    $allowed = match (true) {
        $adminOps, $role === 'manager' => nav_manager_pages(),
        $role === 'farmer' => nav_farmer_pages(),
        $role === 'admin' => nav_admin_pages(),
        default => ['overview'],
    };

    return in_array($page, $allowed, true) ? $page : 'overview';
}

/** @return list<array{page: string, label: string, icon: string, badge_key?: string}> */
function nav_items_for_role(string $role, bool $adminOps = false): array
{
    if ($adminOps || $role === 'manager') {
        return [
            ['page' => 'overview', 'label' => 'Tổng quan', 'icon' => 'grid'],
            ['page' => 'alerts', 'label' => 'Cảnh báo', 'icon' => 'alert', 'badge_key' => 'alerts'],
            ['page' => 'irrigation', 'label' => 'Tưới tiêu', 'icon' => 'water', 'badge_key' => 'irrigation'],
            ['page' => 'weather', 'label' => 'Thời tiết', 'icon' => 'weather'],
            ['page' => 'harvest', 'label' => 'Thu hoạch', 'icon' => 'harvest', 'badge_key' => 'harvest'],
            ['page' => 'ai', 'label' => 'AI & dự báo', 'icon' => 'ai'],
            ['page' => 'zones', 'label' => 'Zone & sensor', 'icon' => 'zones', 'badge_key' => 'sensors'],
        ];
    }

    if ($role === 'farmer') {
        return [
            ['page' => 'overview', 'label' => 'Tổng quan', 'icon' => 'grid'],
            ['page' => 'alerts', 'label' => 'Cảnh báo', 'icon' => 'alert', 'badge_key' => 'alerts'],
            ['page' => 'sensors', 'label' => 'Sensor', 'icon' => 'sensor'],
        ];
    }

    if ($role === 'admin') {
        return [
            ['page' => 'overview', 'label' => 'Tổng quan', 'icon' => 'grid'],
            ['page' => 'users', 'label' => 'Người dùng', 'icon' => 'users'],
            ['page' => 'audit', 'label' => 'Nhật ký', 'icon' => 'log'],
            ['page' => 'ops', 'label' => 'Vận hành farm', 'icon' => 'farm', 'href' => 'dashboard.php?view=ops&page=overview'],
        ];
    }

    return [['page' => 'overview', 'label' => 'Dashboard', 'icon' => 'grid']];
}

function nav_page_title(string $role, string $page, bool $adminOps = false): string
{
    if ($page === 'ops') {
        return 'Vận hành farm';
    }

    $titles = [
        'overview' => 'Tổng quan',
        'alerts' => 'Cảnh báo',
        'irrigation' => 'Tưới tiêu',
        'weather' => 'Thời tiết',
        'harvest' => 'Thu hoạch',
        'ai' => 'AI & dự báo',
        'zones' => 'Zone & sensor',
        'sensors' => 'Chỉ số sensor',
        'users' => 'Người dùng',
        'audit' => 'Nhật ký hệ thống',
    ];

    $t = $titles[$page] ?? 'Dashboard';
    if ($adminOps && $role === 'admin') {
        return $t . ' (Ops)';
    }

    return $t;
}

function nav_dashboard_url(string $page, string $role, bool $adminOps = false): string
{
    if ($role === 'admin' && !$adminOps && $page !== 'ops') {
        return 'dashboard.php?page=' . rawurlencode($page);
    }
    if ($role === 'admin' && $adminOps) {
        return 'dashboard.php?view=ops&page=' . rawurlencode($page);
    }

    return 'dashboard.php?page=' . rawurlencode($page);
}

/** @return array<string, int> */
function nav_badge_counts(mysqli $conn, string $role, bool $adminOps = false): array
{
    if ($role !== 'manager' && !($role === 'admin' && $adminOps)) {
        if ($role === 'farmer') {
            $uid = (int)(current_user()['user_id'] ?? 0);
            $alerts = report_run($conn, 'BQ-29', ['userId' => $uid]);

            return ['alerts' => count($alerts)];
        }

        return [];
    }

    $kpi = report_run($conn, 'BQ-30');
    $row = $kpi[0] ?? [];

    return [
        'alerts' => (int)($row['unresolved_alerts'] ?? 0),
        'harvest' => (int)($row['pending_harvests'] ?? 0),
        'irrigation' => (int)($row['running_irrigations'] ?? 0),
        'sensors' => (int)($row['faulty_sensors'] ?? 0),
    ];
}
