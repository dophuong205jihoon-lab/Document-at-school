<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/jwt.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function auth_cookie_options(int $expires): array
{
    return [
        'expires' => $expires,
        'path' => COOKIE_PATH,
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ];
}

function auth_restore_from_jwt(): void
{
    if (isset($_SESSION['user'])) {
        return;
    }

    $token = $_COOKIE[JWT_COOKIE_NAME] ?? '';
    if ($token === '') {
        return;
    }

    $payload = jwt_decode($token, JWT_SECRET);
    if (!$payload || empty($payload['sub'])) {
        setcookie(JWT_COOKIE_NAME, '', auth_cookie_options(1));
        return;
    }

    $_SESSION['user'] = [
        'user_id' => (int)$payload['sub'],
        'username' => (string)($payload['username'] ?? ''),
        'full_name' => (string)($payload['full_name'] ?? ''),
        'role' => (string)($payload['role'] ?? ''),
    ];
}

auth_restore_from_jwt();

function is_logged_in(): bool
{
    return isset($_SESSION['user']);
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function auth_jwt_token(): ?string
{
    return $_COOKIE[JWT_COOKIE_NAME] ?? null;
}

function auth_create_session(array $user): string
{
    $sessionUser = [
        'user_id' => (int)$user['user_id'],
        'username' => $user['username'],
        'full_name' => $user['full_name'],
        'role' => $user['role'],
    ];
    $_SESSION['user'] = $sessionUser;

    $exp = time() + JWT_TTL;
    $payload = [
        'sub' => $sessionUser['user_id'],
        'username' => $sessionUser['username'],
        'full_name' => $sessionUser['full_name'],
        'role' => $sessionUser['role'],
        'iat' => time(),
        'exp' => $exp,
    ];
    $token = jwt_encode($payload, JWT_SECRET);
    setcookie(JWT_COOKIE_NAME, $token, auth_cookie_options($exp));

    return $token;
}

function auth_destroy_session(): void
{
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
    setcookie(JWT_COOKIE_NAME, '', auth_cookie_options(1));
}

function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function require_roles(array $roles): void
{
    if (!function_exists('rbac_require_roles')) {
        require_once __DIR__ . '/rbac.php';
    }
    rbac_require_roles($roles);
}

/**
 * @return array{ok: bool, error: string, user: ?array, token: ?string, locked: bool}
 */
function attempt_login(mysqli $conn, string $username, string $password): array
{
    $fail = static fn(string $error, bool $locked = false): array => [
        'ok' => false,
        'error' => $error,
        'user' => null,
        'token' => null,
        'locked' => $locked,
    ];

    if ($username === '' || $password === '') {
        return $fail('Vui lòng nhập tên đăng nhập và mật khẩu.');
    }

    $stmt = mysqli_prepare(
        $conn,
        'SELECT user_id,
                user_username AS username,
                user_full_name AS full_name,
                user_role AS role,
                user_status AS status,
                user_failed_login_count AS failed_login_count,
                user_password_hash AS password_hash
         FROM users WHERE user_username = ? LIMIT 1'
    );
    mysqli_stmt_bind_param($stmt, 's', $username);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$user) {
        return $fail('Tài khoản không tồn tại.');
    }

    if ($user['status'] === 'locked') {
        return $fail('Tài khoản đã bị khóa sau 5 lần đăng nhập sai. Liên hệ Admin.', true);
    }

    if ($user['status'] !== 'active') {
        return $fail('Tài khoản không hoạt động.');
    }

    if (!password_verify($password, $user['password_hash'])) {
        $newCount = (int)$user['failed_login_count'] + 1;
        $locked = $newCount >= 5;
        $newStatus = $locked ? 'locked' : $user['status'];

        $up = mysqli_prepare($conn, 'UPDATE users SET user_failed_login_count = ?, user_status = ? WHERE user_id = ?');
        mysqli_stmt_bind_param($up, 'isi', $newCount, $newStatus, $user['user_id']);
        mysqli_stmt_execute($up);

        if ($locked) {
            if (function_exists('audit_log')) {
                require_once __DIR__ . '/audit.php';
                audit_log($conn, (int)$user['user_id'], 'UPDATE', 'users', (string)$user['user_id'], [
                    'action' => 'auto_lock',
                    'reason' => '5_failed_logins',
                ]);
            }
            return $fail('Sai mật khẩu 5 lần liên tiếp. Tài khoản đã bị khóa.', true);
        }

        return $fail('Sai mật khẩu. Lần thử: ' . $newCount . '/5.');
    }

    $up = mysqli_prepare($conn, 'UPDATE users SET user_failed_login_count = 0, user_last_login = NOW() WHERE user_id = ?');
    mysqli_stmt_bind_param($up, 'i', $user['user_id']);
    mysqli_stmt_execute($up);

    $token = auth_create_session($user);

    return [
        'ok' => true,
        'error' => '',
        'user' => current_user(),
        'token' => $token,
        'locked' => false,
    ];
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
