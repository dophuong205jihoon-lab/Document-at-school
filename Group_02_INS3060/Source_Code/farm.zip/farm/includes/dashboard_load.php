<?php

require_once __DIR__ . '/reports.php';
require_once __DIR__ . '/nav_config.php';

/**
 * Load report data only for the active dashboard page.
 *
 * @return array<string, mixed>
 */
function dashboard_load_manager(mysqli $conn, string $page): array
{
    $ctx = [];
    $codes = ['BQ-30'];

    $pageBqs = match ($page) {
        'overview' => ['BQ-21'],
        'alerts' => ['BQ-05', 'BQ-13'],
        'irrigation' => ['BQ-06', 'BQ-07', 'BQ-14', 'BQ-15', 'BQ-11', 'BQ-12'],
        'weather' => ['BQ-09', 'BQ-20'],
        'harvest' => ['BQ-08', 'BQ-18', 'BQ-19', 'BQ-25'],
        'ai' => ['BQ-16', 'BQ-17'],
        'zones' => ['BQ-02', 'BQ-03', 'BQ-04'],
        default => ['BQ-21'],
    };

    $codes = array_values(array_unique(array_merge($codes, $pageBqs)));

    $map = [
        'BQ-30' => 'managerKpi',
        'BQ-21' => 'zoneHealth',
        'BQ-02' => 'zones',
        'BQ-03' => 'assignments',
        'BQ-04' => 'faultySensors',
        'BQ-05' => 'openAlerts',
        'BQ-06' => 'activeSchedules',
        'BQ-07' => 'irrigatingNow',
        'BQ-08' => 'pendingHarvests',
        'BQ-09' => 'weatherForecast',
        'BQ-20' => 'weatherIrrigationPlan',
        'BQ-11' => 'dryZones',
        'BQ-12' => 'wetZones',
        'BQ-13' => 'alertSummaryByZone',
        'BQ-14' => 'irrigationEfficiency',
        'BQ-15' => 'irrigationFailures',
        'BQ-16' => 'aiIrrigationRecs',
        'BQ-17' => 'aiDiseaseRisks',
        'BQ-18' => 'harvestPerformance',
        'BQ-19' => 'harvestKpi',
        'BQ-25' => 'zoneYieldRank',
    ];

    $out = ['managerPage' => $page];
    foreach ($codes as $code) {
        $key = $map[$code] ?? $code;
        $out[$key] = report_run($conn, $code, $ctx);
    }

    return dashboard_manager_prepare($out);
}

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
function dashboard_manager_prepare(array $data): array
{
    $zoneYieldRank = $data['zoneYieldRank'] ?? [];
    $harvestPerformance = $data['harvestPerformance'] ?? [];
    $irrigationEfficiency = $data['irrigationEfficiency'] ?? [];
    $alertSummaryByZone = $data['alertSummaryByZone'] ?? [];
    $activeSchedules = $data['activeSchedules'] ?? [];

    $yieldRankMax = 1.0;
    foreach ($zoneYieldRank as $row) {
        $kg = (float)($row['total_yield_kg'] ?? 0);
        if ($kg > $yieldRankMax) {
            $yieldRankMax = $kg;
        }
    }

    $harvestKgMax = 1.0;
    foreach ($harvestPerformance as $row) {
        $kg = (float)($row['total_kg'] ?? 0);
        if ($kg > $harvestKgMax) {
            $harvestKgMax = $kg;
        }
    }

    $irrGainMax = 1.0;
    foreach ($irrigationEfficiency as $row) {
        $g = (float)($row['avg_moisture_gain'] ?? 0);
        if ($g > $irrGainMax) {
            $irrGainMax = $g;
        }
    }

    $alertChartMax = 1;
    foreach ($alertSummaryByZone as $row) {
        $t = (int)($row['total_alerts'] ?? 0);
        if ($t > $alertChartMax) {
            $alertChartMax = $t;
        }
    }

    $alertChartRows = array_values(array_filter(
        $alertSummaryByZone,
        static fn(array $r): bool => (int)($r['total_alerts'] ?? 0) > 0
    ));

    $schedulesByZone = [];
    foreach ($activeSchedules as $sch) {
        $code = (string)($sch['zone_code'] ?? '');
        if ($code === '') {
            continue;
        }
        if (!isset($schedulesByZone[$code])) {
            $schedulesByZone[$code] = [
                'zone_name' => $sch['zone_name'] ?? '',
                'items' => [],
            ];
        }
        $schedulesByZone[$code]['items'][] = $sch;
    }

    $kpiRow = ($data['managerKpi'] ?? [])[0] ?? [];

    return array_merge($data, [
        'yieldRankMax' => $yieldRankMax,
        'harvestKgMax' => $harvestKgMax,
        'irrGainMax' => $irrGainMax,
        'alertChartMax' => $alertChartMax,
        'alertChartRows' => $alertChartRows,
        'schedulesByZone' => $schedulesByZone,
        'kpiRow' => $kpiRow,
        'kpiActiveZones' => (int)($kpiRow['active_zones'] ?? 0),
        'kpiUnresolvedAlerts' => (int)($kpiRow['unresolved_alerts'] ?? 0),
        'kpiPendingHarvests' => (int)($kpiRow['pending_harvests'] ?? 0),
        'kpiRunningIrrigations' => (int)($kpiRow['running_irrigations'] ?? 0),
        'kpiFaultySensors' => (int)($kpiRow['faulty_sensors'] ?? 0),
    ]);
}

/**
 * @return array<string, mixed>
 */
function dashboard_load_farmer(mysqli $conn, string $page, int $userId): array
{
    $out = ['farmerPage' => $page, 'farmerUserId' => $userId];

    if (in_array($page, ['overview', 'alerts', 'sensors'], true)) {
        $out['farmerZones'] = report_run($conn, 'BQ-22', ['userId' => $userId]);
        $out['farmerOpenAlerts'] = report_run($conn, 'BQ-29', ['userId' => $userId]);
    }
    if ($page === 'sensors') {
        $out['farmerLatestReadings'] = report_run($conn, 'BQ-28', ['userId' => $userId]);
    }

    return dashboard_farmer_prepare($out);
}

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
function dashboard_farmer_prepare(array $data): array
{
    $farmerLatestReadings = $data['farmerLatestReadings'] ?? [];
    $readingsByZone = [];
    foreach ($farmerLatestReadings as $row) {
        $code = (string)($row['zone_code'] ?? '');
        if ($code === '') {
            continue;
        }
        if (!isset($readingsByZone[$code])) {
            $readingsByZone[$code] = [
                'zone_name' => $row['zone_name'] ?? '',
                'items' => [],
            ];
        }
        $readingsByZone[$code]['items'][] = $row;
    }

    $farmerZones = $data['farmerZones'] ?? [];
    $farmerOpenAlerts = $data['farmerOpenAlerts'] ?? [];
    $alertZoneCodes = [];
    foreach ($farmerOpenAlerts as $a) {
        $zc = (string)($a['zone_code'] ?? '');
        if ($zc !== '' && !in_array($zc, $alertZoneCodes, true)) {
            $alertZoneCodes[] = $zc;
        }
    }
    sort($alertZoneCodes);

    return array_merge($data, [
        'readingsByZone' => $readingsByZone,
        'totalAlerts' => count($farmerOpenAlerts),
        'totalSensors' => array_sum(array_map(
            static fn(array $z): int => (int)($z['total_sensors'] ?? 0),
            $farmerZones
        )),
        'alertZoneCodes' => $alertZoneCodes,
        'roleLabels' => ['admin' => 'Admin', 'manager' => 'Manager', 'farmer' => 'Farmer'],
    ]);
}

/**
 * @return array<string, mixed>
 */
function dashboard_load_admin(mysqli $conn, string $page): array
{
    $out = ['adminPage' => $page];

    if ($page === 'overview' || $page === 'users') {
        $out['users'] = report_run($conn, 'BQ-01');
    }
    if ($page === 'users') {
        $out['userSummary'] = report_run($conn, 'BQ-26');
        $out['usersAtRisk'] = report_run($conn, 'BQ-27');
    }
    if ($page === 'audit') {
        $out['auditLog'] = report_run($conn, 'BQ-10');
    }

    if ($page === 'overview') {
        $out['userSummary'] = report_run($conn, 'BQ-26');
    }

    return dashboard_admin_prepare($out);
}

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
function dashboard_admin_prepare(array $data): array
{
    $users = $data['users'] ?? [];
    $userSummary = $data['userSummary'] ?? [];

    $userMatrix = [];
    $userSummaryTotal = 0;
    foreach ($userSummary as $row) {
        $r = (string)($row['user_role'] ?? '');
        $s = (string)($row['user_status'] ?? '');
        $n = (int)($row['total_users'] ?? 0);
        $userMatrix[$r][$s] = $n;
        $userSummaryTotal += $n;
    }

    $userChartRoles = ['admin', 'manager', 'farmer'];
    $userChartRows = [];
    $userChartMax = 1;
    foreach ($userChartRoles as $role) {
        $active = (int)($userMatrix[$role]['active'] ?? 0);
        $locked = (int)($userMatrix[$role]['locked'] ?? 0);
        $inactive = (int)($userMatrix[$role]['inactive'] ?? 0);
        $total = $active + $locked + $inactive;
        if ($total <= 0) {
            continue;
        }
        $userChartRows[] = [
            'role' => $role,
            'active' => $active,
            'locked' => $locked,
            'inactive' => $inactive,
            'total' => $total,
        ];
        if ($total > $userChartMax) {
            $userChartMax = $total;
        }
    }

    $byRole = ['admin' => [], 'manager' => [], 'farmer' => []];
    foreach ($users as $u) {
        $r = $u['user_role'] ?? 'farmer';
        if (isset($byRole[$r])) {
            $byRole[$r][] = $u;
        }
    }

    return array_merge($data, [
        'userMatrix' => $userMatrix,
        'userSummaryTotal' => $userSummaryTotal,
        'userChartRows' => $userChartRows,
        'userChartMax' => $userChartMax,
        'byRole' => $byRole,
        'total' => count($users),
        'roleLabels' => ['admin' => 'Admin', 'manager' => 'Manager', 'farmer' => 'Farmer'],
    ]);
}
