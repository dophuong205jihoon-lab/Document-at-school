<?php
/**
 * RBAC – 3 roles:
 * - admin: full access
 * - manager: zones (all) + irrigation schedules + reports + harvest approve
 * - farmer: assigned zones only (view alerts/harvest/dashboard)
 */
require_once __DIR__ . '/auth.php';

const RBAC_ROLES = ['admin', 'manager', 'farmer'];

/** @var array<string, list<string>> */
const RBAC_PAGES = [
    'dashboard.php' => ['admin', 'manager', 'farmer'],
    'login.php' => ['admin', 'manager', 'farmer'],
    'register.php' => ['admin', 'manager', 'farmer'],
    'logout.php' => ['admin', 'manager', 'farmer'],
    'index.php' => ['admin', 'manager', 'farmer'],
];

/** @var array<string, list<string>> */
const RBAC_ACTIONS = [
    'harvest.approve' => ['admin', 'manager'],
    'harvest.create' => ['admin', 'manager', 'farmer'],
    'irrigation.manage' => ['admin', 'manager'],
    'users.manage' => ['admin'],
    'sensors.manage' => ['admin'],
    'sensors.view' => ['admin', 'manager', 'farmer'],
    'zones.view_all' => ['admin', 'manager'],
    'zones.manage' => ['admin'],
    'zones.assign' => ['admin'],
    'cycles.manage' => ['admin', 'manager'],
];

function rbac_role(): ?string
{
    $user = current_user();

    return $user['role'] ?? null;
}

function rbac_is_admin(): bool
{
    return rbac_role() === 'admin';
}

function rbac_is_manager(): bool
{
    return rbac_role() === 'manager';
}

function rbac_is_farmer(): bool
{
    return rbac_role() === 'farmer';
}

function rbac_can_access_page(string $page, ?string $role = null): bool
{
    $role ??= rbac_role();
    if ($role === null || !in_array($role, RBAC_ROLES, true)) {
        return false;
    }

    $allowed = RBAC_PAGES[$page] ?? null;
    if ($allowed === null) {
        return false;
    }

    return in_array($role, $allowed, true);
}

function rbac_can(string $action, ?string $role = null): bool
{
    $role ??= rbac_role();
    if ($role === null) {
        return false;
    }

    $allowed = RBAC_ACTIONS[$action] ?? [];

    return in_array($role, $allowed, true);
}

function rbac_deny(string $message = '403 - Bạn không có quyền truy cập trang này.'): void
{
    http_response_code(403);
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    if (str_contains($accept, 'application/json') || (($_GET['format'] ?? '') === 'json')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $home = 'dashboard.php';
    if (is_logged_in() && rbac_can_access_page('dashboard.php')) {
        $home = 'dashboard.php';
    } elseif (is_logged_in()) {
        $home = 'logout.php';
    } else {
        $home = 'login.php';
    }

    echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>403</title>';
    echo '<link rel="stylesheet" href="assets/style.css"></head><body class="auth-page">';
    echo '<div class="card" style="max-width:480px;margin:80px auto;">';
    echo '<h2>Không có quyền truy cập</h2>';
    echo '<p class="muted">' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<p style="margin-top:16px;"><a href="' . htmlspecialchars($home, ENT_QUOTES, 'UTF-8') . '">← Quay lại</a></p>';
    echo '</div></body></html>';
    exit;
}

/**
 * Middleware: require login + page permission for current (or given) script.
 */
function rbac_middleware(?string $page = null): void
{
    require_login();

    $page = $page ?? basename($_SERVER['PHP_SELF'] ?? '');
    if (!rbac_can_access_page($page)) {
        rbac_deny();
    }
}

function rbac_require_roles(array $roles): void
{
    require_login();
    $role = rbac_role();
    if (!$role || !in_array($role, $roles, true)) {
        rbac_deny();
    }
}

/** @return list<int> */
function rbac_farmer_zone_ids(mysqli $conn): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $user = current_user();
    if (!$user || $user['role'] !== 'farmer') {
        $cache = [];

        return $cache;
    }

    $uid = (int)$user['user_id'];
    $stmt = mysqli_prepare(
        $conn,
        'SELECT assign_zone_id AS zone_id FROM user_zone_assignment WHERE assign_user_id = ? AND assign_is_active = 1'
    );
    mysqli_stmt_bind_param($stmt, 'i', $uid);
    mysqli_stmt_execute($stmt);
    $rows = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
    $cache = array_map(static fn(array $r): int => (int)$r['zone_id'], $rows);

    return $cache;
}

function rbac_can_access_zone(mysqli $conn, int $zoneId): bool
{
    if ($zoneId <= 0) {
        return false;
    }

    if (rbac_can('zones.view_all')) {
        return true;
    }

    if (rbac_is_farmer()) {
        return in_array($zoneId, rbac_farmer_zone_ids($conn), true);
    }

    return false;
}

function rbac_assert_zone_access(mysqli $conn, int $zoneId): void
{
    if (!rbac_can_access_zone($conn, $zoneId)) {
        rbac_deny('Bạn không có quyền truy cập Zone này.');
    }
}

/**
 * SQL fragment for filtering a zone column to current farmer assignments.
 */
function rbac_zone_sql_filter(mysqli $conn, string $zoneColumn = 'zone_id'): string
{
    if (!rbac_is_farmer()) {
        return '';
    }

    $ids = rbac_farmer_zone_ids($conn);
    if ($ids === []) {
        return ' AND 1=0';
    }

    return ' AND ' . $zoneColumn . ' IN (' . implode(',', $ids) . ')';
}

function rbac_nav_pages(): array
{
    return ['dashboard.php' => 'Dashboard'];
}
