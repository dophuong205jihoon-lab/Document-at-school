<?php
/**
 * Import schema đầy đủ: DDL + mock data + trigger/view/procedure + Q01-Q33.
 * Chạy: php install/install_bq.php
 */

$sqlFile = realpath(__DIR__ . '/../sql/aloe_farm_dashboard.sql');
if (!$sqlFile || !is_readable($sqlFile)) {
    fwrite(STDERR, "Không tìm thấy sql/aloe_farm_dashboard.sql\n");
    exit(1);
}

$mysql = '/Applications/XAMPP/xamppfiles/bin/mysql';
if (!is_executable($mysql)) {
    $mysql = trim((string)shell_exec('which mysql 2>/dev/null'));
}
if (!is_executable($mysql)) {
    fwrite(STDERR, "Không tìm thấy mysql CLI. Hãy import sql/aloe_farm_dashboard.sql bằng phpMyAdmin.\n");
    exit(1);
}

$cmd = sprintf(
    '%s -u %s %s < %s 2>&1',
    escapeshellcmd($mysql),
    escapeshellarg('root'),
    '',
    escapeshellarg($sqlFile)
);
passthru($cmd, $code);
if ($code === 0) {
    echo "OK - đã import sql/aloe_farm_dashboard.sql.\n";
    exit(0);
}

echo "Import lỗi (code {$code}). Hãy mở phpMyAdmin và chạy sql/aloe_farm_dashboard.sql.\n";
exit($code);
