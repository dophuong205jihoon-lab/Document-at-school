<?php
/**
 * Chạy một lần: php install/migrate.php
 */
require_once __DIR__ . '/../db.php';

$queries = [
    "CREATE TABLE IF NOT EXISTS zone_valves (
        valve_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        zone_id INT UNSIGNED NOT NULL,
        valve_code VARCHAR(50) NOT NULL,
        status ENUM('open','closed','error') NOT NULL DEFAULT 'closed',
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (valve_id),
        UNIQUE KEY uk_zone_valve (zone_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS notifications (
        notification_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NULL,
        zone_id INT UNSIGNED NULL,
        alert_id INT UNSIGNED NULL,
        title VARCHAR(200) NOT NULL,
        message VARCHAR(500) NOT NULL,
        priority ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        digest_key VARCHAR(32) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (notification_id),
        KEY idx_user_read (user_id, is_read, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];

foreach ($queries as $q) {
    mysqli_query($conn, $q) or die(mysqli_error($conn) . "\n");
}

echo "Migration done. Core schema stays in sql/aloe_farm_dashboard.sql; only optional zone_valves/notifications were ensured.\n";
