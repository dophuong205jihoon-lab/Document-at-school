<?php
/**
 * JSON: GET ?code=BQ-01  (cần đăng nhập)
 */
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/reports.php';

header('Content-Type: application/json; charset=utf-8');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$code = strtoupper(trim($_GET['code'] ?? ''));
$userId = isset($_GET['userId']) ? (int)$_GET['userId'] : null;
$defs = report_definitions();
$def = $defs[$code] ?? null;

if (!$def) {
    http_response_code(404);
    echo json_encode(['error' => 'Unknown code']);
    exit;
}

$data = report_run($conn, $code, ['userId' => $userId]);
echo json_encode([
    'code' => $code,
    'title' => $def['title'],
    'data' => $data,
], JSON_UNESCAPED_UNICODE);
