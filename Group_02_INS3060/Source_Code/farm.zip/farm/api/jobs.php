<?php
/**
 * Cron: php api/jobs.php (hoặc gọi qua HTTP với API key)
 * FR-11 weather rules, FR-10 moisture auto, FR-12 zone alerts
 */
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/irrigation_engine.php';
require_once __DIR__ . '/../includes/alerts_engine.php';
require_once __DIR__ . '/../includes/weather_service.php';

$key = $_GET['key'] ?? '';
if (php_sapi_name() !== 'cli' && !hash_equals(IOT_API_KEY, (string)$key)) {
    http_response_code(401);
    exit('Unauthorized');
}

$weatherSync = weather_sync_forecast($conn, 7);
$weather = irrigation_apply_weather_rules($conn);
$auto = irrigation_check_moisture_auto($conn);
alert_run_all_zones($conn);

$out = [
    'weather_sync' => $weatherSync,
    'weather_rules' => $weather,
    'auto_irrigation' => $auto,
    'alerts_checked' => true,
];
header('Content-Type: application/json');
echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
