<?php
/**
 * IoT van tưới — cập nhật trạng thái van theo zone (POST JSON).
 * Header: X-API-Key: <IOT_API_KEY>
 *
 * Body: { "zone_id": 1, "status": "open"|"closed"|"error", "valve_code": "optional" }
 */
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db_schema.php';
require_once __DIR__ . '/../includes/irrigation_engine.php';
require_once __DIR__ . '/../includes/audit.php';

header('Content-Type: application/json; charset=utf-8');

$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['api_key'] ?? '');
if (!hash_equals(IOT_API_KEY, (string)$apiKey)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Invalid API key'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POST required'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!db_table_exists($conn, 'zone_valves')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'zone_valves table missing — run install/migrate.php'], JSON_UNESCAPED_UNICODE);
    exit;
}

$input = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($input)) {
    $input = $_POST;
}

$zoneId = (int)($input['zone_id'] ?? 0);
$status = strtolower(trim((string)($input['status'] ?? '')));
$allowed = ['open', 'closed', 'error'];

if ($zoneId < 1 || !in_array($status, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'zone_id and status (open|closed|error) required'], JSON_UNESCAPED_UNICODE);
    exit;
}

$zone = mysqli_fetch_assoc(mysqli_query($conn, "SELECT zone_id, zone_code FROM zones WHERE zone_id = {$zoneId} LIMIT 1"));
if (!$zone) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Zone not found'], JSON_UNESCAPED_UNICODE);
    exit;
}

$old = mysqli_fetch_assoc(mysqli_query($conn, "SELECT status, valve_code FROM zone_valves WHERE zone_id = {$zoneId} LIMIT 1"));
irrigation_ensure_valve($conn, $zoneId);

if (!empty($input['valve_code'])) {
    $code = trim((string)$input['valve_code']);
    $u = mysqli_prepare($conn, 'UPDATE zone_valves SET valve_code = ? WHERE zone_id = ?');
    mysqli_stmt_bind_param($u, 'si', $code, $zoneId);
    mysqli_stmt_execute($u);
}

irrigation_set_valve($conn, $zoneId, $status);

audit_log($conn, null, 'UPDATE', 'zone_valves', (string)$zoneId, [
    'zone_code' => $zone['zone_code'],
    'old_status' => $old['status'] ?? null,
    'new_status' => $status,
    'source' => 'iot_valve_api',
]);

echo json_encode([
    'success' => true,
    'zone_id' => $zoneId,
    'zone_code' => $zone['zone_code'],
    'status' => $status,
], JSON_UNESCAPED_UNICODE);
