<?php
/**
 * IoT endpoint – nhận dữ liệu cảm biến (POST JSON hoặc form).
 * Header: X-API-Key: <IOT_API_KEY>
 *
 * Body: { "sensor_code": "Z-A01-SM01", "value": 45.2, "recorded_at": "2026-05-15 10:00:00" }
 */
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/sensor_helpers.php';

header('Content-Type: application/json; charset=utf-8');

$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['api_key'] ?? '');
if (!hash_equals(IOT_API_KEY, (string)$apiKey)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Invalid API key'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POST required'], JSON_UNESCAPED_UNICODE);
    exit;
}

$input = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($input)) {
    $input = $_POST;
}

$sensorCode = trim((string)($input['sensor_code'] ?? ''));
$value = $input['value'] ?? null;
$recordedAt = isset($input['recorded_at']) ? trim((string)$input['recorded_at']) : null;

if ($sensorCode === '' || $value === null || $value === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'sensor_code and value required'], JSON_UNESCAPED_UNICODE);
    exit;
}

$result = sensor_ingest_by_code($conn, $sensorCode, (float)$value, $recordedAt ?: null);

if (!$result['ok']) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => $result['error']], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode([
    'success' => true,
    'sensor_id' => $result['sensor_id'],
    'zone_id' => $result['zone_id'],
    'value' => $result['value'],
    'is_valid' => $result['is_valid'],
    'invalid_reason' => $result['invalid_reason'] ?? null,
    'reading_id' => $result['reading_id'] ?? null,
], JSON_UNESCAPED_UNICODE);
