<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/notifications.php';
rbac_middleware();

header('Content-Type: application/json; charset=utf-8');
$user = current_user();
$uid = (int)$user['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'read') {
    $nid = (int)($_POST['notification_id'] ?? 0);
    if ($nid > 0) {
        notify_mark_read($conn, $uid, $nid);
    }
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode([
    'unread' => notify_count_unread($conn, $uid),
    'items' => notify_list($conn, $uid, 15),
], JSON_UNESCAPED_UNICODE);
