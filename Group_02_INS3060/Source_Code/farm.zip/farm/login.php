<?php
/**
 * FR-02: Đăng nhập (JWT + session, khóa sau 5 lần sai)
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/audit.php';

if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$registered = isset($_GET['registered']);
$wantsJson = isset($_GET['format']) && $_GET['format'] === 'json'
    || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $result = attempt_login($conn, $username, $password);

    if ($result['ok']) {
        $userId = (int)$result['user']['user_id'];
        audit_log($conn, $userId, 'LOGIN', 'users', (string)$userId, [
            'username' => $result['user']['username'],
            'ip' => client_ip(),
        ]);
        if ($wantsJson) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => true,
                'token' => $result['token'],
                'expires_in' => JWT_TTL,
                'user' => $result['user'],
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        header('Location: dashboard.php');
        exit;
    }

    $error = $result['error'];
    if ($wantsJson) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code($result['locked'] ? 423 : 401);
        echo json_encode(['success' => false, 'error' => $error, 'locked' => $result['locked']], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if ($wantsJson) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed. Use POST.'], JSON_UNESCAPED_UNICODE);
    exit;
}

require __DIR__ . '/includes/layout.php';
?>
<div class="auth-card">
    <div class="auth-logo">
        <div class="auth-logo-icon">🌱</div>
        <div>
            <div class="auth-brand">Aloe Vera Farm</div>
            <div class="auth-brand-sub">Dashboard Management System</div>
        </div>
    </div>
    <div class="auth-heading">Đăng nhập</div>
    <div class="auth-sub">Tài khoản hệ thống (Admin / Manager / Farmer đã được cấp)</div>

    <?php if ($registered): ?>
        <div class="message-success">Đăng ký thành công. Vui lòng đăng nhập bằng tài khoản vừa tạo.</div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="message-error"><?php echo e($error); ?></div>
    <?php endif; ?>

    <form method="post" id="loginForm">
        <div class="form-group">
            <label class="form-label">Tên đăng nhập</label>
            <input class="form-input" type="text" name="username" autocomplete="username" required
                   value="<?php echo e($_POST['username'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label class="form-label">Mật khẩu</label>
            <input class="form-input" type="password" name="password" autocomplete="current-password" required>
        </div>
        <button type="submit" class="auth-btn">Đăng nhập →</button>
    </form>

    <div class="auth-switch">
        Chưa có tài khoản Farmer?
        <a href="register.php"><strong>Đăng ký tài khoản (FR-01)</strong></a>
    </div>

    <div class="demo-section">
        <div class="demo-label">Tài khoản demo (thử nhanh)</div>
        <div class="demo-grid">
            <button type="button" class="demo-btn demo-admin" data-user="admin_system" data-pass="admin123">
                <span style="display:block;font-size:18px">🛡️</span>
                <span style="font-size:11px;font-weight:700;display:block">Admin</span>
            </button>
            <button type="button" class="demo-btn demo-manager" data-user="mgr_nguyen" data-pass="manager123">
                <span style="display:block;font-size:18px">📊</span>
                <span style="font-size:11px;font-weight:700;display:block">Manager</span>
            </button>
            <button type="button" class="demo-btn demo-farmer" data-user="farmer_minh" data-pass="farmer123">
                <span style="display:block;font-size:18px">🌾</span>
                <span style="font-size:11px;font-weight:700;display:block">Farmer</span>
            </button>
        </div>
    </div>
</div>
<script>
document.querySelectorAll('.demo-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var f = document.getElementById('loginForm');
        f.querySelector('[name=username]').value = btn.getAttribute('data-user');
        f.querySelector('[name=password]').value = btn.getAttribute('data-pass');
        f.submit();
    });
});
</script>
<?php require __DIR__ . '/includes/layout_end.php';
